import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/App.jsx");const useEffect = __vite__cjsImport0_react["useEffect"]; const useMemo = __vite__cjsImport0_react["useMemo"]; const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport3_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport3_react_jsxDevRuntime["Fragment"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=3abbd831";
import { ArrowUpRight, Ban, BellRing, Check, ChevronDown, CircleUserRound, Clock3, DoorOpen, Edit3, LayoutList, LogOut, Menu, MoreHorizontal, Plus, Settings2, ShieldCheck, Sparkles, Table2, UsersRound, X } from "/node_modules/.vite/deps/lucide-react.js?v=bc2ecd65";
import { backendApi as api } from "/src/api/backendApi.js";
var _jsxFileName = "C:/DATA/Cursos/ai-dev-tools/Final_Project/frontend/src/App.jsx";
import __vite__cjsImport3_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=3abbd831";
var _s = $RefreshSig$(), _s2 = $RefreshSig$(), _s3 = $RefreshSig$(), _s4 = $RefreshSig$(), _s5 = $RefreshSig$(), _s6 = $RefreshSig$(), _s7 = $RefreshSig$(), _s8 = $RefreshSig$(), _s9 = $RefreshSig$();
const preferenceOptions = [
	"No preference",
	"Dining room",
	"Patio",
	"Bar"
];
const formatTime = (value) => new Intl.DateTimeFormat("en-US", {
	hour: "numeric",
	minute: "2-digit"
}).format(new Date(value));
const formatDate = (value = new Date()) => new Intl.DateTimeFormat("en-US", {
	weekday: "long",
	month: "long",
	day: "numeric"
}).format(new Date(value));
const formatRelative = (value) => {
	const minutes = Math.max(0, Math.floor((Date.now() - new Date(value).getTime()) / 6e4));
	if (minutes < 1) return "Just now";
	if (minutes === 1) return "1 min ago";
	return `${minutes} min ago`;
};
function App() {
	_s();
	const [session, setSession] = useState(() => api.getSession());
	const [data, setData] = useState(null);
	const [view, setView] = useState("waitlist");
	const [loading, setLoading] = useState(Boolean(session));
	const [modal, setModal] = useState(null);
	const [toast, setToast] = useState(null);
	const [sidebarOpen, setSidebarOpen] = useState(false);
	const refresh = async () => {
		const dashboard = await api.getDashboard();
		setData(dashboard);
	};
	useEffect(() => {
		if (!session) return undefined;
		let mounted = true;
		setLoading(true);
		api.getDashboard().then((dashboard) => {
			if (mounted) {
				setData(dashboard);
				setLoading(false);
			}
		}).catch((error) => {
			if (!mounted) return;
			setLoading(false);
			if (error.status === 401) {
				api.clearSession();
				setSession(null);
				setData(null);
			} else {
				notify(error.message, "error");
			}
		});
		return () => {
			mounted = false;
		};
	}, [session]);
	useEffect(() => {
		if (!toast) return undefined;
		const timeout = window.setTimeout(() => setToast(null), 3600);
		return () => window.clearTimeout(timeout);
	}, [toast]);
	const notify = (message, tone = "success") => setToast({
		message,
		tone
	});
	const handleLogin = async (credentials) => {
		try {
			const nextSession = await api.login(credentials);
			setSession(nextSession);
			notify(`Welcome back, ${nextSession.name.split(" ")[0]}.`);
		} catch (error) {
			throw error;
		}
	};
	const handleLogout = () => {
		void api.logout();
		setSession(null);
		setData(null);
		setView("waitlist");
	};
	const runMutation = async (action, successMessage) => {
		try {
			await action();
			await refresh();
			setModal(null);
			notify(successMessage);
		} catch (error) {
			if (error.status === 401) {
				api.clearSession();
				setSession(null);
				setData(null);
			} else {
				notify(error.message, "error");
			}
		}
	};
	if (!session) return /* @__PURE__ */ _jsxDEV(LoginScreen, { onLogin: handleLogin }, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 116,
		columnNumber: 24
	}, this);
	if (loading || !data) return /* @__PURE__ */ _jsxDEV(LoadingScreen, {}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 117,
		columnNumber: 32
	}, this);
	const activeCount = data.entries.filter((entry) => entry.status === "waiting").length;
	const occupiedTableIds = new Set(data.tables.filter((table) => table.availability === "occupied").map((table) => table.id));
	const availableCount = data.tables.filter((table) => table.isActive && table.availability === "available").length;
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "app-shell",
		children: [
			/* @__PURE__ */ _jsxDEV("aside", {
				className: `sidebar ${sidebarOpen ? "is-open" : ""}`,
				children: [
					/* @__PURE__ */ _jsxDEV("div", {
						className: "brand-lockup",
						children: [
							/* @__PURE__ */ _jsxDEV("div", {
								className: "brand-mark",
								children: [/* @__PURE__ */ _jsxDEV("span", { children: "J" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 127,
									columnNumber: 39
								}, this), /* @__PURE__ */ _jsxDEV("span", { children: "P" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 127,
									columnNumber: 53
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 127,
								columnNumber: 11
							}, this),
							/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "brand-name",
								children: "HOSTBOARD"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 129,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "brand-subtitle",
								children: "June & Pine"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 130,
								columnNumber: 13
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 128,
								columnNumber: 11
							}, this),
							/* @__PURE__ */ _jsxDEV("button", {
								className: "icon-button sidebar-close",
								onClick: () => setSidebarOpen(false),
								"aria-label": "Close navigation",
								children: /* @__PURE__ */ _jsxDEV(X, { size: 18 }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 132,
									columnNumber: 125
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 132,
								columnNumber: 11
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 126,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "service-switcher",
						children: [
							/* @__PURE__ */ _jsxDEV("div", {
								className: "service-kicker",
								children: [/* @__PURE__ */ _jsxDEV("span", { className: "live-dot" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 135,
									columnNumber: 43
								}, this), " Live service"]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 135,
								columnNumber: 11
							}, this),
							/* @__PURE__ */ _jsxDEV("strong", { children: data.restaurant.serviceLabel }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 136,
								columnNumber: 11
							}, this),
							/* @__PURE__ */ _jsxDEV("span", {
								className: "service-date",
								children: formatDate()
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 137,
								columnNumber: 11
							}, this),
							/* @__PURE__ */ _jsxDEV(ChevronDown, { size: 15 }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 138,
								columnNumber: 11
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 134,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("nav", {
						className: "primary-nav",
						"aria-label": "Primary navigation",
						children: [
							/* @__PURE__ */ _jsxDEV(NavItem, {
								icon: /* @__PURE__ */ _jsxDEV(LayoutList, { size: 18 }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 141,
									columnNumber: 26
								}, this),
								label: "Waitlist",
								active: view === "waitlist",
								onClick: () => {
									setView("waitlist");
									setSidebarOpen(false);
								},
								count: activeCount
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 141,
								columnNumber: 11
							}, this),
							/* @__PURE__ */ _jsxDEV(NavItem, {
								icon: /* @__PURE__ */ _jsxDEV(Clock3, { size: 18 }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 142,
									columnNumber: 26
								}, this),
								label: "Today’s history",
								active: view === "history",
								onClick: () => {
									setView("history");
									setSidebarOpen(false);
								}
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 142,
								columnNumber: 11
							}, this),
							session.role === "manager" && /* @__PURE__ */ _jsxDEV(NavItem, {
								icon: /* @__PURE__ */ _jsxDEV(Settings2, { size: 18 }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 143,
									columnNumber: 57
								}, this),
								label: "Manager settings",
								active: view === "settings",
								onClick: () => {
									setView("settings");
									setSidebarOpen(false);
								}
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 143,
								columnNumber: 42
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 140,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "sidebar-footer",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "sidebar-note",
							children: [/* @__PURE__ */ _jsxDEV(Sparkles, { size: 15 }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 146,
								columnNumber: 41
							}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Keep the room moving." }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 146,
								columnNumber: 63
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 146,
							columnNumber: 11
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "profile-row",
							children: [
								/* @__PURE__ */ _jsxDEV("div", {
									className: "avatar",
									children: session.name.split(" ").map((part) => part[0]).join("")
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 148,
									columnNumber: 13
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "profile-copy",
									children: [/* @__PURE__ */ _jsxDEV("strong", { children: session.name }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 149,
										columnNumber: 43
									}, this), /* @__PURE__ */ _jsxDEV("span", { children: session.role }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 149,
										columnNumber: 74
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 149,
									columnNumber: 13
								}, this),
								/* @__PURE__ */ _jsxDEV("button", {
									className: "icon-button",
									onClick: handleLogout,
									"aria-label": "Sign out",
									title: "Sign out",
									children: /* @__PURE__ */ _jsxDEV(LogOut, { size: 17 }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 150,
										columnNumber: 107
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 150,
									columnNumber: 13
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 147,
							columnNumber: 11
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 145,
						columnNumber: 9
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 125,
				columnNumber: 7
			}, this),
			sidebarOpen && /* @__PURE__ */ _jsxDEV("button", {
				className: "sidebar-scrim",
				onClick: () => setSidebarOpen(false),
				"aria-label": "Close navigation"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 154,
				columnNumber: 23
			}, this),
			/* @__PURE__ */ _jsxDEV("main", {
				className: "main-shell",
				children: [/* @__PURE__ */ _jsxDEV("header", {
					className: "topbar",
					children: [
						/* @__PURE__ */ _jsxDEV("button", {
							className: "icon-button menu-button",
							onClick: () => setSidebarOpen(true),
							"aria-label": "Open navigation",
							children: /* @__PURE__ */ _jsxDEV(Menu, { size: 20 }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 157,
								columnNumber: 121
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 157,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "crumb",
							children: [
								/* @__PURE__ */ _jsxDEV("span", { children: "Operations" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 158,
									columnNumber: 34
								}, this),
								/* @__PURE__ */ _jsxDEV("span", {
									className: "crumb-slash",
									children: "/"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 158,
									columnNumber: 57
								}, this),
								/* @__PURE__ */ _jsxDEV("strong", { children: view === "waitlist" ? "Waitlist" : view === "history" ? "Today’s history" : "Manager settings" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 158,
									columnNumber: 95
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 158,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "topbar-actions",
							children: [
								/* @__PURE__ */ _jsxDEV("div", {
									className: `open-pill ${data.restaurant.isOpen ? "is-open" : "is-closed"}`,
									children: [
										/* @__PURE__ */ _jsxDEV("span", { className: "open-pill-dot" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 160,
											columnNumber: 94
										}, this),
										" ",
										data.restaurant.isOpen ? "Open now" : "Closed"
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 160,
									columnNumber: 13
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "topbar-date",
									children: formatDate()
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 161,
									columnNumber: 13
								}, this),
								/* @__PURE__ */ _jsxDEV("button", {
									className: "avatar avatar-small",
									"aria-label": "Current profile",
									children: session.name.split(" ").map((part) => part[0]).join("")
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 162,
									columnNumber: 13
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 159,
							columnNumber: 11
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 156,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "content-wrap",
					children: [
						view === "waitlist" && /* @__PURE__ */ _jsxDEV(WaitlistView, {
							data,
							onAdd: () => setModal({ type: "party" }),
							onEdit: (entry) => setModal({
								type: "party",
								entry
							}),
							onSeat: (entry) => setModal({
								type: "seat",
								entry
							}),
							onCancel: (entry) => setModal({
								type: "cancel",
								entry
							}),
							onReleaseTable: (table) => setModal({
								type: "release-table",
								table
							})
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 166,
							columnNumber: 35
						}, this),
						view === "history" && /* @__PURE__ */ _jsxDEV(HistoryView, {
							data,
							onReleaseTable: (table) => setModal({
								type: "release-table",
								table
							})
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 167,
							columnNumber: 34
						}, this),
						view === "settings" && session.role === "manager" && /* @__PURE__ */ _jsxDEV(SettingsView, {
							data,
							onRefresh: refresh,
							onNotify: notify,
							onModal: setModal
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 168,
							columnNumber: 65
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 165,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 155,
				columnNumber: 7
			}, this),
			modal?.type === "party" && /* @__PURE__ */ _jsxDEV(PartyModal, {
				entry: modal.entry,
				entries: data.entries,
				onClose: () => setModal(null),
				onSave: (payload) => runMutation(() => modal.entry ? api.updateEntry(modal.entry.id, payload, session) : api.createEntry(payload, session), modal.entry ? "Party details updated." : "Party added to the waitlist.")
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 171,
				columnNumber: 35
			}, this),
			modal?.type === "seat" && /* @__PURE__ */ _jsxDEV(SeatModal, {
				entry: modal.entry,
				tables: data.tables,
				entries: data.entries,
				areas: data.areas,
				onClose: () => setModal(null),
				onSeat: (tableId) => runMutation(() => api.seatEntry(modal.entry.id, tableId, session), `${modal.entry.guestName} is seated.`)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 172,
				columnNumber: 34
			}, this),
			modal?.type === "cancel" && /* @__PURE__ */ _jsxDEV(ConfirmModal, {
				title: "Cancel this party?",
				description: `${modal.entry.guestName} will leave the active queue. This action will be kept in today’s history.`,
				confirmLabel: "Cancel party",
				onClose: () => setModal(null),
				onConfirm: () => runMutation(() => api.cancelEntry(modal.entry.id, session), `${modal.entry.guestName} was cancelled.`)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 173,
				columnNumber: 36
			}, this),
			modal?.type === "table" && /* @__PURE__ */ _jsxDEV(TableModal, {
				table: modal.table,
				areas: data.areas,
				onClose: () => setModal(null),
				onSave: (payload) => runMutation(() => modal.table ? api.updateTable(modal.table.id, payload) : api.createTable(payload), modal.table ? "Table details updated." : "Table added to the room.")
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 174,
				columnNumber: 35
			}, this),
			modal?.type === "staff" && /* @__PURE__ */ _jsxDEV(StaffModal, {
				onClose: () => setModal(null),
				onSave: (payload) => runMutation(() => api.createStaff(payload), "Staff account created.")
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 175,
				columnNumber: 35
			}, this),
			modal?.type === "release-table" && /* @__PURE__ */ _jsxDEV(ConfirmModal, {
				title: `Mark ${modal.table.name} as free?`,
				description: modal.table.currentParty ? `${modal.table.currentParty.guestName}’s party (${modal.table.currentParty.partySize} guests) has finished using table ${modal.table.name}. It will become available immediately for new parties.` : `Mark table ${modal.table.name} as free and ready for new guests.`,
				confirmLabel: "Mark table free",
				onClose: () => setModal(null),
				onConfirm: () => runMutation(() => api.releaseTable(modal.table.id), `Table ${modal.table.name} is now free.`)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 176,
				columnNumber: 43
			}, this),
			toast && /* @__PURE__ */ _jsxDEV("div", {
				className: `toast toast-${toast.tone}`,
				role: "status",
				children: [/* @__PURE__ */ _jsxDEV("span", {
					className: "toast-icon",
					children: toast.tone === "error" ? /* @__PURE__ */ _jsxDEV(Ban, { size: 16 }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 177,
						columnNumber: 131
					}, this) : /* @__PURE__ */ _jsxDEV(Check, { size: 16 }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 177,
						columnNumber: 151
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 177,
					columnNumber: 76
				}, this), toast.message]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 177,
				columnNumber: 17
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 124,
		columnNumber: 5
	}, this);
}
_s(App, "KoneyLtKC9caJeqO1JcmIuuIwOc=");
_c = App;
function NavItem({ icon, label, active, onClick, count }) {
	return /* @__PURE__ */ _jsxDEV("button", {
		className: `nav-item ${active ? "is-active" : ""}`,
		onClick,
		children: [
			icon,
			/* @__PURE__ */ _jsxDEV("span", { children: label }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 183,
				columnNumber: 94
			}, this),
			count > 0 && /* @__PURE__ */ _jsxDEV("span", {
				className: "nav-count",
				children: count
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 183,
				columnNumber: 128
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 183,
		columnNumber: 10
	}, this);
}
_c2 = NavItem;
function LoadingScreen() {
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "loading-screen",
		children: [/* @__PURE__ */ _jsxDEV("div", {
			className: "loading-orbit",
			children: /* @__PURE__ */ _jsxDEV("span", {}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 187,
				columnNumber: 73
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 187,
			columnNumber: 42
		}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Opening the service board" }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 187,
			columnNumber: 87
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 187,
		columnNumber: 10
	}, this);
}
_c3 = LoadingScreen;
function LoginScreen({ onLogin }) {
	_s2();
	const [identifier, setIdentifier] = useState("maya@juneandpine.com");
	const [password, setPassword] = useState("demo1234");
	const [busy, setBusy] = useState(false);
	const [error, setError] = useState("");
	const submit = async (event) => {
		event.preventDefault();
		setBusy(true);
		setError("");
		try {
			await onLogin({
				identifier,
				password
			});
		} catch (loginError) {
			setError(loginError.message);
		} finally {
			setBusy(false);
		}
	};
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "login-screen",
		children: [
			/* @__PURE__ */ _jsxDEV("div", { className: "login-ambient ambient-one" }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 210,
				columnNumber: 5
			}, this),
			/* @__PURE__ */ _jsxDEV("div", { className: "login-ambient ambient-two" }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 210,
				columnNumber: 50
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "login-left",
				children: [
					/* @__PURE__ */ _jsxDEV("div", {
						className: "login-brand",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "brand-mark",
							children: [/* @__PURE__ */ _jsxDEV("span", { children: "J" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 212,
								columnNumber: 64
							}, this), /* @__PURE__ */ _jsxDEV("span", { children: "P" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 212,
								columnNumber: 78
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 212,
							columnNumber: 36
						}, this), /* @__PURE__ */ _jsxDEV("span", { children: "HOSTBOARD" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 212,
							columnNumber: 98
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 212,
						columnNumber: 7
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "login-copy",
						children: [
							/* @__PURE__ */ _jsxDEV("p", {
								className: "eyebrow",
								children: "June & Pine / Service operations"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 213,
								columnNumber: 35
							}, this),
							/* @__PURE__ */ _jsxDEV("h1", { children: [
								"Make every",
								/* @__PURE__ */ _jsxDEV("br", {}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 213,
									columnNumber: 108
								}, this),
								/* @__PURE__ */ _jsxDEV("em", { children: "seat" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 213,
									columnNumber: 114
								}, this),
								" count."
							] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 213,
								columnNumber: 94
							}, this),
							/* @__PURE__ */ _jsxDEV("p", { children: "A clear-eyed waitlist for the moments between arrival and first bite." }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 213,
								columnNumber: 139
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 213,
						columnNumber: 7
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "login-footer",
						children: [
							/* @__PURE__ */ _jsxDEV("span", { children: "Staff workspace" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 214,
								columnNumber: 37
							}, this),
							/* @__PURE__ */ _jsxDEV("span", { className: "login-footer-line" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 214,
								columnNumber: 65
							}, this),
							/* @__PURE__ */ _jsxDEV("span", { children: "Brooklyn, NY" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 214,
								columnNumber: 103
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 214,
						columnNumber: 7
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 211,
				columnNumber: 5
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "login-panel-wrap",
				children: /* @__PURE__ */ _jsxDEV("div", {
					className: "login-panel",
					children: [
						/* @__PURE__ */ _jsxDEV("div", {
							className: "panel-kicker",
							children: [/* @__PURE__ */ _jsxDEV(ShieldCheck, { size: 16 }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 217,
								columnNumber: 37
							}, this), " Staff sign in"]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 217,
							columnNumber: 7
						}, this),
						/* @__PURE__ */ _jsxDEV("h2", { children: "Good evening." }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 218,
							columnNumber: 7
						}, this),
						/* @__PURE__ */ _jsxDEV("p", {
							className: "panel-intro",
							children: "Sign in to open tonight’s service board."
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 218,
							columnNumber: 29
						}, this),
						/* @__PURE__ */ _jsxDEV("form", {
							onSubmit: submit,
							className: "login-form",
							children: [
								/* @__PURE__ */ _jsxDEV(Field, {
									label: "Work email",
									value: identifier,
									onChange: setIdentifier,
									type: "email",
									autoComplete: "username"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 220,
									columnNumber: 9
								}, this),
								/* @__PURE__ */ _jsxDEV(Field, {
									label: "Password",
									value: password,
									onChange: setPassword,
									type: "password",
									autoComplete: "current-password"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 221,
									columnNumber: 9
								}, this),
								error && /* @__PURE__ */ _jsxDEV("div", {
									className: "form-error",
									children: [/* @__PURE__ */ _jsxDEV(Ban, { size: 15 }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 222,
										columnNumber: 47
									}, this), error]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 222,
									columnNumber: 19
								}, this),
								/* @__PURE__ */ _jsxDEV("button", {
									className: "button button-primary button-wide",
									disabled: busy,
									children: [
										busy ? "Opening board…" : "Enter service board",
										" ",
										/* @__PURE__ */ _jsxDEV(ArrowUpRight, { size: 17 }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 223,
											columnNumber: 129
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 223,
									columnNumber: 9
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 219,
							columnNumber: 7
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "demo-accounts",
							children: [
								/* @__PURE__ */ _jsxDEV("span", { children: "Demo access" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 225,
									columnNumber: 38
								}, this),
								/* @__PURE__ */ _jsxDEV("button", {
									type: "button",
									onClick: () => {
										setIdentifier("maya@juneandpine.com");
										setPassword("demo1234");
									},
									children: "Manager"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 225,
									columnNumber: 62
								}, this),
								/* @__PURE__ */ _jsxDEV("button", {
									type: "button",
									onClick: () => {
										setIdentifier("luca@juneandpine.com");
										setPassword("demo1234");
									},
									children: "Host"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 225,
									columnNumber: 183
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 225,
							columnNumber: 7
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 216,
					columnNumber: 39
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 216,
				columnNumber: 5
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 209,
		columnNumber: 10
	}, this);
}
_s2(LoginScreen, "kUrGKhJV1G1yy1tTj0GmuDmFtig=");
_c4 = LoginScreen;
function WaitlistView({ data, onAdd, onEdit, onSeat, onCancel, onReleaseTable }) {
	_s3();
	const [filter, setFilter] = useState("All");
	const waiting = data.entries.filter((entry) => entry.status === "waiting");
	const seated = data.entries.filter((entry) => entry.status === "seated").length;
	const available = data.tables.filter((table) => table.isActive && table.availability === "available").length;
	const visible = filter === "All" ? waiting : waiting.filter((entry) => entry.seatingPreference === filter);
	const oldest = waiting[0];
	return /* @__PURE__ */ _jsxDEV(_Fragment, { children: [
		/* @__PURE__ */ _jsxDEV("section", {
			className: "page-intro page-intro-board",
			children: [/* @__PURE__ */ _jsxDEV("div", { children: [
				/* @__PURE__ */ _jsxDEV("p", {
					className: "eyebrow",
					children: [
						/* @__PURE__ */ _jsxDEV("span", { className: "eyebrow-pulse" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 240,
							columnNumber: 35
						}, this),
						" Live service / ",
						data.restaurant.serviceLabel
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 240,
					columnNumber: 12
				}, this),
				/* @__PURE__ */ _jsxDEV("h1", { children: ["Keep the room moving", /* @__PURE__ */ _jsxDEV("span", {
					className: "period",
					children: "."
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 240,
					columnNumber: 143
				}, this)] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 240,
					columnNumber: 119
				}, this),
				/* @__PURE__ */ _jsxDEV("p", {
					className: "page-description",
					children: "The active board for tonight’s walk-ins. First in, first served."
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 240,
					columnNumber: 181
				}, this)
			] }, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 240,
				columnNumber: 7
			}, this), /* @__PURE__ */ _jsxDEV("button", {
				className: "button button-primary button-add",
				onClick: onAdd,
				children: [/* @__PURE__ */ _jsxDEV(Plus, { size: 18 }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 241,
					columnNumber: 76
				}, this), " Add party"]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 241,
				columnNumber: 7
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 239,
			columnNumber: 5
		}, this),
		/* @__PURE__ */ _jsxDEV("section", {
			className: "metric-strip",
			"aria-label": "Service summary",
			children: [
				/* @__PURE__ */ _jsxDEV(Metric, {
					label: "Waiting now",
					value: waiting.length,
					detail: waiting.length ? `Next up: ${waiting[0].guestName}` : "The queue is clear",
					accent: "red"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 244,
					columnNumber: 7
				}, this),
				/* @__PURE__ */ _jsxDEV(Metric, {
					label: "Seated tonight",
					value: seated,
					detail: "Completed service entries",
					accent: "green"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 245,
					columnNumber: 7
				}, this),
				/* @__PURE__ */ _jsxDEV(Metric, {
					label: "Open tables",
					value: available,
					detail: "Ready for a party",
					accent: "ink"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 246,
					columnNumber: 7
				}, this),
				/* @__PURE__ */ _jsxDEV(Metric, {
					label: "Longest wait",
					value: oldest ? formatRelative(oldest.createdAt) : "—",
					detail: oldest ? oldest.guestName : "No active parties",
					accent: "amber"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 247,
					columnNumber: 7
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 243,
			columnNumber: 5
		}, this),
		/* @__PURE__ */ _jsxDEV("div", {
			className: "board-grid",
			children: [/* @__PURE__ */ _jsxDEV("section", {
				className: "queue-panel",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "section-heading queue-heading",
					children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("p", {
						className: "eyebrow",
						children: "The line"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 251,
						columnNumber: 61
					}, this), /* @__PURE__ */ _jsxDEV("h2", { children: ["Active waitlist ", /* @__PURE__ */ _jsxDEV("span", {
						className: "heading-count",
						children: waiting.length
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 251,
						columnNumber: 116
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 251,
						columnNumber: 96
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 251,
						columnNumber: 56
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						className: "filter-tabs",
						children: [
							"All",
							"Dining room",
							"Patio",
							"Bar"
						].map((item) => /* @__PURE__ */ _jsxDEV("button", {
							className: filter === item ? "is-active" : "",
							onClick: () => setFilter(item),
							children: item
						}, item, false, {
							fileName: _jsxFileName,
							lineNumber: 251,
							columnNumber: 265
						}, this))
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 251,
						columnNumber: 182
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 251,
					columnNumber: 9
				}, this), visible.length === 0 ? /* @__PURE__ */ _jsxDEV(EmptyQueue, {
					onAdd,
					filtered: filter !== "All"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 252,
					columnNumber: 33
				}, this) : /* @__PURE__ */ _jsxDEV("div", {
					className: "queue-list",
					children: visible.map((entry, index) => /* @__PURE__ */ _jsxDEV(QueueRow, {
						entry,
						position: waiting.indexOf(entry) + 1,
						isNext: waiting.indexOf(entry) === 0,
						onEdit,
						onSeat,
						onCancel
					}, entry.id, false, {
						fileName: _jsxFileName,
						lineNumber: 252,
						columnNumber: 151
					}, this))
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 252,
					columnNumber: 92
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 250,
				columnNumber: 7
			}, this), /* @__PURE__ */ _jsxDEV("aside", {
				className: "room-rail",
				children: [
					/* @__PURE__ */ _jsxDEV("div", {
						className: "rail-heading",
						children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("p", {
							className: "eyebrow",
							children: "The room"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 255,
							columnNumber: 44
						}, this), /* @__PURE__ */ _jsxDEV("h2", { children: "Table pulse" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 255,
							columnNumber: 79
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 255,
							columnNumber: 39
						}, this), /* @__PURE__ */ _jsxDEV(Table2, { size: 20 }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 255,
							columnNumber: 105
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 255,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "table-summary",
						children: [
							/* @__PURE__ */ _jsxDEV("strong", { children: available }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 256,
								columnNumber: 40
							}, this),
							/* @__PURE__ */ _jsxDEV("span", { children: [
								"of ",
								data.tables.filter((table) => table.isActive).length,
								" active tables open"
							] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 256,
								columnNumber: 68
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "table-meter",
								children: /* @__PURE__ */ _jsxDEV("span", { style: { width: `${Math.max(6, available / Math.max(1, data.tables.filter((table) => table.isActive).length) * 100)}%` } }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 256,
									columnNumber: 186
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 256,
								columnNumber: 157
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 256,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "mini-table-grid",
						children: data.tables.filter((table) => table.isActive).map((table) => {
							const occupied = table.availability === "occupied";
							return /* @__PURE__ */ _jsxDEV("button", {
								type: "button",
								className: `mini-table ${occupied ? "is-occupied" : ""}`,
								onClick: () => occupied && onReleaseTable && onReleaseTable(table),
								style: {
									cursor: occupied ? "pointer" : "default",
									textAlign: "left",
									border: "none",
									font: "inherit"
								},
								title: occupied ? `Occupied by ${table.currentParty?.guestName || "party"}. Click to mark table free.` : `${table.capacity} seats available`,
								children: [/* @__PURE__ */ _jsxDEV("span", { children: table.name }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 257,
									columnNumber: 575
								}, this), /* @__PURE__ */ _jsxDEV("small", { children: occupied ? table.currentParty ? `${table.currentParty.guestName} · Free` : "Occupied · Free" : `${table.capacity} seats` }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 257,
									columnNumber: 600
								}, this)]
							}, table.id, true, {
								fileName: _jsxFileName,
								lineNumber: 257,
								columnNumber: 165
							}, this);
						})
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 257,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("div", { className: "rail-divider" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 258,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "rail-activity",
						children: [
							/* @__PURE__ */ _jsxDEV("div", {
								className: "rail-heading small",
								children: [/* @__PURE__ */ _jsxDEV("h3", { children: "Service note" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 259,
									columnNumber: 76
								}, this), /* @__PURE__ */ _jsxDEV(BellRing, { size: 16 }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 259,
									columnNumber: 97
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 259,
								columnNumber: 40
							}, this),
							/* @__PURE__ */ _jsxDEV("p", { children: "Click occupied tables to mark them free once guests depart, or select an available table when seating." }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 259,
								columnNumber: 125
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "activity-user",
								children: [/* @__PURE__ */ _jsxDEV("div", {
									className: "avatar avatar-tiny",
									children: "JP"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 259,
									columnNumber: 265
								}, this), /* @__PURE__ */ _jsxDEV("span", { children: "June & Pine staff workspace" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 259,
									columnNumber: 309
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 259,
								columnNumber: 234
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 259,
						columnNumber: 9
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 254,
				columnNumber: 7
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 249,
			columnNumber: 5
		}, this)
	] }, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 238,
		columnNumber: 10
	}, this);
}
_s3(WaitlistView, "0moJxxOgRMEoT9kgLUwB+XpLGiM=");
_c5 = WaitlistView;
function Metric({ label, value, detail, accent }) {
	return /* @__PURE__ */ _jsxDEV("div", {
		className: `metric metric-${accent}`,
		children: [
			/* @__PURE__ */ _jsxDEV("div", {
				className: "metric-top",
				children: [/* @__PURE__ */ _jsxDEV("span", { children: label }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 266,
					columnNumber: 81
				}, this), /* @__PURE__ */ _jsxDEV("span", { className: "metric-mark" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 266,
					columnNumber: 101
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 266,
				columnNumber: 53
			}, this),
			/* @__PURE__ */ _jsxDEV("strong", { children: value }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 266,
				columnNumber: 139
			}, this),
			/* @__PURE__ */ _jsxDEV("small", { children: detail }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 266,
				columnNumber: 163
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 266,
		columnNumber: 10
	}, this);
}
_c6 = Metric;
function QueueRow({ entry, position, isNext, onEdit, onSeat, onCancel }) {
	return /* @__PURE__ */ _jsxDEV("article", {
		className: `queue-row ${isNext ? "is-next" : ""}`,
		children: [
			/* @__PURE__ */ _jsxDEV("div", {
				className: "queue-position",
				children: isNext ? /* @__PURE__ */ _jsxDEV("span", {
					className: "next-tag",
					children: "Next"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 271,
					columnNumber: 47
				}, this) : /* @__PURE__ */ _jsxDEV("span", { children: String(position).padStart(2, "0") }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 271,
					columnNumber: 88
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 271,
				columnNumber: 5
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "party-main",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "party-name-line",
					children: [/* @__PURE__ */ _jsxDEV("h3", { children: entry.guestName }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 272,
						columnNumber: 66
					}, this), entry.notes && /* @__PURE__ */ _jsxDEV("span", {
						className: "note-flag",
						title: entry.notes,
						children: "Note"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 272,
						columnNumber: 108
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 272,
					columnNumber: 33
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "party-meta",
					children: [
						/* @__PURE__ */ _jsxDEV("span", { children: [
							/* @__PURE__ */ _jsxDEV(UsersRound, { size: 14 }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 272,
								columnNumber: 208
							}, this),
							" ",
							entry.partySize,
							" ",
							entry.partySize === 1 ? "guest" : "guests"
						] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 272,
							columnNumber: 202
						}, this),
						/* @__PURE__ */ _jsxDEV("span", { children: [
							/* @__PURE__ */ _jsxDEV(DoorOpen, { size: 14 }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 272,
								columnNumber: 308
							}, this),
							" ",
							entry.seatingPreference
						] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 272,
							columnNumber: 302
						}, this),
						/* @__PURE__ */ _jsxDEV("span", { children: [
							/* @__PURE__ */ _jsxDEV(Clock3, { size: 14 }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 272,
								columnNumber: 369
							}, this),
							" ",
							formatTime(entry.createdAt)
						] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 272,
							columnNumber: 363
						}, this),
						/* @__PURE__ */ _jsxDEV("span", {
							className: "party-phone-inline",
							children: entry.phone
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 272,
							columnNumber: 426
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 272,
					columnNumber: 174
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 272,
				columnNumber: 5
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "party-phone",
				children: entry.phone
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 273,
				columnNumber: 5
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "wait-age",
				children: [/* @__PURE__ */ _jsxDEV("strong", { children: formatRelative(entry.createdAt) }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 274,
					columnNumber: 31
				}, this), /* @__PURE__ */ _jsxDEV("span", { children: "waiting" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 274,
					columnNumber: 81
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 274,
				columnNumber: 5
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "row-actions",
				children: [
					/* @__PURE__ */ _jsxDEV("button", {
						className: "button button-seat",
						onClick: () => onSeat(entry),
						children: [/* @__PURE__ */ _jsxDEV(Table2, { size: 15 }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 275,
							columnNumber: 103
						}, this), " Seat"]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 275,
						columnNumber: 34
					}, this),
					/* @__PURE__ */ _jsxDEV("button", {
						className: "icon-button",
						onClick: () => onEdit(entry),
						"aria-label": `Edit ${entry.guestName}`,
						title: "Edit",
						children: /* @__PURE__ */ _jsxDEV(Edit3, { size: 16 }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 275,
							columnNumber: 251
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 275,
						columnNumber: 137
					}, this),
					/* @__PURE__ */ _jsxDEV("button", {
						className: "icon-button icon-danger",
						onClick: () => onCancel(entry),
						"aria-label": `Cancel ${entry.guestName}`,
						title: "Cancel",
						children: /* @__PURE__ */ _jsxDEV(X, { size: 17 }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 275,
							columnNumber: 411
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 275,
						columnNumber: 279
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 275,
				columnNumber: 5
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 270,
		columnNumber: 10
	}, this);
}
_c7 = QueueRow;
function EmptyQueue({ onAdd, filtered }) {
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "empty-state",
		children: [
			/* @__PURE__ */ _jsxDEV("div", {
				className: "empty-icon",
				children: /* @__PURE__ */ _jsxDEV(Sparkles, { size: 22 }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 280,
					columnNumber: 67
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 280,
				columnNumber: 39
			}, this),
			/* @__PURE__ */ _jsxDEV("h3", { children: filtered ? "No parties in this area" : "A clear room, for now" }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 280,
				columnNumber: 95
			}, this),
			/* @__PURE__ */ _jsxDEV("p", { children: filtered ? "Try another seating preference." : "When the first walk-in arrives, add them to the board." }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 280,
				columnNumber: 168
			}, this),
			!filtered && /* @__PURE__ */ _jsxDEV("button", {
				className: "button button-secondary",
				onClick: onAdd,
				children: [/* @__PURE__ */ _jsxDEV(Plus, { size: 16 }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 280,
					columnNumber: 354
				}, this), " Add first party"]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 280,
				columnNumber: 294
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 280,
		columnNumber: 10
	}, this);
}
_c8 = EmptyQueue;
function HistoryView({ data, onReleaseTable }) {
	const history = data.entries.filter((entry) => entry.status !== "waiting").sort((a, b) => new Date(b.seatedAt || b.cancelledAt || b.createdAt) - new Date(a.seatedAt || a.cancelledAt || a.createdAt));
	const seated = history.filter((entry) => entry.status === "seated").length;
	return /* @__PURE__ */ _jsxDEV(_Fragment, { children: [
		/* @__PURE__ */ _jsxDEV("section", {
			className: "page-intro",
			children: [/* @__PURE__ */ _jsxDEV("div", { children: [
				/* @__PURE__ */ _jsxDEV("p", {
					className: "eyebrow",
					children: "Service archive / Today"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 286,
					columnNumber: 49
				}, this),
				/* @__PURE__ */ _jsxDEV("h1", { children: ["Today’s history", /* @__PURE__ */ _jsxDEV("span", {
					className: "period",
					children: "."
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 286,
					columnNumber: 118
				}, this)] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 286,
					columnNumber: 99
				}, this),
				/* @__PURE__ */ _jsxDEV("p", {
					className: "page-description",
					children: "A quiet record of every handoff after the waitlist."
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 286,
					columnNumber: 156
				}, this)
			] }, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 286,
				columnNumber: 44
			}, this), /* @__PURE__ */ _jsxDEV("div", {
				className: "history-total",
				children: [/* @__PURE__ */ _jsxDEV("strong", { children: history.length }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 286,
					columnNumber: 280
				}, this), /* @__PURE__ */ _jsxDEV("span", { children: "completed entries" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 286,
					columnNumber: 313
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 286,
				columnNumber: 249
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 286,
			columnNumber: 12
		}, this),
		/* @__PURE__ */ _jsxDEV("section", {
			className: "history-summary",
			children: [
				/* @__PURE__ */ _jsxDEV("div", { children: [
					/* @__PURE__ */ _jsxDEV("span", {
						className: "summary-label",
						children: "Seated"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 286,
						columnNumber: 401
					}, this),
					/* @__PURE__ */ _jsxDEV("strong", { children: seated }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 286,
						columnNumber: 446
					}, this),
					/* @__PURE__ */ _jsxDEV("span", { children: "parties at a table" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 286,
						columnNumber: 471
					}, this)
				] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 286,
					columnNumber: 396
				}, this),
				/* @__PURE__ */ _jsxDEV("div", { children: [
					/* @__PURE__ */ _jsxDEV("span", {
						className: "summary-label",
						children: "Cancelled"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 286,
						columnNumber: 513
					}, this),
					/* @__PURE__ */ _jsxDEV("strong", { children: history.length - seated }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 286,
						columnNumber: 561
					}, this),
					/* @__PURE__ */ _jsxDEV("span", { children: "parties left the line" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 286,
						columnNumber: 603
					}, this)
				] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 286,
					columnNumber: 508
				}, this),
				/* @__PURE__ */ _jsxDEV("div", { children: [
					/* @__PURE__ */ _jsxDEV("span", {
						className: "summary-label",
						children: "Service date"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 286,
						columnNumber: 648
					}, this),
					/* @__PURE__ */ _jsxDEV("strong", { children: new Intl.DateTimeFormat("en-US", {
						month: "short",
						day: "numeric"
					}).format(new Date()) }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 286,
						columnNumber: 699
					}, this),
					/* @__PURE__ */ _jsxDEV("span", { children: data.restaurant.name }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 286,
						columnNumber: 805
					}, this)
				] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 286,
					columnNumber: 643
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 286,
			columnNumber: 359
		}, this),
		/* @__PURE__ */ _jsxDEV("section", {
			className: "history-panel",
			children: [/* @__PURE__ */ _jsxDEV("div", {
				className: "section-heading",
				children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("p", {
					className: "eyebrow",
					children: "The log"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 286,
					columnNumber: 929
				}, this), /* @__PURE__ */ _jsxDEV("h2", { children: "Completed entries" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 286,
					columnNumber: 963
				}, this)] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 286,
					columnNumber: 924
				}, this), /* @__PURE__ */ _jsxDEV("span", {
					className: "muted-label",
					children: "Current service day"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 286,
					columnNumber: 995
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 286,
				columnNumber: 891
			}, this), history.length === 0 ? /* @__PURE__ */ _jsxDEV(EmptyHistory, {}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 286,
				columnNumber: 1081
			}, this) : /* @__PURE__ */ _jsxDEV("div", {
				className: "history-list",
				children: history.map((entry) => /* @__PURE__ */ _jsxDEV(HistoryRow, {
					entry,
					table: data.tables.find((table) => table.id === entry.assignedTableId),
					onReleaseTable
				}, entry.id, false, {
					fileName: _jsxFileName,
					lineNumber: 286,
					columnNumber: 1154
				}, this))
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 286,
				columnNumber: 1100
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 286,
			columnNumber: 856
		}, this)
	] }, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 286,
		columnNumber: 10
	}, this);
}
_c9 = HistoryView;
function HistoryRow({ entry, table, onReleaseTable }) {
	const isSeated = entry.status === "seated";
	const isOccupied = isSeated && entry.isTableOccupied && table && table.availability === "occupied";
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "history-row",
		children: [
			/* @__PURE__ */ _jsxDEV("div", {
				className: `history-status ${isSeated ? "status-seated" : "status-cancelled"}`,
				children: isSeated ? /* @__PURE__ */ _jsxDEV(Check, { size: 15 }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 292,
					columnNumber: 136
				}, this) : /* @__PURE__ */ _jsxDEV(X, { size: 15 }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 292,
					columnNumber: 158
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 292,
				columnNumber: 39
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "history-party",
				children: [/* @__PURE__ */ _jsxDEV("strong", { children: entry.guestName }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 292,
					columnNumber: 211
				}, this), /* @__PURE__ */ _jsxDEV("span", { children: [
					entry.partySize,
					" guests · ",
					entry.seatingPreference
				] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 292,
					columnNumber: 245
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 292,
				columnNumber: 180
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "history-detail",
				children: [/* @__PURE__ */ _jsxDEV("span", { children: isSeated ? `Seated at ${table?.name || "table"}` : "Cancelled from queue" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 292,
					columnNumber: 348
				}, this), /* @__PURE__ */ _jsxDEV("small", { children: formatTime(entry.seatedAt || entry.cancelledAt || entry.createdAt) }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 292,
					columnNumber: 436
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 292,
				columnNumber: 316
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "history-staff",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "avatar avatar-tiny",
					children: (entry.completedBy || "Staff").split(" ").map((part) => part[0]).join("")
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 292,
					columnNumber: 556
				}, this), /* @__PURE__ */ _jsxDEV("span", { children: entry.completedBy || "Staff" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 292,
					columnNumber: 673
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 292,
				columnNumber: 525
			}, this),
			isOccupied && /* @__PURE__ */ _jsxDEV("button", {
				className: "button button-ghost",
				style: {
					padding: "0.35rem 0.75rem",
					fontSize: "0.85rem"
				},
				onClick: () => onReleaseTable(table),
				children: "Free table"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 292,
				columnNumber: 737
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 292,
		columnNumber: 10
	}, this);
}
_c10 = HistoryRow;
function EmptyHistory() {
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "empty-state compact",
		children: [
			/* @__PURE__ */ _jsxDEV("div", {
				className: "empty-icon",
				children: /* @__PURE__ */ _jsxDEV(Clock3, { size: 21 }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 295,
					columnNumber: 99
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 295,
				columnNumber: 71
			}, this),
			/* @__PURE__ */ _jsxDEV("h3", { children: "Nothing filed yet" }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 295,
				columnNumber: 125
			}, this),
			/* @__PURE__ */ _jsxDEV("p", { children: "Seated and cancelled parties will appear here." }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 295,
				columnNumber: 151
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 295,
		columnNumber: 34
	}, this);
}
_c11 = EmptyHistory;
function SettingsView({ data, onRefresh, onNotify, onModal }) {
	_s4();
	const [tab, setTab] = useState("room");
	const [restaurantName, setRestaurantName] = useState(data.restaurant.name);
	const [isOpen, setIsOpen] = useState(data.restaurant.isOpen);
	const [saving, setSaving] = useState(false);
	const saveRestaurant = async (event) => {
		event.preventDefault();
		setSaving(true);
		try {
			await api.updateRestaurant({
				name: restaurantName,
				isOpen
			});
			await onRefresh();
			onNotify("Restaurant settings saved.");
		} catch (error) {
			onNotify(error.message, "error");
		} finally {
			setSaving(false);
		}
	};
	return /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV("section", {
		className: "page-intro settings-intro",
		children: [/* @__PURE__ */ _jsxDEV("div", { children: [
			/* @__PURE__ */ _jsxDEV("p", {
				className: "eyebrow",
				children: "Control room / Manager access"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 307,
				columnNumber: 64
			}, this),
			/* @__PURE__ */ _jsxDEV("h1", { children: ["Make it yours", /* @__PURE__ */ _jsxDEV("span", {
				className: "period",
				children: "."
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 307,
				columnNumber: 137
			}, this)] }, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 307,
				columnNumber: 120
			}, this),
			/* @__PURE__ */ _jsxDEV("p", {
				className: "page-description",
				children: "The small controls that keep tonight’s operation feeling like yours."
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 307,
				columnNumber: 175
			}, this)
		] }, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 307,
			columnNumber: 59
		}, this), /* @__PURE__ */ _jsxDEV("div", {
			className: "manager-seal",
			children: [/* @__PURE__ */ _jsxDEV(ShieldCheck, { size: 19 }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 307,
				columnNumber: 315
			}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Manager access" }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 307,
				columnNumber: 340
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 307,
			columnNumber: 285
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 307,
		columnNumber: 12
	}, this), /* @__PURE__ */ _jsxDEV("div", {
		className: "settings-layout",
		children: [/* @__PURE__ */ _jsxDEV("div", {
			className: "settings-tabs",
			role: "tablist",
			children: [
				/* @__PURE__ */ _jsxDEV("button", {
					className: tab === "room" ? "is-active" : "",
					onClick: () => setTab("room"),
					children: [/* @__PURE__ */ _jsxDEV(Settings2, { size: 17 }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 307,
						columnNumber: 547
					}, this), " Restaurant"]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 307,
					columnNumber: 462
				}, this),
				/* @__PURE__ */ _jsxDEV("button", {
					className: tab === "tables" ? "is-active" : "",
					onClick: () => setTab("tables"),
					children: [
						/* @__PURE__ */ _jsxDEV(Table2, { size: 17 }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 307,
							columnNumber: 679
						}, this),
						" Tables ",
						/* @__PURE__ */ _jsxDEV("span", { children: data.tables.length }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 307,
							columnNumber: 707
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 307,
					columnNumber: 590
				}, this),
				/* @__PURE__ */ _jsxDEV("button", {
					className: tab === "staff" ? "is-active" : "",
					onClick: () => setTab("staff"),
					children: [
						/* @__PURE__ */ _jsxDEV(UsersRound, { size: 17 }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 307,
							columnNumber: 836
						}, this),
						" Staff ",
						/* @__PURE__ */ _jsxDEV("span", { children: data.users.length }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 307,
							columnNumber: 867
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 307,
					columnNumber: 749
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 307,
			columnNumber: 416
		}, this), /* @__PURE__ */ _jsxDEV("div", {
			className: "settings-content",
			children: [
				tab === "room" && /* @__PURE__ */ _jsxDEV("form", {
					className: "settings-section",
					onSubmit: saveRestaurant,
					children: [
						/* @__PURE__ */ _jsxDEV("div", {
							className: "settings-section-head",
							children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("p", {
								className: "eyebrow",
								children: "Restaurant identity"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 307,
								columnNumber: 1072
							}, this), /* @__PURE__ */ _jsxDEV("h2", { children: "Tonight’s room" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 307,
								columnNumber: 1118
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 307,
								columnNumber: 1067
							}, this), /* @__PURE__ */ _jsxDEV("button", {
								className: "button button-primary",
								disabled: saving,
								children: saving ? "Saving…" : "Save changes"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 307,
								columnNumber: 1147
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 307,
							columnNumber: 1028
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "form-grid",
							children: [/* @__PURE__ */ _jsxDEV(Field, {
								label: "Restaurant name",
								value: restaurantName,
								onChange: setRestaurantName
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 307,
								columnNumber: 1286
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "setting-toggle",
								children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("strong", { children: "Accept new parties" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 307,
									columnNumber: 1408
								}, this), /* @__PURE__ */ _jsxDEV("span", { children: "When closed, the queue stays visible but new entries are paused." }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 307,
									columnNumber: 1443
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 307,
									columnNumber: 1403
								}, this), /* @__PURE__ */ _jsxDEV("button", {
									type: "button",
									className: `toggle ${isOpen ? "is-on" : ""}`,
									onClick: () => setIsOpen((value) => !value),
									"aria-label": "Toggle restaurant open status",
									children: /* @__PURE__ */ _jsxDEV("span", {}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 307,
										columnNumber: 1682
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 307,
									columnNumber: 1526
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 307,
								columnNumber: 1371
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 307,
							columnNumber: 1259
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "preference-section",
							children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("p", {
								className: "eyebrow",
								children: "Seating preferences"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 307,
								columnNumber: 1752
							}, this), /* @__PURE__ */ _jsxDEV("h3", { children: "Areas in the room" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 307,
								columnNumber: 1798
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 307,
								columnNumber: 1747
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "preference-chips",
								children: data.areas.filter((area) => area.isActive).map((area) => /* @__PURE__ */ _jsxDEV("span", {
									className: "preference-chip",
									children: [/* @__PURE__ */ _jsxDEV("span", { className: "chip-dot" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 307,
										columnNumber: 1970
									}, this), area.name]
								}, area.id, true, {
									fileName: _jsxFileName,
									lineNumber: 307,
									columnNumber: 1922
								}, this))
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 307,
								columnNumber: 1830
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 307,
							columnNumber: 1711
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 307,
					columnNumber: 967
				}, this),
				tab === "tables" && /* @__PURE__ */ _jsxDEV(TablesSettings, {
					data,
					onModal
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 307,
					columnNumber: 2060
				}, this),
				tab === "staff" && /* @__PURE__ */ _jsxDEV(StaffSettings, {
					data,
					onModal,
					onRefresh,
					onNotify
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 307,
					columnNumber: 2129
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 307,
			columnNumber: 914
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 307,
		columnNumber: 383
	}, this)] }, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 307,
		columnNumber: 10
	}, this);
}
_s4(SettingsView, "yV3ihwC2kmyly/poKnbps4fiIm0=");
_c12 = SettingsView;
function TablesSettings({ data, onModal }) {
	return /* @__PURE__ */ _jsxDEV("section", {
		className: "settings-section",
		children: [/* @__PURE__ */ _jsxDEV("div", {
			className: "settings-section-head",
			children: [/* @__PURE__ */ _jsxDEV("div", { children: [
				/* @__PURE__ */ _jsxDEV("p", {
					className: "eyebrow",
					children: "Room inventory"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 311,
					columnNumber: 92
				}, this),
				/* @__PURE__ */ _jsxDEV("h2", { children: "Tables" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 311,
					columnNumber: 133
				}, this),
				/* @__PURE__ */ _jsxDEV("p", {
					className: "section-subtitle",
					children: "Active tables are available to hosts when seating a party."
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 311,
					columnNumber: 148
				}, this)
			] }, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 311,
				columnNumber: 87
			}, this), /* @__PURE__ */ _jsxDEV("button", {
				className: "button button-primary",
				onClick: () => onModal({ type: "table" }),
				children: [/* @__PURE__ */ _jsxDEV(Plus, { size: 16 }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 311,
					columnNumber: 333
				}, this), " Add table"]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 311,
				columnNumber: 248
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 311,
			columnNumber: 48
		}, this), /* @__PURE__ */ _jsxDEV("div", {
			className: "inventory-list",
			children: data.tables.map((table) => /* @__PURE__ */ _jsxDEV("div", {
				className: `inventory-row ${!table.isActive ? "is-inactive" : ""}`,
				children: [
					/* @__PURE__ */ _jsxDEV("div", {
						className: "inventory-symbol",
						children: /* @__PURE__ */ _jsxDEV(Table2, { size: 18 }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 311,
							columnNumber: 558
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 311,
						columnNumber: 524
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "inventory-main",
						children: [/* @__PURE__ */ _jsxDEV("strong", { children: table.name }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 311,
							columnNumber: 616
						}, this), /* @__PURE__ */ _jsxDEV("span", { children: [
							table.capacity,
							" seats · ",
							data.areas.find((area) => area.id === table.areaId)?.name || "No area"
						] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 311,
							columnNumber: 645
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 311,
						columnNumber: 584
					}, this),
					/* @__PURE__ */ _jsxDEV("span", {
						className: `inventory-status ${table.availability}`,
						children: table.availability === "occupied" ? "Occupied" : table.isActive ? "Available" : "Inactive"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 311,
						columnNumber: 761
					}, this),
					table.availability === "occupied" && /* @__PURE__ */ _jsxDEV("button", {
						className: "text-button",
						style: {
							marginLeft: "0.5rem",
							fontWeight: 600
						},
						onClick: () => onModal({
							type: "release-table",
							table
						}),
						children: "Free table"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 311,
						columnNumber: 957
					}, this),
					/* @__PURE__ */ _jsxDEV("button", {
						className: "icon-button",
						onClick: () => onModal({
							type: "table",
							table
						}),
						"aria-label": `Edit ${table.name}`,
						title: "Edit table",
						children: /* @__PURE__ */ _jsxDEV(MoreHorizontal, { size: 18 }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 311,
							columnNumber: 1252
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 311,
						columnNumber: 1117
					}, this)
				]
			}, table.id, true, {
				fileName: _jsxFileName,
				lineNumber: 311,
				columnNumber: 436
			}, this))
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 311,
			columnNumber: 376
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 311,
		columnNumber: 10
	}, this);
}
_c13 = TablesSettings;
function StaffSettings({ data, onModal, onRefresh, onNotify }) {
	const toggle = async (user) => {
		try {
			await api.toggleStaff(user.id, !user.isActive);
			await onRefresh();
			onNotify(`${user.name} is now ${user.isActive ? "inactive" : "active"}.`);
		} catch (error) {
			onNotify(error.message, "error");
		}
	};
	return /* @__PURE__ */ _jsxDEV("section", {
		className: "settings-section",
		children: [/* @__PURE__ */ _jsxDEV("div", {
			className: "settings-section-head",
			children: [/* @__PURE__ */ _jsxDEV("div", { children: [
				/* @__PURE__ */ _jsxDEV("p", {
					className: "eyebrow",
					children: "People & access"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 316,
					columnNumber: 92
				}, this),
				/* @__PURE__ */ _jsxDEV("h2", { children: "Staff accounts" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 316,
					columnNumber: 134
				}, this),
				/* @__PURE__ */ _jsxDEV("p", {
					className: "section-subtitle",
					children: "Hosts operate the board. Managers own the room."
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 316,
					columnNumber: 157
				}, this)
			] }, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 316,
				columnNumber: 87
			}, this), /* @__PURE__ */ _jsxDEV("button", {
				className: "button button-primary",
				onClick: () => onModal({ type: "staff" }),
				children: [/* @__PURE__ */ _jsxDEV(Plus, { size: 16 }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 316,
					columnNumber: 331
				}, this), " Add staff"]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 316,
				columnNumber: 246
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 316,
			columnNumber: 48
		}, this), /* @__PURE__ */ _jsxDEV("div", {
			className: "inventory-list",
			children: data.users.map((user) => /* @__PURE__ */ _jsxDEV("div", {
				className: `inventory-row ${!user.isActive ? "is-inactive" : ""}`,
				children: [
					/* @__PURE__ */ _jsxDEV("div", {
						className: "avatar avatar-small",
						children: user.name.split(" ").map((part) => part[0]).join("")
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 316,
						columnNumber: 518
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "inventory-main",
						children: [/* @__PURE__ */ _jsxDEV("strong", { children: user.name }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 316,
							columnNumber: 647
						}, this), /* @__PURE__ */ _jsxDEV("span", { children: user.identifier }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 316,
							columnNumber: 675
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 316,
						columnNumber: 615
					}, this),
					/* @__PURE__ */ _jsxDEV("span", {
						className: `role-pill role-${user.role}`,
						children: user.role
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 316,
						columnNumber: 711
					}, this),
					/* @__PURE__ */ _jsxDEV("button", {
						className: `text-button ${user.isActive ? "danger-text" : ""}`,
						onClick: () => toggle(user),
						children: user.isActive ? "Disable" : "Enable"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 316,
						columnNumber: 777
					}, this)
				]
			}, user.id, true, {
				fileName: _jsxFileName,
				lineNumber: 316,
				columnNumber: 432
			}, this))
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 316,
			columnNumber: 374
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 316,
		columnNumber: 10
	}, this);
}
_c14 = StaffSettings;
function ModalShell({ title, eyebrow, children, onClose, wide = false }) {
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "modal-backdrop",
		role: "presentation",
		children: /* @__PURE__ */ _jsxDEV("div", {
			className: `modal ${wide ? "modal-wide" : ""}`,
			role: "dialog",
			"aria-modal": "true",
			"aria-label": title,
			children: [
				/* @__PURE__ */ _jsxDEV("button", {
					className: "modal-close icon-button",
					onClick: onClose,
					"aria-label": "Close dialog",
					children: /* @__PURE__ */ _jsxDEV(X, { size: 18 }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 320,
						columnNumber: 254
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 320,
					columnNumber: 166
				}, this),
				/* @__PURE__ */ _jsxDEV("p", {
					className: "eyebrow",
					children: eyebrow
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 320,
					columnNumber: 278
				}, this),
				/* @__PURE__ */ _jsxDEV("h2", { children: title }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 320,
					columnNumber: 314
				}, this),
				children
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 320,
			columnNumber: 62
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 320,
		columnNumber: 10
	}, this);
}
_c15 = ModalShell;
function PartyModal({ entry, entries, onClose, onSave }) {
	_s5();
	const [form, setForm] = useState({
		guestName: entry?.guestName || "",
		phone: entry?.phone || "",
		partySize: entry?.partySize || 2,
		seatingPreference: entry?.seatingPreference || "No preference",
		notes: entry?.notes || ""
	});
	const [busy, setBusy] = useState(false);
	const [errors, setErrors] = useState({});
	const duplicate = entries.some((candidate) => candidate.status === "waiting" && candidate.id !== entry?.id && candidate.phone.replace(/\D/g, "") === form.phone.replace(/\D/g, "") && form.phone.replace(/\D/g, "").length > 5);
	const update = (key, value) => setForm((current) => ({
		...current,
		[key]: value
	}));
	const submit = async (event) => {
		event.preventDefault();
		const nextErrors = {};
		if (!form.guestName.trim()) nextErrors.guestName = "Add the guest name.";
		if (form.phone.replace(/\D/g, "").length < 7) nextErrors.phone = "Add a valid phone number.";
		if (!Number.isInteger(Number(form.partySize)) || Number(form.partySize) < 1) nextErrors.partySize = "Use a whole number.";
		setErrors(nextErrors);
		if (Object.keys(nextErrors).length) return;
		setBusy(true);
		await onSave(form);
		setBusy(false);
	};
	return /* @__PURE__ */ _jsxDEV(ModalShell, {
		title: entry ? "Edit party" : "Add a party",
		eyebrow: entry ? "Update the line" : "New arrival",
		onClose,
		children: /* @__PURE__ */ _jsxDEV("form", {
			className: "modal-form",
			onSubmit: submit,
			children: [
				/* @__PURE__ */ _jsxDEV("div", {
					className: "form-grid",
					children: [
						/* @__PURE__ */ _jsxDEV(Field, {
							label: "Guest name",
							value: form.guestName,
							onChange: (value) => update("guestName", value),
							error: errors.guestName,
							autoFocus: true
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 341,
							columnNumber: 211
						}, this),
						/* @__PURE__ */ _jsxDEV(Field, {
							label: "Phone number",
							value: form.phone,
							onChange: (value) => update("phone", value),
							error: errors.phone,
							type: "tel"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 341,
							columnNumber: 346
						}, this),
						/* @__PURE__ */ _jsxDEV(Field, {
							label: "Party size",
							value: form.partySize,
							onChange: (value) => update("partySize", value),
							error: errors.partySize,
							type: "number",
							min: "1"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 341,
							columnNumber: 472
						}, this),
						/* @__PURE__ */ _jsxDEV(SelectField, {
							label: "Seating preference",
							value: form.seatingPreference,
							onChange: (value) => update("seatingPreference", value),
							options: preferenceOptions
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 341,
							columnNumber: 619
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 341,
					columnNumber: 184
				}, this),
				/* @__PURE__ */ _jsxDEV(Field, {
					label: "Notes for the floor",
					value: form.notes,
					onChange: (value) => update("notes", value),
					placeholder: "High chair, celebration, accessibility…"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 341,
					columnNumber: 783
				}, this),
				/* @__PURE__ */ _jsxDEV("div", { className: "modal-rule" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 341,
					columnNumber: 938
				}, this),
				duplicate && /* @__PURE__ */ _jsxDEV("div", {
					className: "duplicate-warning",
					children: [/* @__PURE__ */ _jsxDEV(BellRing, { size: 17 }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 341,
						columnNumber: 1017
					}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("strong", { children: "Another active party has this number." }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 341,
						columnNumber: 1044
					}, this), /* @__PURE__ */ _jsxDEV("span", { children: "You can still save this entry, but check the name before calling." }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 341,
						columnNumber: 1098
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 341,
						columnNumber: 1039
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 341,
					columnNumber: 982
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "modal-actions",
					children: [/* @__PURE__ */ _jsxDEV("button", {
						type: "button",
						className: "button button-ghost",
						onClick: onClose,
						children: "Back"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 341,
						columnNumber: 1220
					}, this), /* @__PURE__ */ _jsxDEV("button", {
						className: "button button-primary",
						disabled: busy,
						children: [
							busy ? "Saving…" : entry ? "Save changes" : "Add to waitlist",
							" ",
							/* @__PURE__ */ _jsxDEV(ArrowUpRight, { size: 16 }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 341,
								columnNumber: 1427
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 341,
						columnNumber: 1305
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 341,
					columnNumber: 1189
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 341,
			columnNumber: 137
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 341,
		columnNumber: 10
	}, this);
}
_s5(PartyModal, "W/ACVvnzIaNpQ/Ijy9eR1gUmtI8=");
_c16 = PartyModal;
function SeatModal({ entry, tables, entries, areas, onClose, onSeat }) {
	_s6();
	const [selected, setSelected] = useState("");
	const [busy, setBusy] = useState(false);
	const options = tables.filter((table) => table.isActive && table.availability === "available");
	const submit = async () => {
		if (!selected) return;
		setBusy(true);
		await onSeat(selected);
		setBusy(false);
	};
	return /* @__PURE__ */ _jsxDEV(ModalShell, {
		title: `Seat ${entry.guestName}`,
		eyebrow: "Choose a table",
		onClose,
		wide: true,
		children: [
			/* @__PURE__ */ _jsxDEV("div", {
				className: "seat-party-summary",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "seat-number",
					children: entry.partySize
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 349,
					columnNumber: 140
				}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("strong", { children: entry.guestName }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 349,
					columnNumber: 197
				}, this), /* @__PURE__ */ _jsxDEV("span", { children: [
					entry.partySize,
					" guests · ",
					entry.seatingPreference,
					" · waiting ",
					formatRelative(entry.createdAt).replace(" ago", "")
				] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 349,
					columnNumber: 231
				}, this)] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 349,
					columnNumber: 192
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 349,
				columnNumber: 104
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "table-choice-grid",
				children: options.map((table) => {
					const area = areas.find((candidate) => candidate.id === table.areaId)?.name;
					const fits = table.capacity >= entry.partySize;
					return /* @__PURE__ */ _jsxDEV("button", {
						type: "button",
						disabled: !fits,
						className: `table-choice ${selected === table.id ? "is-selected" : ""} ${!fits ? "is-too-small" : ""}`,
						onClick: () => setSelected(table.id),
						children: [
							/* @__PURE__ */ _jsxDEV("span", {
								className: "choice-check",
								children: selected === table.id && /* @__PURE__ */ _jsxDEV(Check, { size: 14 }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 349,
									columnNumber: 818
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 349,
								columnNumber: 761
							}, this),
							/* @__PURE__ */ _jsxDEV(Table2, { size: 22 }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 349,
								columnNumber: 845
							}, this),
							/* @__PURE__ */ _jsxDEV("strong", { children: table.name }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 349,
								columnNumber: 865
							}, this),
							/* @__PURE__ */ _jsxDEV("span", { children: [table.capacity, " seats"] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 349,
								columnNumber: 894
							}, this),
							/* @__PURE__ */ _jsxDEV("small", { children: area }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 349,
								columnNumber: 929
							}, this),
							!fits && /* @__PURE__ */ _jsxDEV("em", { children: "Too small" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 349,
								columnNumber: 960
							}, this)
						]
					}, table.id, true, {
						fileName: _jsxFileName,
						lineNumber: 349,
						columnNumber: 565
					}, this);
				})
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 349,
				columnNumber: 372
			}, this),
			options.length === 0 && /* @__PURE__ */ _jsxDEV("div", {
				className: "inline-empty",
				children: "There are no active tables available right now."
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 349,
				columnNumber: 1023
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "modal-actions",
				children: [/* @__PURE__ */ _jsxDEV("button", {
					type: "button",
					className: "button button-ghost",
					onClick: onClose,
					children: "Back"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 349,
					columnNumber: 1138
				}, this), /* @__PURE__ */ _jsxDEV("button", {
					className: "button button-primary",
					disabled: !selected || busy,
					onClick: submit,
					children: [
						busy ? "Seating…" : "Confirm table",
						" ",
						/* @__PURE__ */ _jsxDEV(Check, { size: 16 }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 349,
							columnNumber: 1349
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 349,
					columnNumber: 1223
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 349,
				columnNumber: 1107
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 349,
		columnNumber: 10
	}, this);
}
_s6(SeatModal, "SDa5MhgQ1eDMWP+IYwiyA8iwO1c=");
_c17 = SeatModal;
function TableModal({ table, areas, onClose, onSave }) {
	_s7();
	const [form, setForm] = useState({
		name: table?.name || "",
		capacity: table?.capacity || 2,
		areaId: table?.areaId || areas[0]?.id || "",
		isActive: table?.isActive ?? true
	});
	const submit = async (event) => {
		event.preventDefault();
		await onSave(form);
	};
	return /* @__PURE__ */ _jsxDEV(ModalShell, {
		title: table ? `Edit ${table.name}` : "Add a table",
		eyebrow: "Room inventory",
		onClose,
		children: /* @__PURE__ */ _jsxDEV("form", {
			className: "modal-form",
			onSubmit: submit,
			children: [
				/* @__PURE__ */ _jsxDEV("div", {
					className: "form-grid",
					children: [
						/* @__PURE__ */ _jsxDEV(Field, {
							label: "Table name",
							value: form.name,
							onChange: (value) => setForm({
								...form,
								name: value
							}),
							autoFocus: true
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 355,
							columnNumber: 192
						}, this),
						/* @__PURE__ */ _jsxDEV(Field, {
							label: "Capacity",
							type: "number",
							min: "1",
							value: form.capacity,
							onChange: (value) => setForm({
								...form,
								capacity: value
							})
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 355,
							columnNumber: 304
						}, this),
						/* @__PURE__ */ _jsxDEV(SelectField, {
							label: "Area",
							value: form.areaId,
							onChange: (value) => setForm({
								...form,
								areaId: value
							}),
							options: areas.map((area) => ({
								label: area.name,
								value: area.id
							}))
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 355,
							columnNumber: 434
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 355,
					columnNumber: 165
				}, this),
				table && /* @__PURE__ */ _jsxDEV("div", {
					className: "setting-toggle modal-toggle",
					children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("strong", { children: "Available for seating" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 355,
						columnNumber: 676
					}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Inactive tables stay in the inventory for reference." }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 355,
						columnNumber: 714
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 355,
						columnNumber: 671
					}, this), /* @__PURE__ */ _jsxDEV("button", {
						type: "button",
						className: `toggle ${form.isActive ? "is-on" : ""}`,
						onClick: () => setForm({
							...form,
							isActive: !form.isActive
						}),
						"aria-label": "Toggle table availability",
						children: /* @__PURE__ */ _jsxDEV("span", {}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 355,
							columnNumber: 962
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 355,
						columnNumber: 785
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 355,
					columnNumber: 626
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "modal-actions",
					children: [/* @__PURE__ */ _jsxDEV("button", {
						type: "button",
						className: "button button-ghost",
						onClick: onClose,
						children: "Back"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 355,
						columnNumber: 1017
					}, this), /* @__PURE__ */ _jsxDEV("button", {
						className: "button button-primary",
						children: [
							table ? "Save table" : "Add table",
							" ",
							/* @__PURE__ */ _jsxDEV(ArrowUpRight, { size: 16 }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 355,
								columnNumber: 1181
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 355,
						columnNumber: 1102
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 355,
					columnNumber: 986
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 355,
			columnNumber: 118
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 355,
		columnNumber: 10
	}, this);
}
_s7(TableModal, "7QhVIWdJkXITCv1Yfymf1+73TYg=");
_c18 = TableModal;
function StaffModal({ onClose, onSave }) {
	_s8();
	const [form, setForm] = useState({
		name: "",
		identifier: "",
		role: "host"
	});
	return /* @__PURE__ */ _jsxDEV(ModalShell, {
		title: "Add a staff account",
		eyebrow: "People & access",
		onClose,
		children: /* @__PURE__ */ _jsxDEV("form", {
			className: "modal-form",
			onSubmit: (event) => {
				event.preventDefault();
				onSave(form);
			},
			children: [
				/* @__PURE__ */ _jsxDEV(Field, {
					label: "Full name",
					value: form.name,
					onChange: (value) => setForm({
						...form,
						name: value
					}),
					autoFocus: true
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 360,
					columnNumber: 186
				}, this),
				/* @__PURE__ */ _jsxDEV(Field, {
					label: "Work email",
					type: "email",
					value: form.identifier,
					onChange: (value) => setForm({
						...form,
						identifier: value
					})
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 360,
					columnNumber: 297
				}, this),
				/* @__PURE__ */ _jsxDEV(SelectField, {
					label: "Role",
					value: form.role,
					onChange: (value) => setForm({
						...form,
						role: value
					}),
					options: [{
						label: "Host",
						value: "host"
					}, {
						label: "Manager",
						value: "manager"
					}]
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 360,
					columnNumber: 424
				}, this),
				/* @__PURE__ */ _jsxDEV("p", {
					className: "modal-hint",
					children: "A temporary password flow will be connected when the backend is added."
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 360,
					columnNumber: 611
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "modal-actions",
					children: [/* @__PURE__ */ _jsxDEV("button", {
						type: "button",
						className: "button button-ghost",
						onClick: onClose,
						children: "Back"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 360,
						columnNumber: 742
					}, this), /* @__PURE__ */ _jsxDEV("button", {
						className: "button button-primary",
						children: ["Create account ", /* @__PURE__ */ _jsxDEV(ArrowUpRight, { size: 16 }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 360,
							columnNumber: 884
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 360,
						columnNumber: 827
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 360,
					columnNumber: 711
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 360,
			columnNumber: 94
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 360,
		columnNumber: 10
	}, this);
}
_s8(StaffModal, "edb5MoIbD6GcqA4OGkIKbaPkdMw=");
_c19 = StaffModal;
function ConfirmModal({ title, description, confirmLabel, onClose, onConfirm }) {
	_s9();
	const [busy, setBusy] = useState(false);
	const confirm = async () => {
		setBusy(true);
		await onConfirm();
		setBusy(false);
	};
	return /* @__PURE__ */ _jsxDEV(ModalShell, {
		title,
		eyebrow: "Please confirm",
		onClose,
		children: [/* @__PURE__ */ _jsxDEV("p", {
			className: "confirm-copy",
			children: description
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 366,
			columnNumber: 79
		}, this), /* @__PURE__ */ _jsxDEV("div", {
			className: "modal-actions",
			children: [/* @__PURE__ */ _jsxDEV("button", {
				className: "button button-ghost",
				onClick: onClose,
				children: "Keep party"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 366,
				columnNumber: 155
			}, this), /* @__PURE__ */ _jsxDEV("button", {
				className: "button button-danger",
				onClick: confirm,
				disabled: busy,
				children: [
					busy ? "Updating…" : confirmLabel,
					" ",
					/* @__PURE__ */ _jsxDEV(X, { size: 16 }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 366,
						columnNumber: 343
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 366,
				columnNumber: 232
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 366,
			columnNumber: 124
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 366,
		columnNumber: 10
	}, this);
}
_s9(ConfirmModal, "1xb9mZubXs1SxY/cOnjkSF8CKNw=");
_c20 = ConfirmModal;
function Field({ label, value, onChange, type = "text", error, placeholder, ...props }) {
	return /* @__PURE__ */ _jsxDEV("label", {
		className: "field",
		children: [
			/* @__PURE__ */ _jsxDEV("span", { children: label }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 369,
				columnNumber: 123
			}, this),
			/* @__PURE__ */ _jsxDEV("input", {
				...props,
				type,
				value,
				placeholder,
				onChange: (event) => onChange(event.target.value)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 369,
				columnNumber: 143
			}, this),
			/* @__PURE__ */ _jsxDEV(_Fragment, { children: error && /* @__PURE__ */ _jsxDEV("small", {
				className: "field-error",
				children: error
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 369,
				columnNumber: 278
			}, this) }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 369,
				columnNumber: 266
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 369,
		columnNumber: 98
	}, this);
}
_c21 = Field;
function SelectField({ label, value, onChange, options }) {
	return /* @__PURE__ */ _jsxDEV("label", {
		className: "field",
		children: [/* @__PURE__ */ _jsxDEV("span", { children: label }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 370,
			columnNumber: 93
		}, this), /* @__PURE__ */ _jsxDEV("div", {
			className: "select-wrap",
			children: [/* @__PURE__ */ _jsxDEV("select", {
				value: typeof options[0] === "string" ? value : value,
				onChange: (event) => onChange(event.target.value),
				children: options.map((option) => {
					const normalized = typeof option === "string" ? {
						label: option,
						value: option
					} : option;
					return /* @__PURE__ */ _jsxDEV("option", {
						value: normalized.value,
						children: normalized.label
					}, normalized.value, false, {
						fileName: _jsxFileName,
						lineNumber: 370,
						columnNumber: 381
					}, this);
				})
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 370,
				columnNumber: 142
			}, this), /* @__PURE__ */ _jsxDEV(ChevronDown, { size: 16 }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 370,
				columnNumber: 477
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 370,
			columnNumber: 113
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 370,
		columnNumber: 68
	}, this);
}
_c22 = SelectField;
export default App;
var _c, _c2, _c3, _c4, _c5, _c6, _c7, _c8, _c9, _c10, _c11, _c12, _c13, _c14, _c15, _c16, _c17, _c18, _c19, _c20, _c21, _c22;
$RefreshReg$(_c, "App");
$RefreshReg$(_c2, "NavItem");
$RefreshReg$(_c3, "LoadingScreen");
$RefreshReg$(_c4, "LoginScreen");
$RefreshReg$(_c5, "WaitlistView");
$RefreshReg$(_c6, "Metric");
$RefreshReg$(_c7, "QueueRow");
$RefreshReg$(_c8, "EmptyQueue");
$RefreshReg$(_c9, "HistoryView");
$RefreshReg$(_c10, "HistoryRow");
$RefreshReg$(_c11, "EmptyHistory");
$RefreshReg$(_c12, "SettingsView");
$RefreshReg$(_c13, "TablesSettings");
$RefreshReg$(_c14, "StaffSettings");
$RefreshReg$(_c15, "ModalShell");
$RefreshReg$(_c16, "PartyModal");
$RefreshReg$(_c17, "SeatModal");
$RefreshReg$(_c18, "TableModal");
$RefreshReg$(_c19, "StaffModal");
$RefreshReg$(_c20, "ConfirmModal");
$RefreshReg$(_c21, "Field");
$RefreshReg$(_c22, "SelectField");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/App.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/DATA/Cursos/ai-dev-tools/Final_Project/frontend/src/App.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/DATA/Cursos/ai-dev-tools/Final_Project/frontend/src/App.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/DATA/Cursos/ai-dev-tools/Final_Project/frontend/src/App.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxXQUFXLFNBQVMsZ0JBQWdCO0FBQzdDLFNBQ0UsY0FDQSxLQUNBLFVBQ0EsT0FDQSxhQUNBLGlCQUNBLFFBQ0EsVUFDQSxPQUNBLFlBQ0EsUUFDQSxNQUNBLGdCQUNBLE1BQ0EsV0FDQSxhQUNBLFVBQ0EsUUFDQSxZQUNBLFNBQ0s7QUFDUCxTQUFTLGNBQWMsV0FBVzs7OztBQUVsQyxNQUFNLG9CQUFvQjtDQUFDO0NBQWlCO0NBQWU7Q0FBUztBQUFLO0FBRXpFLE1BQU0sY0FBYyxVQUFVLElBQUksS0FBSyxlQUFlLFNBQVM7Q0FBRSxNQUFNO0NBQVcsUUFBUTtBQUFVLENBQUMsQ0FBQyxDQUFDLE9BQU8sSUFBSSxLQUFLLEtBQUssQ0FBQztBQUM3SCxNQUFNLGNBQWMsUUFBUSxJQUFJLEtBQUssTUFBTSxJQUFJLEtBQUssZUFBZSxTQUFTO0NBQUUsU0FBUztDQUFRLE9BQU87Q0FBUSxLQUFLO0FBQVUsQ0FBQyxDQUFDLENBQUMsT0FBTyxJQUFJLEtBQUssS0FBSyxDQUFDO0FBQ3RKLE1BQU0sa0JBQWtCLFVBQVU7Q0FDaEMsTUFBTSxVQUFVLEtBQUssSUFBSSxHQUFHLEtBQUssT0FBTyxLQUFLLElBQUksSUFBSSxJQUFJLEtBQUssS0FBSyxDQUFDLENBQUMsUUFBUSxLQUFLLEdBQUssQ0FBQztDQUN4RixJQUFJLFVBQVUsR0FBRyxPQUFPO0NBQ3hCLElBQUksWUFBWSxHQUFHLE9BQU87Q0FDMUIsT0FBTyxHQUFHLFFBQVE7QUFDcEI7QUFFQSxTQUFTLE1BQU07O0NBQ2IsTUFBTSxDQUFDLFNBQVMsY0FBYyxlQUFlLElBQUksV0FBVyxDQUFDO0NBQzdELE1BQU0sQ0FBQyxNQUFNLFdBQVcsU0FBUyxJQUFJO0NBQ3JDLE1BQU0sQ0FBQyxNQUFNLFdBQVcsU0FBUyxVQUFVO0NBQzNDLE1BQU0sQ0FBQyxTQUFTLGNBQWMsU0FBUyxRQUFRLE9BQU8sQ0FBQztDQUN2RCxNQUFNLENBQUMsT0FBTyxZQUFZLFNBQVMsSUFBSTtDQUN2QyxNQUFNLENBQUMsT0FBTyxZQUFZLFNBQVMsSUFBSTtDQUN2QyxNQUFNLENBQUMsYUFBYSxrQkFBa0IsU0FBUyxLQUFLO0NBRXBELE1BQU0sVUFBVSxZQUFZO0VBQzFCLE1BQU0sWUFBWSxNQUFNLElBQUksYUFBYTtFQUN6QyxRQUFRLFNBQVM7Q0FDbkI7Q0FFQSxnQkFBZ0I7RUFDZCxJQUFJLENBQUMsU0FBUyxPQUFPO0VBQ3JCLElBQUksVUFBVTtFQUNkLFdBQVcsSUFBSTtFQUNmLElBQUksYUFBYSxDQUFDLENBQUMsTUFBTSxjQUFjO0dBQ3JDLElBQUksU0FBUztJQUNYLFFBQVEsU0FBUztJQUNqQixXQUFXLEtBQUs7R0FDbEI7RUFDRixDQUFDLENBQUMsQ0FBQyxPQUFPLFVBQVU7R0FDbEIsSUFBSSxDQUFDLFNBQVM7R0FDZCxXQUFXLEtBQUs7R0FDaEIsSUFBSSxNQUFNLFdBQVcsS0FBSztJQUN4QixJQUFJLGFBQWE7SUFDakIsV0FBVyxJQUFJO0lBQ2YsUUFBUSxJQUFJO0dBQ2QsT0FBTztJQUNMLE9BQU8sTUFBTSxTQUFTLE9BQU87R0FDL0I7RUFDRixDQUFDO0VBQ0QsYUFBYTtHQUFFLFVBQVU7RUFBTTtDQUNqQyxHQUFHLENBQUMsT0FBTyxDQUFDO0NBRVosZ0JBQWdCO0VBQ2QsSUFBSSxDQUFDLE9BQU8sT0FBTztFQUNuQixNQUFNLFVBQVUsT0FBTyxpQkFBaUIsU0FBUyxJQUFJLEdBQUcsSUFBSTtFQUM1RCxhQUFhLE9BQU8sYUFBYSxPQUFPO0NBQzFDLEdBQUcsQ0FBQyxLQUFLLENBQUM7Q0FFVixNQUFNLFVBQVUsU0FBUyxPQUFPLGNBQWMsU0FBUztFQUFFO0VBQVM7Q0FBSyxDQUFDO0NBRXhFLE1BQU0sY0FBYyxPQUFPLGdCQUFnQjtFQUN6QyxJQUFJO0dBQ0YsTUFBTSxjQUFjLE1BQU0sSUFBSSxNQUFNLFdBQVc7R0FDL0MsV0FBVyxXQUFXO0dBQ3RCLE9BQU8saUJBQWlCLFlBQVksS0FBSyxNQUFNLEdBQUcsQ0FBQyxDQUFDLEdBQUcsRUFBRTtFQUMzRCxTQUFTLE9BQU87R0FDZCxNQUFNO0VBQ1I7Q0FDRjtDQUVBLE1BQU0scUJBQXFCO0VBQ3pCLEtBQUssSUFBSSxPQUFPO0VBQ2hCLFdBQVcsSUFBSTtFQUNmLFFBQVEsSUFBSTtFQUNaLFFBQVEsVUFBVTtDQUNwQjtDQUVBLE1BQU0sY0FBYyxPQUFPLFFBQVEsbUJBQW1CO0VBQ3BELElBQUk7R0FDRixNQUFNLE9BQU87R0FDYixNQUFNLFFBQVE7R0FDZCxTQUFTLElBQUk7R0FDYixPQUFPLGNBQWM7RUFDdkIsU0FBUyxPQUFPO0dBQ2QsSUFBSSxNQUFNLFdBQVcsS0FBSztJQUN4QixJQUFJLGFBQWE7SUFDakIsV0FBVyxJQUFJO0lBQ2YsUUFBUSxJQUFJO0dBQ2QsT0FBTztJQUNMLE9BQU8sTUFBTSxTQUFTLE9BQU87R0FDL0I7RUFDRjtDQUNGO0NBRUEsSUFBSSxDQUFDLFNBQVMsT0FBTyx3QkFBQyxhQUFELEVBQWEsU0FBUyxZQUFjOzs7OztDQUN6RCxJQUFJLFdBQVcsQ0FBQyxNQUFNLE9BQU8sd0JBQUMsZUFBRCxDQUFnQjs7Ozs7Q0FFN0MsTUFBTSxjQUFjLEtBQUssUUFBUSxRQUFRLFVBQVUsTUFBTSxXQUFXLFNBQVMsQ0FBQyxDQUFDO0NBQy9FLE1BQU0sbUJBQW1CLElBQUksSUFBSSxLQUFLLE9BQU8sUUFBUSxVQUFVLE1BQU0saUJBQWlCLFVBQVUsQ0FBQyxDQUFDLEtBQUssVUFBVSxNQUFNLEVBQUUsQ0FBQztDQUMxSCxNQUFNLGlCQUFpQixLQUFLLE9BQU8sUUFBUSxVQUFVLE1BQU0sWUFBWSxNQUFNLGlCQUFpQixXQUFXLENBQUMsQ0FBQztDQUUzRyxPQUNFLHdCQUFDLE9BQUQ7RUFBSyxXQUFVO1lBQWY7R0FDRSx3QkFBQyxTQUFEO0lBQU8sV0FBVyxXQUFXLGNBQWMsWUFBWTtjQUF2RDtLQUNFLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmO09BQ0Usd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWYsQ0FBNEIsd0JBQUMsUUFBRCxZQUFNLElBQU87Ozs7a0JBQUMsd0JBQUMsUUFBRCxZQUFNLElBQU87Ozs7Z0JBQU07Ozs7OztPQUM3RCx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWE7T0FBYzs7OztpQkFDMUMsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWlCO09BQWdCOzs7O2VBQzdDOzs7OztPQUNMLHdCQUFDLFVBQUQ7UUFBUSxXQUFVO1FBQTRCLGVBQWUsZUFBZSxLQUFLO1FBQUcsY0FBVztrQkFBbUIsd0JBQUMsR0FBRCxFQUFHLE1BQU0sR0FBSzs7Ozs7T0FBUzs7Ozs7TUFDdEk7Ozs7OztLQUNMLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmO09BQ0Usd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWYsQ0FBZ0Msd0JBQUMsUUFBRCxFQUFNLFdBQVUsV0FBWTs7OztrQkFBQyxlQUFrQjs7Ozs7O09BQy9FLHdCQUFDLFVBQUQsWUFBUyxLQUFLLFdBQVcsYUFBcUI7Ozs7O09BQzlDLHdCQUFDLFFBQUQ7UUFBTSxXQUFVO2tCQUFnQixXQUFXO09BQVE7Ozs7O09BQ25ELHdCQUFDLGFBQUQsRUFBYSxNQUFNLEdBQUs7Ozs7O01BQ3JCOzs7Ozs7S0FDTCx3QkFBQyxPQUFEO01BQUssV0FBVTtNQUFjLGNBQVc7Z0JBQXhDO09BQ0Usd0JBQUMsU0FBRDtRQUFTLE1BQU0sd0JBQUMsWUFBRCxFQUFZLE1BQU0sR0FBSzs7Ozs7UUFBRyxPQUFNO1FBQVcsUUFBUSxTQUFTO1FBQVksZUFBZTtTQUFFLFFBQVEsVUFBVTtTQUFHLGVBQWUsS0FBSztRQUFFO1FBQUcsT0FBTztPQUFjOzs7OztPQUMzSyx3QkFBQyxTQUFEO1FBQVMsTUFBTSx3QkFBQyxRQUFELEVBQVEsTUFBTSxHQUFLOzs7OztRQUFHLE9BQU07UUFBa0IsUUFBUSxTQUFTO1FBQVcsZUFBZTtTQUFFLFFBQVEsU0FBUztTQUFHLGVBQWUsS0FBSztRQUFFO09BQUk7Ozs7O09BQ3ZKLFFBQVEsU0FBUyxhQUFhLHdCQUFDLFNBQUQ7UUFBUyxNQUFNLHdCQUFDLFdBQUQsRUFBVyxNQUFNLEdBQUs7Ozs7O1FBQUcsT0FBTTtRQUFtQixRQUFRLFNBQVM7UUFBWSxlQUFlO1NBQUUsUUFBUSxVQUFVO1NBQUcsZUFBZSxLQUFLO1FBQUU7T0FBSTs7Ozs7TUFDMUw7Ozs7OztLQUNMLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmLENBQ0Usd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FBOEIsd0JBQUMsVUFBRCxFQUFVLE1BQU0sR0FBSzs7OztpQkFBQyx3QkFBQyxRQUFELFlBQU0sd0JBQTJCOzs7O2VBQU07Ozs7O2dCQUMzRix3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZjtRQUNFLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUFVLFFBQVEsS0FBSyxNQUFNLEdBQUcsQ0FBQyxDQUFDLEtBQUssU0FBUyxLQUFLLEVBQUUsQ0FBQyxDQUFDLEtBQUssRUFBRTtRQUFPOzs7OztRQUN0Rix3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBZixDQUE4Qix3QkFBQyxVQUFELFlBQVMsUUFBUSxLQUFhOzs7O21CQUFDLHdCQUFDLFFBQUQsWUFBTyxRQUFRLEtBQVc7Ozs7aUJBQU07Ozs7OztRQUM3Rix3QkFBQyxVQUFEO1NBQVEsV0FBVTtTQUFjLFNBQVM7U0FBYyxjQUFXO1NBQVcsT0FBTTttQkFBVyx3QkFBQyxRQUFELEVBQVEsTUFBTSxHQUFLOzs7OztRQUFTOzs7OztPQUN2SDs7Ozs7Y0FDRjs7Ozs7O0lBQ0E7Ozs7OztHQUNOLGVBQWUsd0JBQUMsVUFBRDtJQUFRLFdBQVU7SUFBZ0IsZUFBZSxlQUFlLEtBQUs7SUFBRyxjQUFXO0dBQW9COzs7OztHQUN2SCx3QkFBQyxRQUFEO0lBQU0sV0FBVTtjQUFoQixDQUNFLHdCQUFDLFVBQUQ7S0FBUSxXQUFVO2VBQWxCO01BQ0Usd0JBQUMsVUFBRDtPQUFRLFdBQVU7T0FBMEIsZUFBZSxlQUFlLElBQUk7T0FBRyxjQUFXO2lCQUFrQix3QkFBQyxNQUFELEVBQU0sTUFBTSxHQUFLOzs7OztNQUFTOzs7OztNQUN4SSx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZjtRQUF1Qix3QkFBQyxRQUFELFlBQU0sYUFBZ0I7Ozs7O1FBQUMsd0JBQUMsUUFBRDtTQUFNLFdBQVU7bUJBQWM7UUFBTzs7Ozs7UUFBQyx3QkFBQyxVQUFELFlBQVMsU0FBUyxhQUFhLGFBQWEsU0FBUyxZQUFZLG9CQUFvQixtQkFBMkI7Ozs7O09BQU07Ozs7OztNQUMxTSx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZjtRQUNFLHdCQUFDLE9BQUQ7U0FBSyxXQUFXLGFBQWEsS0FBSyxXQUFXLFNBQVMsWUFBWTttQkFBbEU7VUFBaUYsd0JBQUMsUUFBRCxFQUFNLFdBQVUsZ0JBQWlCOzs7OztVQUFDO1VBQUUsS0FBSyxXQUFXLFNBQVMsYUFBYTtTQUFjOzs7Ozs7UUFDekssd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQWUsV0FBVztRQUFPOzs7OztRQUNoRCx3QkFBQyxVQUFEO1NBQVEsV0FBVTtTQUFzQixjQUFXO21CQUFtQixRQUFRLEtBQUssTUFBTSxHQUFHLENBQUMsQ0FBQyxLQUFLLFNBQVMsS0FBSyxFQUFFLENBQUMsQ0FBQyxLQUFLLEVBQUU7UUFBVTs7Ozs7T0FDbkk7Ozs7OztLQUNDOzs7OztjQUNSLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWY7TUFDRyxTQUFTLGNBQWMsd0JBQUMsY0FBRDtPQUFvQjtPQUFNLGFBQWEsU0FBUyxFQUFFLE1BQU0sUUFBUSxDQUFDO09BQUcsU0FBUyxVQUFVLFNBQVM7UUFBRSxNQUFNO1FBQVM7T0FBTSxDQUFDO09BQUcsU0FBUyxVQUFVLFNBQVM7UUFBRSxNQUFNO1FBQVE7T0FBTSxDQUFDO09BQUcsV0FBVyxVQUFVLFNBQVM7UUFBRSxNQUFNO1FBQVU7T0FBTSxDQUFDO09BQUcsaUJBQWlCLFVBQVUsU0FBUztRQUFFLE1BQU07UUFBaUI7T0FBTSxDQUFDO01BQUk7Ozs7O01BQzFVLFNBQVMsYUFBYSx3QkFBQyxhQUFEO09BQW1CO09BQU0saUJBQWlCLFVBQVUsU0FBUztRQUFFLE1BQU07UUFBaUI7T0FBTSxDQUFDO01BQUk7Ozs7O01BQ3ZILFNBQVMsY0FBYyxRQUFRLFNBQVMsYUFBYSx3QkFBQyxjQUFEO09BQW9CO09BQU0sV0FBVztPQUFTLFVBQVU7T0FBUSxTQUFTO01BQVc7Ozs7O0tBQ3ZJOzs7OztZQUNEOzs7Ozs7R0FDTCxPQUFPLFNBQVMsV0FBVyx3QkFBQyxZQUFEO0lBQVksT0FBTyxNQUFNO0lBQU8sU0FBUyxLQUFLO0lBQVMsZUFBZSxTQUFTLElBQUk7SUFBRyxTQUFTLFlBQVksa0JBQWtCLE1BQU0sUUFBUSxJQUFJLFlBQVksTUFBTSxNQUFNLElBQUksU0FBUyxPQUFPLElBQUksSUFBSSxZQUFZLFNBQVMsT0FBTyxHQUFHLE1BQU0sUUFBUSwyQkFBMkIsOEJBQThCO0dBQUk7Ozs7O0dBQ3hVLE9BQU8sU0FBUyxVQUFVLHdCQUFDLFdBQUQ7SUFBVyxPQUFPLE1BQU07SUFBTyxRQUFRLEtBQUs7SUFBUSxTQUFTLEtBQUs7SUFBUyxPQUFPLEtBQUs7SUFBTyxlQUFlLFNBQVMsSUFBSTtJQUFHLFNBQVMsWUFBWSxrQkFBa0IsSUFBSSxVQUFVLE1BQU0sTUFBTSxJQUFJLFNBQVMsT0FBTyxHQUFHLEdBQUcsTUFBTSxNQUFNLFVBQVUsWUFBWTtHQUFJOzs7OztHQUN4UixPQUFPLFNBQVMsWUFBWSx3QkFBQyxjQUFEO0lBQWMsT0FBTTtJQUFxQixhQUFhLEdBQUcsTUFBTSxNQUFNLFVBQVU7SUFBNkUsY0FBYTtJQUFlLGVBQWUsU0FBUyxJQUFJO0lBQUcsaUJBQWlCLGtCQUFrQixJQUFJLFlBQVksTUFBTSxNQUFNLElBQUksT0FBTyxHQUFHLEdBQUcsTUFBTSxNQUFNLFVBQVUsZ0JBQWdCO0dBQUk7Ozs7O0dBQzdXLE9BQU8sU0FBUyxXQUFXLHdCQUFDLFlBQUQ7SUFBWSxPQUFPLE1BQU07SUFBTyxPQUFPLEtBQUs7SUFBTyxlQUFlLFNBQVMsSUFBSTtJQUFHLFNBQVMsWUFBWSxrQkFBa0IsTUFBTSxRQUFRLElBQUksWUFBWSxNQUFNLE1BQU0sSUFBSSxPQUFPLElBQUksSUFBSSxZQUFZLE9BQU8sR0FBRyxNQUFNLFFBQVEsMkJBQTJCLDBCQUEwQjtHQUFJOzs7OztHQUM5UyxPQUFPLFNBQVMsV0FBVyx3QkFBQyxZQUFEO0lBQVksZUFBZSxTQUFTLElBQUk7SUFBRyxTQUFTLFlBQVksa0JBQWtCLElBQUksWUFBWSxPQUFPLEdBQUcsd0JBQXdCO0dBQUk7Ozs7O0dBQ25LLE9BQU8sU0FBUyxtQkFBbUIsd0JBQUMsY0FBRDtJQUFjLE9BQU8sUUFBUSxNQUFNLE1BQU0sS0FBSztJQUFZLGFBQWEsTUFBTSxNQUFNLGVBQWUsR0FBRyxNQUFNLE1BQU0sYUFBYSxVQUFVLFlBQVksTUFBTSxNQUFNLGFBQWEsVUFBVSxvQ0FBb0MsTUFBTSxNQUFNLEtBQUssMkRBQTJELGNBQWMsTUFBTSxNQUFNLEtBQUs7SUFBcUMsY0FBYTtJQUFrQixlQUFlLFNBQVMsSUFBSTtJQUFHLGlCQUFpQixrQkFBa0IsSUFBSSxhQUFhLE1BQU0sTUFBTSxFQUFFLEdBQUcsU0FBUyxNQUFNLE1BQU0sS0FBSyxjQUFjO0dBQUk7Ozs7O0dBQzdqQixTQUFTLHdCQUFDLE9BQUQ7SUFBSyxXQUFXLGVBQWUsTUFBTTtJQUFRLE1BQUs7Y0FBbEQsQ0FBMkQsd0JBQUMsUUFBRDtLQUFNLFdBQVU7ZUFBYyxNQUFNLFNBQVMsVUFBVSx3QkFBQyxLQUFELEVBQUssTUFBTSxHQUFLOzs7O2dCQUFJLHdCQUFDLE9BQUQsRUFBTyxNQUFNLEdBQUs7Ozs7O0lBQVE7Ozs7Y0FBRSxNQUFNLE9BQWE7Ozs7OztFQUM1TDs7Ozs7O0FBRVQ7OztBQUVBLFNBQVMsUUFBUSxFQUFFLE1BQU0sT0FBTyxRQUFRLFNBQVMsU0FBUztDQUN4RCxPQUFPLHdCQUFDLFVBQUQ7RUFBUSxXQUFXLFlBQVksU0FBUyxjQUFjO0VBQWU7WUFBckU7R0FBK0U7R0FBSyx3QkFBQyxRQUFELFlBQU8sTUFBWTs7Ozs7R0FBRSxRQUFRLEtBQUssd0JBQUMsUUFBRDtJQUFNLFdBQVU7Y0FBYTtHQUFZOzs7OztFQUFVOzs7Ozs7QUFDbEw7O0FBRUEsU0FBUyxnQkFBZ0I7Q0FDdkIsT0FBTyx3QkFBQyxPQUFEO0VBQUssV0FBVTtZQUFmLENBQWdDLHdCQUFDLE9BQUQ7R0FBSyxXQUFVO2FBQWdCLHdCQUFDLFFBQUQsQ0FBTzs7Ozs7RUFBTTs7OztZQUFDLHdCQUFDLFFBQUQsWUFBTSw0QkFBK0I7Ozs7VUFBTTs7Ozs7O0FBQ2pJOztBQUVBLFNBQVMsWUFBWSxFQUFFLFdBQVc7O0NBQ2hDLE1BQU0sQ0FBQyxZQUFZLGlCQUFpQixTQUFTLHNCQUFzQjtDQUNuRSxNQUFNLENBQUMsVUFBVSxlQUFlLFNBQVMsVUFBVTtDQUNuRCxNQUFNLENBQUMsTUFBTSxXQUFXLFNBQVMsS0FBSztDQUN0QyxNQUFNLENBQUMsT0FBTyxZQUFZLFNBQVMsRUFBRTtDQUVyQyxNQUFNLFNBQVMsT0FBTyxVQUFVO0VBQzlCLE1BQU0sZUFBZTtFQUNyQixRQUFRLElBQUk7RUFDWixTQUFTLEVBQUU7RUFDWCxJQUFJO0dBQ0YsTUFBTSxRQUFRO0lBQUU7SUFBWTtHQUFTLENBQUM7RUFDeEMsU0FBUyxZQUFZO0dBQ25CLFNBQVMsV0FBVyxPQUFPO0VBQzdCLFVBQVU7R0FDUixRQUFRLEtBQUs7RUFDZjtDQUNGO0NBRUEsT0FBTyx3QkFBQyxPQUFEO0VBQUssV0FBVTtZQUFmO0dBQ0wsd0JBQUMsT0FBRCxFQUFLLFdBQVUsNEJBQTZCOzs7OztHQUFDLHdCQUFDLE9BQUQsRUFBSyxXQUFVLDRCQUE2Qjs7Ozs7R0FDekYsd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZjtLQUNFLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmLENBQTZCLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQTRCLHdCQUFDLFFBQUQsWUFBTSxJQUFPOzs7O2lCQUFDLHdCQUFDLFFBQUQsWUFBTSxJQUFPOzs7O2VBQU07Ozs7O2dCQUFDLHdCQUFDLFFBQUQsWUFBTSxZQUFlOzs7O2NBQU07Ozs7OztLQUN0SCx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZjtPQUE0Qix3QkFBQyxLQUFEO1FBQUcsV0FBVTtrQkFBVTtPQUFtQzs7Ozs7T0FBQyx3QkFBQyxNQUFEO1FBQUk7UUFBVSx3QkFBQyxNQUFELENBQUs7Ozs7O1FBQUMsd0JBQUMsTUFBRCxZQUFJLE9BQVE7Ozs7O1FBQUM7T0FBVzs7Ozs7T0FBQyx3QkFBQyxLQUFELFlBQUcsd0VBQXdFOzs7OztNQUFNOzs7Ozs7S0FDck4sd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWY7T0FBOEIsd0JBQUMsUUFBRCxZQUFNLGtCQUFxQjs7Ozs7T0FBQyx3QkFBQyxRQUFELEVBQU0sV0FBVSxvQkFBcUI7Ozs7O09BQUMsd0JBQUMsUUFBRCxZQUFNLGVBQWtCOzs7OztNQUFNOzs7Ozs7SUFDM0g7Ozs7OztHQUNMLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQW1CLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWY7TUFDaEMsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FBOEIsd0JBQUMsYUFBRCxFQUFhLE1BQU0sR0FBSzs7OztpQkFBQyxnQkFBbUI7Ozs7OztNQUMxRSx3QkFBQyxNQUFELFlBQUksZ0JBQWlCOzs7OztNQUFDLHdCQUFDLEtBQUQ7T0FBRyxXQUFVO2lCQUFjO01BQTJDOzs7OztNQUM1Rix3QkFBQyxRQUFEO09BQU0sVUFBVTtPQUFRLFdBQVU7aUJBQWxDO1FBQ0Usd0JBQUMsT0FBRDtTQUFPLE9BQU07U0FBYSxPQUFPO1NBQVksVUFBVTtTQUFlLE1BQUs7U0FBUSxjQUFhO1FBQVk7Ozs7O1FBQzVHLHdCQUFDLE9BQUQ7U0FBTyxPQUFNO1NBQVcsT0FBTztTQUFVLFVBQVU7U0FBYSxNQUFLO1NBQVcsY0FBYTtRQUFvQjs7Ozs7UUFDaEgsU0FBUyx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBZixDQUE0Qix3QkFBQyxLQUFELEVBQUssTUFBTSxHQUFLOzs7O21CQUFFLEtBQVc7Ozs7OztRQUNuRSx3QkFBQyxVQUFEO1NBQVEsV0FBVTtTQUFvQyxVQUFVO21CQUFoRTtVQUF1RSxPQUFPLG1CQUFtQjtVQUFzQjtVQUFDLHdCQUFDLGNBQUQsRUFBYyxNQUFNLEdBQUs7Ozs7O1NBQVM7Ozs7OztPQUN0Sjs7Ozs7O01BQ04sd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWY7UUFBK0Isd0JBQUMsUUFBRCxZQUFNLGNBQWlCOzs7OztRQUFDLHdCQUFDLFVBQUQ7U0FBUSxNQUFLO1NBQVMsZUFBZTtVQUFFLGNBQWMsc0JBQXNCO1VBQUcsWUFBWSxVQUFVO1NBQUU7bUJBQUc7UUFBZTs7Ozs7UUFBQyx3QkFBQyxVQUFEO1NBQVEsTUFBSztTQUFTLGVBQWU7VUFBRSxjQUFjLHNCQUFzQjtVQUFHLFlBQVksVUFBVTtTQUFFO21CQUFHO1FBQVk7Ozs7O09BQU07Ozs7OztLQUN4Uzs7Ozs7O0dBQU07Ozs7O0VBQ1I7Ozs7OztBQUNQOzs7QUFFQSxTQUFTLGFBQWEsRUFBRSxNQUFNLE9BQU8sUUFBUSxRQUFRLFVBQVUsa0JBQWtCOztDQUMvRSxNQUFNLENBQUMsUUFBUSxhQUFhLFNBQVMsS0FBSztDQUMxQyxNQUFNLFVBQVUsS0FBSyxRQUFRLFFBQVEsVUFBVSxNQUFNLFdBQVcsU0FBUztDQUN6RSxNQUFNLFNBQVMsS0FBSyxRQUFRLFFBQVEsVUFBVSxNQUFNLFdBQVcsUUFBUSxDQUFDLENBQUM7Q0FDekUsTUFBTSxZQUFZLEtBQUssT0FBTyxRQUFRLFVBQVUsTUFBTSxZQUFZLE1BQU0saUJBQWlCLFdBQVcsQ0FBQyxDQUFDO0NBQ3RHLE1BQU0sVUFBVSxXQUFXLFFBQVEsVUFBVSxRQUFRLFFBQVEsVUFBVSxNQUFNLHNCQUFzQixNQUFNO0NBQ3pHLE1BQU0sU0FBUyxRQUFRO0NBRXZCLE9BQU87RUFDTCx3QkFBQyxXQUFEO0dBQVMsV0FBVTthQUFuQixDQUNFLHdCQUFDLE9BQUQ7SUFBSyx3QkFBQyxLQUFEO0tBQUcsV0FBVTtlQUFiO01BQXVCLHdCQUFDLFFBQUQsRUFBTSxXQUFVLGdCQUFpQjs7Ozs7TUFBQztNQUFpQixLQUFLLFdBQVc7S0FBZ0I7Ozs7OztJQUFDLHdCQUFDLE1BQUQsYUFBSSx3QkFBb0Isd0JBQUMsUUFBRDtLQUFNLFdBQVU7ZUFBUztJQUFPOzs7O1lBQUs7Ozs7O0lBQUMsd0JBQUMsS0FBRDtLQUFHLFdBQVU7ZUFBbUI7SUFBbUU7Ozs7O0dBQU07Ozs7YUFDdlIsd0JBQUMsVUFBRDtJQUFRLFdBQVU7SUFBbUMsU0FBUztjQUE5RCxDQUFxRSx3QkFBQyxNQUFELEVBQU0sTUFBTSxHQUFLOzs7O2NBQUMsWUFBa0I7Ozs7O1dBQ2xHOzs7Ozs7RUFDVCx3QkFBQyxXQUFEO0dBQVMsV0FBVTtHQUFlLGNBQVc7YUFBN0M7SUFDRSx3QkFBQyxRQUFEO0tBQVEsT0FBTTtLQUFjLE9BQU8sUUFBUTtLQUFRLFFBQVEsUUFBUSxTQUFTLFlBQVksUUFBUSxFQUFFLENBQUMsY0FBYztLQUFzQixRQUFPO0lBQU87Ozs7O0lBQ3JKLHdCQUFDLFFBQUQ7S0FBUSxPQUFNO0tBQWlCLE9BQU87S0FBUSxRQUFPO0tBQTRCLFFBQU87SUFBUzs7Ozs7SUFDakcsd0JBQUMsUUFBRDtLQUFRLE9BQU07S0FBYyxPQUFPO0tBQVcsUUFBTztLQUFvQixRQUFPO0lBQU87Ozs7O0lBQ3ZGLHdCQUFDLFFBQUQ7S0FBUSxPQUFNO0tBQWUsT0FBTyxTQUFTLGVBQWUsT0FBTyxTQUFTLElBQUk7S0FBSyxRQUFRLFNBQVMsT0FBTyxZQUFZO0tBQXFCLFFBQU87SUFBUzs7Ozs7R0FDdko7Ozs7OztFQUNULHdCQUFDLE9BQUQ7R0FBSyxXQUFVO2FBQWYsQ0FDRSx3QkFBQyxXQUFEO0lBQVMsV0FBVTtjQUFuQixDQUNFLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWYsQ0FBK0Msd0JBQUMsT0FBRCxhQUFLLHdCQUFDLEtBQUQ7TUFBRyxXQUFVO2dCQUFVO0tBQVc7Ozs7ZUFBQyx3QkFBQyxNQUFELGFBQUksb0JBQWdCLHdCQUFDLFFBQUQ7TUFBTSxXQUFVO2dCQUFpQixRQUFRO0tBQWE7Ozs7YUFBSzs7OzthQUFNOzs7O2VBQUMsd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWU7T0FBQztPQUFPO09BQWU7T0FBUztNQUFLLENBQUMsQ0FBQyxLQUFLLFNBQVMsd0JBQUMsVUFBRDtPQUFtQixXQUFXLFdBQVcsT0FBTyxjQUFjO09BQUksZUFBZSxVQUFVLElBQUk7aUJBQUk7TUFBYSxHQUFuRzs7OzthQUFtRyxDQUFDO0tBQU87Ozs7YUFBTTs7Ozs7Y0FDN1gsUUFBUSxXQUFXLElBQUksd0JBQUMsWUFBRDtLQUFtQjtLQUFPLFVBQVUsV0FBVztJQUFROzs7O2VBQUksd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBYyxRQUFRLEtBQUssT0FBTyxVQUFVLHdCQUFDLFVBQUQ7TUFBZ0M7TUFBTyxVQUFVLFFBQVEsUUFBUSxLQUFLLElBQUk7TUFBRyxRQUFRLFFBQVEsUUFBUSxLQUFLLE1BQU07TUFBVztNQUFnQjtNQUFrQjtLQUFXLEdBQXpKLE1BQU07Ozs7WUFBbUosQ0FBQztJQUFPOzs7O1lBQ3ZUOzs7OzthQUNULHdCQUFDLFNBQUQ7SUFBTyxXQUFVO2NBQWpCO0tBQ0Usd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWYsQ0FBOEIsd0JBQUMsT0FBRCxhQUFLLHdCQUFDLEtBQUQ7T0FBRyxXQUFVO2lCQUFVO01BQVc7Ozs7Z0JBQUMsd0JBQUMsTUFBRCxZQUFJLGNBQWU7Ozs7Y0FBTTs7OztnQkFBQyx3QkFBQyxRQUFELEVBQVEsTUFBTSxHQUFLOzs7O2NBQU07Ozs7OztLQUN6SCx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZjtPQUErQix3QkFBQyxVQUFELFlBQVMsVUFBa0I7Ozs7O09BQUMsd0JBQUMsUUFBRDtRQUFNO1FBQUksS0FBSyxPQUFPLFFBQVEsVUFBVSxNQUFNLFFBQVEsQ0FBQyxDQUFDO1FBQU87T0FBeUI7Ozs7O09BQUMsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWMsd0JBQUMsUUFBRCxFQUFNLE9BQU8sRUFBRSxPQUFPLEdBQUcsS0FBSyxJQUFJLEdBQUksWUFBWSxLQUFLLElBQUksR0FBRyxLQUFLLE9BQU8sUUFBUSxVQUFVLE1BQU0sUUFBUSxDQUFDLENBQUMsTUFBTSxJQUFLLEdBQUcsRUFBRSxHQUFHLEVBQUk7Ozs7O09BQU07Ozs7O01BQU07Ozs7OztLQUNoVSx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBbUIsS0FBSyxPQUFPLFFBQVEsVUFBVSxNQUFNLFFBQVEsQ0FBQyxDQUFDLEtBQUssVUFBVTtPQUFFLE1BQU0sV0FBVyxNQUFNLGlCQUFpQjtPQUFZLE9BQU8sd0JBQUMsVUFBRDtRQUFRLE1BQUs7UUFBUyxXQUFXLGNBQWMsV0FBVyxnQkFBZ0I7UUFBcUIsZUFBZSxZQUFZLGtCQUFrQixlQUFlLEtBQUs7UUFBRyxPQUFPO1NBQUUsUUFBUSxXQUFXLFlBQVk7U0FBVyxXQUFXO1NBQVEsUUFBUTtTQUFRLE1BQU07UUFBVTtRQUFHLE9BQU8sV0FBVyxlQUFlLE1BQU0sY0FBYyxhQUFhLFFBQVEsK0JBQStCLEdBQUcsTUFBTSxTQUFTO2tCQUF2WSxDQUEwWix3QkFBQyxRQUFELFlBQU8sTUFBTSxLQUFXOzs7O2tCQUFDLHdCQUFDLFNBQUQsWUFBUSxXQUFZLE1BQU0sZUFBZSxHQUFHLE1BQU0sYUFBYSxVQUFVLFdBQVcsb0JBQXFCLEdBQUcsTUFBTSxTQUFTLFFBQWU7Ozs7Z0JBQVM7VUFBamYsTUFBTTs7OztjQUEyZTtNQUFFLENBQUM7S0FBTzs7Ozs7S0FDNXVCLHdCQUFDLE9BQUQsRUFBSyxXQUFVLGVBQWdCOzs7OztLQUMvQix3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZjtPQUErQix3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZixDQUFvQyx3QkFBQyxNQUFELFlBQUksZUFBZ0I7Ozs7a0JBQUMsd0JBQUMsVUFBRCxFQUFVLE1BQU0sR0FBSzs7OztnQkFBTTs7Ozs7O09BQUMsd0JBQUMsS0FBRCxZQUFHLHlHQUF5Rzs7Ozs7T0FBQyx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZixDQUErQix3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBcUI7UUFBTzs7OztrQkFBQyx3QkFBQyxRQUFELFlBQU0sOEJBQWlDOzs7O2dCQUFNOzs7Ozs7TUFBTTs7Ozs7O0lBQzFWOzs7OztXQUNKOzs7Ozs7Q0FDTDs7Ozs7QUFDSjs7O0FBRUEsU0FBUyxPQUFPLEVBQUUsT0FBTyxPQUFPLFFBQVEsVUFBVTtDQUNoRCxPQUFPLHdCQUFDLE9BQUQ7RUFBSyxXQUFXLGlCQUFpQjtZQUFqQztHQUEyQyx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmLENBQTRCLHdCQUFDLFFBQUQsWUFBTyxNQUFZOzs7O2NBQUMsd0JBQUMsUUFBRCxFQUFNLFdBQVUsY0FBZTs7OztZQUFNOzs7Ozs7R0FBQyx3QkFBQyxVQUFELFlBQVMsTUFBYzs7Ozs7R0FBQyx3QkFBQyxTQUFELFlBQVEsT0FBYzs7Ozs7RUFBTTs7Ozs7O0FBQzlMOztBQUVBLFNBQVMsU0FBUyxFQUFFLE9BQU8sVUFBVSxRQUFRLFFBQVEsUUFBUSxZQUFZO0NBQ3ZFLE9BQU8sd0JBQUMsV0FBRDtFQUFTLFdBQVcsYUFBYSxTQUFTLFlBQVk7WUFBdEQ7R0FDTCx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFrQixTQUFTLHdCQUFDLFFBQUQ7S0FBTSxXQUFVO2VBQVc7SUFBVTs7OztlQUFJLHdCQUFDLFFBQUQsWUFBTyxPQUFPLFFBQVEsQ0FBQyxDQUFDLFNBQVMsR0FBRyxHQUFHLEVBQVE7Ozs7O0dBQU87Ozs7O0dBQ3pJLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWYsQ0FBNEIsd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZixDQUFpQyx3QkFBQyxNQUFELFlBQUssTUFBTSxVQUFjOzs7O2VBQUUsTUFBTSxTQUFTLHdCQUFDLFFBQUQ7TUFBTSxXQUFVO01BQVksT0FBTyxNQUFNO2dCQUFPO0tBQVU7Ozs7YUFBTzs7Ozs7Y0FBQyx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmO01BQTRCLHdCQUFDLFFBQUQ7T0FBTSx3QkFBQyxZQUFELEVBQVksTUFBTSxHQUFLOzs7OztPQUFDO09BQUUsTUFBTTtPQUFVO09BQUUsTUFBTSxjQUFjLElBQUksVUFBVTtNQUFlOzs7OztNQUFDLHdCQUFDLFFBQUQ7T0FBTSx3QkFBQyxVQUFELEVBQVUsTUFBTSxHQUFLOzs7OztPQUFDO09BQUUsTUFBTTtNQUF3Qjs7Ozs7TUFBQyx3QkFBQyxRQUFEO09BQU0sd0JBQUMsUUFBRCxFQUFRLE1BQU0sR0FBSzs7Ozs7T0FBQztPQUFFLFdBQVcsTUFBTSxTQUFTO01BQVE7Ozs7O01BQUMsd0JBQUMsUUFBRDtPQUFNLFdBQVU7aUJBQXNCLE1BQU07TUFBWTs7Ozs7S0FBTTs7Ozs7WUFBTTs7Ozs7O0dBQ3plLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWUsTUFBTTtHQUFXOzs7OztHQUMvQyx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmLENBQTBCLHdCQUFDLFVBQUQsWUFBUyxlQUFlLE1BQU0sU0FBUyxFQUFVOzs7O2NBQUMsd0JBQUMsUUFBRCxZQUFNLFVBQWE7Ozs7WUFBTTs7Ozs7O0dBQ3JHLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWY7S0FBNkIsd0JBQUMsVUFBRDtNQUFRLFdBQVU7TUFBcUIsZUFBZSxPQUFPLEtBQUs7Z0JBQWxFLENBQXFFLHdCQUFDLFFBQUQsRUFBUSxNQUFNLEdBQUs7Ozs7Z0JBQUMsT0FBYTs7Ozs7O0tBQUMsd0JBQUMsVUFBRDtNQUFRLFdBQVU7TUFBYyxlQUFlLE9BQU8sS0FBSztNQUFHLGNBQVksUUFBUSxNQUFNO01BQWEsT0FBTTtnQkFBTyx3QkFBQyxPQUFELEVBQU8sTUFBTSxHQUFLOzs7OztLQUFTOzs7OztLQUFDLHdCQUFDLFVBQUQ7TUFBUSxXQUFVO01BQTBCLGVBQWUsU0FBUyxLQUFLO01BQUcsY0FBWSxVQUFVLE1BQU07TUFBYSxPQUFNO2dCQUFTLHdCQUFDLEdBQUQsRUFBRyxNQUFNLEdBQUs7Ozs7O0tBQVM7Ozs7O0lBQU07Ozs7OztFQUM1YTs7Ozs7O0FBQ1g7O0FBRUEsU0FBUyxXQUFXLEVBQUUsT0FBTyxZQUFZO0NBQ3ZDLE9BQU8sd0JBQUMsT0FBRDtFQUFLLFdBQVU7WUFBZjtHQUE2Qix3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFhLHdCQUFDLFVBQUQsRUFBVSxNQUFNLEdBQUs7Ozs7O0dBQU07Ozs7O0dBQUMsd0JBQUMsTUFBRCxZQUFLLFdBQVcsNEJBQTRCLHdCQUE0Qjs7Ozs7R0FBQyx3QkFBQyxLQUFELFlBQUksV0FBVyxvQ0FBb0MseURBQTREOzs7OztHQUFFLENBQUMsWUFBWSx3QkFBQyxVQUFEO0lBQVEsV0FBVTtJQUEwQixTQUFTO2NBQXJELENBQTRELHdCQUFDLE1BQUQsRUFBTSxNQUFNLEdBQUs7Ozs7Y0FBQyxrQkFBd0I7Ozs7OztFQUFPOzs7Ozs7QUFDbFo7O0FBRUEsU0FBUyxZQUFZLEVBQUUsTUFBTSxrQkFBa0I7Q0FDN0MsTUFBTSxVQUFVLEtBQUssUUFBUSxRQUFRLFVBQVUsTUFBTSxXQUFXLFNBQVMsQ0FBQyxDQUFDLE1BQU0sR0FBRyxNQUFNLElBQUksS0FBSyxFQUFFLFlBQVksRUFBRSxlQUFlLEVBQUUsU0FBUyxJQUFJLElBQUksS0FBSyxFQUFFLFlBQVksRUFBRSxlQUFlLEVBQUUsU0FBUyxDQUFDO0NBQ3JNLE1BQU0sU0FBUyxRQUFRLFFBQVEsVUFBVSxNQUFNLFdBQVcsUUFBUSxDQUFDLENBQUM7Q0FDcEUsT0FBTztFQUFFLHdCQUFDLFdBQUQ7R0FBUyxXQUFVO2FBQW5CLENBQWdDLHdCQUFDLE9BQUQ7SUFBSyx3QkFBQyxLQUFEO0tBQUcsV0FBVTtlQUFVO0lBQTBCOzs7OztJQUFDLHdCQUFDLE1BQUQsYUFBSSxtQkFBZSx3QkFBQyxRQUFEO0tBQU0sV0FBVTtlQUFTO0lBQU87Ozs7WUFBSzs7Ozs7SUFBQyx3QkFBQyxLQUFEO0tBQUcsV0FBVTtlQUFtQjtJQUFzRDs7Ozs7R0FBTTs7OzthQUFDLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWYsQ0FBK0Isd0JBQUMsVUFBRCxZQUFTLFFBQVEsT0FBZTs7OztjQUFDLHdCQUFDLFFBQUQsWUFBTSxvQkFBdUI7Ozs7WUFBTTs7Ozs7V0FBVTs7Ozs7O0VBQUMsd0JBQUMsV0FBRDtHQUFTLFdBQVU7YUFBbkI7SUFBcUMsd0JBQUMsT0FBRDtLQUFLLHdCQUFDLFFBQUQ7TUFBTSxXQUFVO2dCQUFnQjtLQUFZOzs7OztLQUFDLHdCQUFDLFVBQUQsWUFBUyxPQUFlOzs7OztLQUFDLHdCQUFDLFFBQUQsWUFBTSxxQkFBd0I7Ozs7O0lBQU07Ozs7O0lBQUMsd0JBQUMsT0FBRDtLQUFLLHdCQUFDLFFBQUQ7TUFBTSxXQUFVO2dCQUFnQjtLQUFlOzs7OztLQUFDLHdCQUFDLFVBQUQsWUFBUyxRQUFRLFNBQVMsT0FBZTs7Ozs7S0FBQyx3QkFBQyxRQUFELFlBQU0sd0JBQTJCOzs7OztJQUFNOzs7OztJQUFDLHdCQUFDLE9BQUQ7S0FBSyx3QkFBQyxRQUFEO01BQU0sV0FBVTtnQkFBZ0I7S0FBa0I7Ozs7O0tBQUMsd0JBQUMsVUFBRCxZQUFTLElBQUksS0FBSyxlQUFlLFNBQVM7TUFBRSxPQUFPO01BQVMsS0FBSztLQUFVLENBQUMsQ0FBQyxDQUFDLE9BQU8sSUFBSSxLQUFLLENBQUMsRUFBVTs7Ozs7S0FBQyx3QkFBQyxRQUFELFlBQU8sS0FBSyxXQUFXLEtBQVc7Ozs7O0lBQU07Ozs7O0dBQVU7Ozs7OztFQUFDLHdCQUFDLFdBQUQ7R0FBUyxXQUFVO2FBQW5CLENBQW1DLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWYsQ0FBaUMsd0JBQUMsT0FBRCxhQUFLLHdCQUFDLEtBQUQ7S0FBRyxXQUFVO2VBQVU7SUFBVTs7OztjQUFDLHdCQUFDLE1BQUQsWUFBSSxvQkFBcUI7Ozs7WUFBTTs7OztjQUFDLHdCQUFDLFFBQUQ7S0FBTSxXQUFVO2VBQWM7SUFBeUI7Ozs7WUFBTTs7Ozs7YUFBRSxRQUFRLFdBQVcsSUFBSSx3QkFBQyxjQUFELENBQWU7Ozs7Y0FBSSx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFnQixRQUFRLEtBQUssVUFBVSx3QkFBQyxZQUFEO0tBQWtDO0tBQU8sT0FBTyxLQUFLLE9BQU8sTUFBTSxVQUFVLE1BQU0sT0FBTyxNQUFNLGVBQWU7S0FBbUI7SUFBaUIsR0FBakksTUFBTTs7OztXQUEySCxDQUFDO0dBQU87Ozs7V0FBVzs7Ozs7O0NBQUc7Ozs7O0FBQ3p5Qzs7QUFFQSxTQUFTLFdBQVcsRUFBRSxPQUFPLE9BQU8sa0JBQWtCO0NBQ3BELE1BQU0sV0FBVyxNQUFNLFdBQVc7Q0FDbEMsTUFBTSxhQUFhLFlBQVksTUFBTSxtQkFBbUIsU0FBUyxNQUFNLGlCQUFpQjtDQUN4RixPQUFPLHdCQUFDLE9BQUQ7RUFBSyxXQUFVO1lBQWY7R0FBNkIsd0JBQUMsT0FBRDtJQUFLLFdBQVcsa0JBQWtCLFdBQVcsa0JBQWtCO2NBQXVCLFdBQVcsd0JBQUMsT0FBRCxFQUFPLE1BQU0sR0FBSzs7OztlQUFJLHdCQUFDLEdBQUQsRUFBRyxNQUFNLEdBQUs7Ozs7O0dBQU87Ozs7O0dBQUMsd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZixDQUErQix3QkFBQyxVQUFELFlBQVMsTUFBTSxVQUFrQjs7OztjQUFDLHdCQUFDLFFBQUQ7S0FBTyxNQUFNO0tBQVU7S0FBVyxNQUFNO0lBQXdCOzs7O1lBQU07Ozs7OztHQUFDLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWYsQ0FBZ0Msd0JBQUMsUUFBRCxZQUFPLFdBQVcsYUFBYSxPQUFPLFFBQVEsWUFBWSx1QkFBNkI7Ozs7Y0FBQyx3QkFBQyxTQUFELFlBQVEsV0FBVyxNQUFNLFlBQVksTUFBTSxlQUFlLE1BQU0sU0FBUyxFQUFTOzs7O1lBQU07Ozs7OztHQUFDLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWYsQ0FBK0Isd0JBQUMsT0FBRDtLQUFLLFdBQVU7Z0JBQXVCLE1BQU0sZUFBZSxRQUFPLENBQUUsTUFBTSxHQUFHLENBQUMsQ0FBQyxLQUFLLFNBQVMsS0FBSyxFQUFFLENBQUMsQ0FBQyxLQUFLLEVBQUU7SUFBTzs7OztjQUFDLHdCQUFDLFFBQUQsWUFBTyxNQUFNLGVBQWUsUUFBYzs7OztZQUFNOzs7Ozs7R0FBRSxjQUFjLHdCQUFDLFVBQUQ7SUFBUSxXQUFVO0lBQXNCLE9BQU87S0FBRSxTQUFTO0tBQW1CLFVBQVU7SUFBVTtJQUFHLGVBQWUsZUFBZSxLQUFLO2NBQUc7R0FBa0I7Ozs7O0VBQU87Ozs7OztBQUNuNEI7O0FBRUEsU0FBUyxlQUFlO0NBQUUsT0FBTyx3QkFBQyxPQUFEO0VBQUssV0FBVTtZQUFmO0dBQXFDLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWEsd0JBQUMsUUFBRCxFQUFRLE1BQU0sR0FBSzs7Ozs7R0FBTTs7Ozs7R0FBQyx3QkFBQyxNQUFELFlBQUksb0JBQXFCOzs7OztHQUFDLHdCQUFDLEtBQUQsWUFBRyxpREFBaUQ7Ozs7O0VBQU07Ozs7OztBQUFFOztBQUVsTixTQUFTLGFBQWEsRUFBRSxNQUFNLFdBQVcsVUFBVSxXQUFXOztDQUM1RCxNQUFNLENBQUMsS0FBSyxVQUFVLFNBQVMsTUFBTTtDQUNyQyxNQUFNLENBQUMsZ0JBQWdCLHFCQUFxQixTQUFTLEtBQUssV0FBVyxJQUFJO0NBQ3pFLE1BQU0sQ0FBQyxRQUFRLGFBQWEsU0FBUyxLQUFLLFdBQVcsTUFBTTtDQUMzRCxNQUFNLENBQUMsUUFBUSxhQUFhLFNBQVMsS0FBSztDQUMxQyxNQUFNLGlCQUFpQixPQUFPLFVBQVU7RUFDdEMsTUFBTSxlQUFlO0VBQ3JCLFVBQVUsSUFBSTtFQUNkLElBQUk7R0FBRSxNQUFNLElBQUksaUJBQWlCO0lBQUUsTUFBTTtJQUFnQjtHQUFPLENBQUM7R0FBRyxNQUFNLFVBQVU7R0FBRyxTQUFTLDRCQUE0QjtFQUFFLFNBQVMsT0FBTztHQUFFLFNBQVMsTUFBTSxTQUFTLE9BQU87RUFBRSxVQUFVO0dBQUUsVUFBVSxLQUFLO0VBQUU7Q0FDaE47Q0FDQSxPQUFPLGdEQUFFLHdCQUFDLFdBQUQ7RUFBUyxXQUFVO1lBQW5CLENBQStDLHdCQUFDLE9BQUQ7R0FBSyx3QkFBQyxLQUFEO0lBQUcsV0FBVTtjQUFVO0dBQWdDOzs7OztHQUFDLHdCQUFDLE1BQUQsYUFBSSxpQkFBYSx3QkFBQyxRQUFEO0lBQU0sV0FBVTtjQUFTO0dBQU87Ozs7V0FBSzs7Ozs7R0FBQyx3QkFBQyxLQUFEO0lBQUcsV0FBVTtjQUFtQjtHQUF1RTs7Ozs7RUFBTTs7OztZQUFDLHdCQUFDLE9BQUQ7R0FBSyxXQUFVO2FBQWYsQ0FBOEIsd0JBQUMsYUFBRCxFQUFhLE1BQU0sR0FBSzs7OzthQUFDLHdCQUFDLFFBQUQsWUFBTSxpQkFBb0I7Ozs7V0FBTTs7Ozs7VUFBVTs7Ozs7V0FBQyx3QkFBQyxPQUFEO0VBQUssV0FBVTtZQUFmLENBQWlDLHdCQUFDLE9BQUQ7R0FBSyxXQUFVO0dBQWdCLE1BQUs7YUFBcEM7SUFBOEMsd0JBQUMsVUFBRDtLQUFRLFdBQVcsUUFBUSxTQUFTLGNBQWM7S0FBSSxlQUFlLE9BQU8sTUFBTTtlQUFsRixDQUFxRix3QkFBQyxXQUFELEVBQVcsTUFBTSxHQUFLOzs7O2VBQUMsYUFBbUI7Ozs7OztJQUFDLHdCQUFDLFVBQUQ7S0FBUSxXQUFXLFFBQVEsV0FBVyxjQUFjO0tBQUksZUFBZSxPQUFPLFFBQVE7ZUFBdEY7TUFBeUYsd0JBQUMsUUFBRCxFQUFRLE1BQU0sR0FBSzs7Ozs7TUFBQztNQUFRLHdCQUFDLFFBQUQsWUFBTyxLQUFLLE9BQU8sT0FBYTs7Ozs7S0FBUzs7Ozs7O0lBQUMsd0JBQUMsVUFBRDtLQUFRLFdBQVcsUUFBUSxVQUFVLGNBQWM7S0FBSSxlQUFlLE9BQU8sT0FBTztlQUFwRjtNQUF1Rix3QkFBQyxZQUFELEVBQVksTUFBTSxHQUFLOzs7OztNQUFDO01BQU8sd0JBQUMsUUFBRCxZQUFPLEtBQUssTUFBTSxPQUFhOzs7OztLQUFTOzs7Ozs7R0FBTTs7Ozs7WUFBQyx3QkFBQyxPQUFEO0dBQUssV0FBVTthQUFmO0lBQW1DLFFBQVEsVUFBVSx3QkFBQyxRQUFEO0tBQU0sV0FBVTtLQUFtQixVQUFVO2VBQTdDO01BQTZELHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQXVDLHdCQUFDLE9BQUQsYUFBSyx3QkFBQyxLQUFEO1FBQUcsV0FBVTtrQkFBVTtPQUFzQjs7OztpQkFBQyx3QkFBQyxNQUFELFlBQUksaUJBQWtCOzs7O2VBQU07Ozs7aUJBQUMsd0JBQUMsVUFBRDtRQUFRLFdBQVU7UUFBd0IsVUFBVTtrQkFBUyxTQUFTLFlBQVk7T0FBdUI7Ozs7ZUFBTTs7Ozs7O01BQUMsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FBMkIsd0JBQUMsT0FBRDtRQUFPLE9BQU07UUFBa0IsT0FBTztRQUFnQixVQUFVO09BQW9COzs7O2lCQUFDLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmLENBQWdDLHdCQUFDLE9BQUQsYUFBSyx3QkFBQyxVQUFELFlBQVEscUJBQTBCOzs7O2tCQUFDLHdCQUFDLFFBQUQsWUFBTSxtRUFBc0U7Ozs7Z0JBQU07Ozs7a0JBQUMsd0JBQUMsVUFBRDtTQUFRLE1BQUs7U0FBUyxXQUFXLFVBQVUsU0FBUyxVQUFVO1NBQU0sZUFBZSxXQUFXLFVBQVUsQ0FBQyxLQUFLO1NBQUcsY0FBVzttQkFBZ0Msd0JBQUMsUUFBRCxDQUFPOzs7OztRQUFTOzs7O2dCQUFNOzs7OztlQUFNOzs7Ozs7TUFBQyx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUFvQyx3QkFBQyxPQUFELGFBQUssd0JBQUMsS0FBRDtRQUFHLFdBQVU7a0JBQVU7T0FBc0I7Ozs7aUJBQUMsd0JBQUMsTUFBRCxZQUFJLG9CQUFxQjs7OztlQUFNOzs7O2lCQUFDLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFvQixLQUFLLE1BQU0sUUFBUSxTQUFTLEtBQUssUUFBUSxDQUFDLENBQUMsS0FBSyxTQUFTLHdCQUFDLFFBQUQ7U0FBb0IsV0FBVTttQkFBOUIsQ0FBZ0Qsd0JBQUMsUUFBRCxFQUFNLFdBQVUsV0FBWTs7OzttQkFBRSxLQUFLLElBQVc7V0FBbkYsS0FBSzs7OztlQUE4RSxDQUFDO09BQU87Ozs7ZUFBTTs7Ozs7O0tBQU87Ozs7OztJQUFHLFFBQVEsWUFBWSx3QkFBQyxnQkFBRDtLQUFzQjtLQUFlO0lBQVU7Ozs7O0lBQUcsUUFBUSxXQUFXLHdCQUFDLGVBQUQ7S0FBcUI7S0FBZTtLQUFvQjtLQUFxQjtJQUFXOzs7OztHQUFPOzs7OztVQUFNOzs7OztTQUFHOzs7OztBQUN4ckU7OztBQUVBLFNBQVMsZUFBZSxFQUFFLE1BQU0sV0FBVztDQUN6QyxPQUFPLHdCQUFDLFdBQUQ7RUFBUyxXQUFVO1lBQW5CLENBQXNDLHdCQUFDLE9BQUQ7R0FBSyxXQUFVO2FBQWYsQ0FBdUMsd0JBQUMsT0FBRDtJQUFLLHdCQUFDLEtBQUQ7S0FBRyxXQUFVO2VBQVU7SUFBaUI7Ozs7O0lBQUMsd0JBQUMsTUFBRCxZQUFJLFNBQVU7Ozs7O0lBQUMsd0JBQUMsS0FBRDtLQUFHLFdBQVU7ZUFBbUI7SUFBNkQ7Ozs7O0dBQU07Ozs7YUFBQyx3QkFBQyxVQUFEO0lBQVEsV0FBVTtJQUF3QixlQUFlLFFBQVEsRUFBRSxNQUFNLFFBQVEsQ0FBQztjQUFsRixDQUFxRix3QkFBQyxNQUFELEVBQU0sTUFBTSxHQUFLOzs7O2NBQUMsWUFBa0I7Ozs7O1dBQU07Ozs7O1lBQUMsd0JBQUMsT0FBRDtHQUFLLFdBQVU7YUFBa0IsS0FBSyxPQUFPLEtBQUssVUFBVSx3QkFBQyxPQUFEO0lBQUssV0FBVyxpQkFBaUIsQ0FBQyxNQUFNLFdBQVcsZ0JBQWdCO2NBQW5FO0tBQXdGLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFtQix3QkFBQyxRQUFELEVBQVEsTUFBTSxHQUFLOzs7OztLQUFNOzs7OztLQUFDLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmLENBQWdDLHdCQUFDLFVBQUQsWUFBUyxNQUFNLEtBQWE7Ozs7Z0JBQUMsd0JBQUMsUUFBRDtPQUFPLE1BQU07T0FBUztPQUFVLEtBQUssTUFBTSxNQUFNLFNBQVMsS0FBSyxPQUFPLE1BQU0sTUFBTSxDQUFDLEVBQUUsUUFBUTtNQUFnQjs7OztjQUFNOzs7Ozs7S0FBQyx3QkFBQyxRQUFEO01BQU0sV0FBVyxvQkFBb0IsTUFBTTtnQkFBaUIsTUFBTSxpQkFBaUIsYUFBYSxhQUFhLE1BQU0sV0FBVyxjQUFjO0tBQWlCOzs7OztLQUFFLE1BQU0saUJBQWlCLGNBQWMsd0JBQUMsVUFBRDtNQUFRLFdBQVU7TUFBYyxPQUFPO09BQUUsWUFBWTtPQUFVLFlBQVk7TUFBSTtNQUFHLGVBQWUsUUFBUTtPQUFFLE1BQU07T0FBaUI7TUFBTSxDQUFDO2dCQUFHO0tBQWtCOzs7OztLQUFFLHdCQUFDLFVBQUQ7TUFBUSxXQUFVO01BQWMsZUFBZSxRQUFRO09BQUUsTUFBTTtPQUFTO01BQU0sQ0FBQztNQUFHLGNBQVksUUFBUSxNQUFNO01BQVEsT0FBTTtnQkFBYSx3QkFBQyxnQkFBRCxFQUFnQixNQUFNLEdBQUs7Ozs7O0tBQVM7Ozs7O0lBQU07TUFBNXdCLE1BQU07Ozs7VUFBc3dCLENBQUM7RUFBTzs7OztVQUFVOzs7Ozs7QUFDL3hDOztBQUVBLFNBQVMsY0FBYyxFQUFFLE1BQU0sU0FBUyxXQUFXLFlBQVk7Q0FDN0QsTUFBTSxTQUFTLE9BQU8sU0FBUztFQUFFLElBQUk7R0FBRSxNQUFNLElBQUksWUFBWSxLQUFLLElBQUksQ0FBQyxLQUFLLFFBQVE7R0FBRyxNQUFNLFVBQVU7R0FBRyxTQUFTLEdBQUcsS0FBSyxLQUFLLFVBQVUsS0FBSyxXQUFXLGFBQWEsU0FBUyxFQUFFO0VBQUUsU0FBUyxPQUFPO0dBQUUsU0FBUyxNQUFNLFNBQVMsT0FBTztFQUFFO0NBQUU7Q0FDek8sT0FBTyx3QkFBQyxXQUFEO0VBQVMsV0FBVTtZQUFuQixDQUFzQyx3QkFBQyxPQUFEO0dBQUssV0FBVTthQUFmLENBQXVDLHdCQUFDLE9BQUQ7SUFBSyx3QkFBQyxLQUFEO0tBQUcsV0FBVTtlQUFVO0lBQWtCOzs7OztJQUFDLHdCQUFDLE1BQUQsWUFBSSxpQkFBa0I7Ozs7O0lBQUMsd0JBQUMsS0FBRDtLQUFHLFdBQVU7ZUFBbUI7SUFBa0Q7Ozs7O0dBQU07Ozs7YUFBQyx3QkFBQyxVQUFEO0lBQVEsV0FBVTtJQUF3QixlQUFlLFFBQVEsRUFBRSxNQUFNLFFBQVEsQ0FBQztjQUFsRixDQUFxRix3QkFBQyxNQUFELEVBQU0sTUFBTSxHQUFLOzs7O2NBQUMsWUFBa0I7Ozs7O1dBQU07Ozs7O1lBQUMsd0JBQUMsT0FBRDtHQUFLLFdBQVU7YUFBa0IsS0FBSyxNQUFNLEtBQUssU0FBUyx3QkFBQyxPQUFEO0lBQUssV0FBVyxpQkFBaUIsQ0FBQyxLQUFLLFdBQVcsZ0JBQWdCO2NBQWxFO0tBQXNGLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUF1QixLQUFLLEtBQUssTUFBTSxHQUFHLENBQUMsQ0FBQyxLQUFLLFNBQVMsS0FBSyxFQUFFLENBQUMsQ0FBQyxLQUFLLEVBQUU7S0FBTzs7Ozs7S0FBQyx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZixDQUFnQyx3QkFBQyxVQUFELFlBQVMsS0FBSyxLQUFhOzs7O2dCQUFDLHdCQUFDLFFBQUQsWUFBTyxLQUFLLFdBQWlCOzs7O2NBQU07Ozs7OztLQUFDLHdCQUFDLFFBQUQ7TUFBTSxXQUFXLGtCQUFrQixLQUFLO2dCQUFTLEtBQUs7S0FBVzs7Ozs7S0FBQyx3QkFBQyxVQUFEO01BQVEsV0FBVyxlQUFlLEtBQUssV0FBVyxnQkFBZ0I7TUFBTSxlQUFlLE9BQU8sSUFBSTtnQkFBSSxLQUFLLFdBQVcsWUFBWTtLQUFpQjs7Ozs7SUFBTTtNQUFyYSxLQUFLOzs7O1VBQWdhLENBQUM7RUFBTzs7OztVQUFVOzs7Ozs7QUFDbjdCOztBQUVBLFNBQVMsV0FBVyxFQUFFLE9BQU8sU0FBUyxVQUFVLFNBQVMsT0FBTyxTQUFTO0NBQ3ZFLE9BQU8sd0JBQUMsT0FBRDtFQUFLLFdBQVU7RUFBaUIsTUFBSztZQUFlLHdCQUFDLE9BQUQ7R0FBSyxXQUFXLFNBQVMsT0FBTyxlQUFlO0dBQU0sTUFBSztHQUFTLGNBQVc7R0FBTyxjQUFZO2FBQWpHO0lBQXdHLHdCQUFDLFVBQUQ7S0FBUSxXQUFVO0tBQTBCLFNBQVM7S0FBUyxjQUFXO2VBQWUsd0JBQUMsR0FBRCxFQUFHLE1BQU0sR0FBSzs7Ozs7SUFBUzs7Ozs7SUFBQyx3QkFBQyxLQUFEO0tBQUcsV0FBVTtlQUFXO0lBQVc7Ozs7O0lBQUMsd0JBQUMsTUFBRCxZQUFLLE1BQVU7Ozs7O0lBQUU7R0FBYzs7Ozs7O0NBQU07Ozs7O0FBQzlWOztBQUVBLFNBQVMsV0FBVyxFQUFFLE9BQU8sU0FBUyxTQUFTLFVBQVU7O0NBQ3ZELE1BQU0sQ0FBQyxNQUFNLFdBQVcsU0FBUztFQUFFLFdBQVcsT0FBTyxhQUFhO0VBQUksT0FBTyxPQUFPLFNBQVM7RUFBSSxXQUFXLE9BQU8sYUFBYTtFQUFHLG1CQUFtQixPQUFPLHFCQUFxQjtFQUFpQixPQUFPLE9BQU8sU0FBUztDQUFHLENBQUM7Q0FDOU4sTUFBTSxDQUFDLE1BQU0sV0FBVyxTQUFTLEtBQUs7Q0FDdEMsTUFBTSxDQUFDLFFBQVEsYUFBYSxTQUFTLENBQUMsQ0FBQztDQUN2QyxNQUFNLFlBQVksUUFBUSxNQUFNLGNBQWMsVUFBVSxXQUFXLGFBQWEsVUFBVSxPQUFPLE9BQU8sTUFBTSxVQUFVLE1BQU0sUUFBUSxPQUFPLEVBQUUsTUFBTSxLQUFLLE1BQU0sUUFBUSxPQUFPLEVBQUUsS0FBSyxLQUFLLE1BQU0sUUFBUSxPQUFPLEVBQUUsQ0FBQyxDQUFDLFNBQVMsQ0FBQztDQUM5TixNQUFNLFVBQVUsS0FBSyxVQUFVLFNBQVMsYUFBYTtFQUFFLEdBQUc7R0FBVSxNQUFNO0NBQU0sRUFBRTtDQUNsRixNQUFNLFNBQVMsT0FBTyxVQUFVO0VBQzlCLE1BQU0sZUFBZTtFQUNyQixNQUFNLGFBQWEsQ0FBQztFQUNwQixJQUFJLENBQUMsS0FBSyxVQUFVLEtBQUssR0FBRyxXQUFXLFlBQVk7RUFDbkQsSUFBSSxLQUFLLE1BQU0sUUFBUSxPQUFPLEVBQUUsQ0FBQyxDQUFDLFNBQVMsR0FBRyxXQUFXLFFBQVE7RUFDakUsSUFBSSxDQUFDLE9BQU8sVUFBVSxPQUFPLEtBQUssU0FBUyxDQUFDLEtBQUssT0FBTyxLQUFLLFNBQVMsSUFBSSxHQUFHLFdBQVcsWUFBWTtFQUNwRyxVQUFVLFVBQVU7RUFDcEIsSUFBSSxPQUFPLEtBQUssVUFBVSxDQUFDLENBQUMsUUFBUTtFQUNwQyxRQUFRLElBQUk7RUFDWixNQUFNLE9BQU8sSUFBSTtFQUNqQixRQUFRLEtBQUs7Q0FDZjtDQUNBLE9BQU8sd0JBQUMsWUFBRDtFQUFZLE9BQU8sUUFBUSxlQUFlO0VBQWUsU0FBUyxRQUFRLG9CQUFvQjtFQUF3QjtZQUFTLHdCQUFDLFFBQUQ7R0FBTSxXQUFVO0dBQWEsVUFBVTthQUF2QztJQUErQyx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmO01BQTJCLHdCQUFDLE9BQUQ7T0FBTyxPQUFNO09BQWEsT0FBTyxLQUFLO09BQVcsV0FBVyxVQUFVLE9BQU8sYUFBYSxLQUFLO09BQUcsT0FBTyxPQUFPO09BQVc7TUFBVzs7Ozs7TUFBQyx3QkFBQyxPQUFEO09BQU8sT0FBTTtPQUFlLE9BQU8sS0FBSztPQUFPLFdBQVcsVUFBVSxPQUFPLFNBQVMsS0FBSztPQUFHLE9BQU8sT0FBTztPQUFPLE1BQUs7TUFBTzs7Ozs7TUFBQyx3QkFBQyxPQUFEO09BQU8sT0FBTTtPQUFhLE9BQU8sS0FBSztPQUFXLFdBQVcsVUFBVSxPQUFPLGFBQWEsS0FBSztPQUFHLE9BQU8sT0FBTztPQUFXLE1BQUs7T0FBUyxLQUFJO01BQUs7Ozs7O01BQUMsd0JBQUMsYUFBRDtPQUFhLE9BQU07T0FBcUIsT0FBTyxLQUFLO09BQW1CLFdBQVcsVUFBVSxPQUFPLHFCQUFxQixLQUFLO09BQUcsU0FBUztNQUFvQjs7Ozs7S0FBTTs7Ozs7O0lBQUMsd0JBQUMsT0FBRDtLQUFPLE9BQU07S0FBc0IsT0FBTyxLQUFLO0tBQU8sV0FBVyxVQUFVLE9BQU8sU0FBUyxLQUFLO0tBQUcsYUFBWTtJQUEyQzs7Ozs7SUFBQyx3QkFBQyxPQUFELEVBQUssV0FBVSxhQUFjOzs7OztJQUFFLGFBQWEsd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZixDQUFtQyx3QkFBQyxVQUFELEVBQVUsTUFBTSxHQUFLOzs7O2VBQUMsd0JBQUMsT0FBRCxhQUFLLHdCQUFDLFVBQUQsWUFBUSx3Q0FBNkM7Ozs7ZUFBQyx3QkFBQyxRQUFELFlBQU0sb0VBQXVFOzs7O2FBQU07Ozs7YUFBTTs7Ozs7O0lBQUUsd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZixDQUErQix3QkFBQyxVQUFEO01BQVEsTUFBSztNQUFTLFdBQVU7TUFBc0IsU0FBUztnQkFBUztLQUFZOzs7O2VBQUMsd0JBQUMsVUFBRDtNQUFRLFdBQVU7TUFBd0IsVUFBVTtnQkFBcEQ7T0FBMkQsT0FBTyxZQUFZLFFBQVEsaUJBQWlCO09BQWtCO09BQUMsd0JBQUMsY0FBRCxFQUFjLE1BQU0sR0FBSzs7Ozs7TUFBUzs7Ozs7YUFBTTs7Ozs7O0dBQU87Ozs7OztDQUFhOzs7OztBQUM5OEM7OztBQUVBLFNBQVMsVUFBVSxFQUFFLE9BQU8sUUFBUSxTQUFTLE9BQU8sU0FBUyxVQUFVOztDQUNyRSxNQUFNLENBQUMsVUFBVSxlQUFlLFNBQVMsRUFBRTtDQUMzQyxNQUFNLENBQUMsTUFBTSxXQUFXLFNBQVMsS0FBSztDQUN0QyxNQUFNLFVBQVUsT0FBTyxRQUFRLFVBQVUsTUFBTSxZQUFZLE1BQU0saUJBQWlCLFdBQVc7Q0FDN0YsTUFBTSxTQUFTLFlBQVk7RUFBRSxJQUFJLENBQUMsVUFBVTtFQUFRLFFBQVEsSUFBSTtFQUFHLE1BQU0sT0FBTyxRQUFRO0VBQUcsUUFBUSxLQUFLO0NBQUU7Q0FDMUcsT0FBTyx3QkFBQyxZQUFEO0VBQVksT0FBTyxRQUFRLE1BQU07RUFBYSxTQUFRO0VBQTBCO0VBQVM7WUFBekY7R0FBOEYsd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZixDQUFvQyx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFlLE1BQU07SUFBZTs7OztjQUFDLHdCQUFDLE9BQUQsYUFBSyx3QkFBQyxVQUFELFlBQVMsTUFBTSxVQUFrQjs7OztjQUFDLHdCQUFDLFFBQUQ7S0FBTyxNQUFNO0tBQVU7S0FBVyxNQUFNO0tBQWtCO0tBQVksZUFBZSxNQUFNLFNBQVMsQ0FBQyxDQUFDLFFBQVEsUUFBUSxFQUFFO0lBQVE7Ozs7WUFBTTs7OztZQUFNOzs7Ozs7R0FBQyx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFxQixRQUFRLEtBQUssVUFBVTtLQUFFLE1BQU0sT0FBTyxNQUFNLE1BQU0sY0FBYyxVQUFVLE9BQU8sTUFBTSxNQUFNLENBQUMsRUFBRTtLQUFNLE1BQU0sT0FBTyxNQUFNLFlBQVksTUFBTTtLQUFXLE9BQU8sd0JBQUMsVUFBRDtNQUFRLE1BQUs7TUFBd0IsVUFBVSxDQUFDO01BQU0sV0FBVyxnQkFBZ0IsYUFBYSxNQUFNLEtBQUssZ0JBQWdCLEdBQUcsR0FBRyxDQUFDLE9BQU8saUJBQWlCO01BQU0sZUFBZSxZQUFZLE1BQU0sRUFBRTtnQkFBak07T0FBb00sd0JBQUMsUUFBRDtRQUFNLFdBQVU7a0JBQWdCLGFBQWEsTUFBTSxNQUFNLHdCQUFDLE9BQUQsRUFBTyxNQUFNLEdBQUs7Ozs7O09BQVE7Ozs7O09BQUMsd0JBQUMsUUFBRCxFQUFRLE1BQU0sR0FBSzs7Ozs7T0FBQyx3QkFBQyxVQUFELFlBQVMsTUFBTSxLQUFhOzs7OztPQUFDLHdCQUFDLFFBQUQsYUFBTyxNQUFNLFVBQVMsUUFBWTs7Ozs7T0FBQyx3QkFBQyxTQUFELFlBQVEsS0FBWTs7Ozs7T0FBRSxDQUFDLFFBQVEsd0JBQUMsTUFBRCxZQUFJLFlBQWE7Ozs7O01BQVU7UUFBM1ksTUFBTTs7OztZQUFxWTtJQUFFLENBQUM7R0FBTzs7Ozs7R0FBRSxRQUFRLFdBQVcsS0FBSyx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFlO0dBQW9EOzs7OztHQUFFLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWYsQ0FBK0Isd0JBQUMsVUFBRDtLQUFRLE1BQUs7S0FBUyxXQUFVO0tBQXNCLFNBQVM7ZUFBUztJQUFZOzs7O2NBQUMsd0JBQUMsVUFBRDtLQUFRLFdBQVU7S0FBd0IsVUFBVSxDQUFDLFlBQVk7S0FBTSxTQUFTO2VBQWhGO01BQXlGLE9BQU8sYUFBYTtNQUFnQjtNQUFDLHdCQUFDLE9BQUQsRUFBTyxNQUFNLEdBQUs7Ozs7O0tBQVM7Ozs7O1lBQU07Ozs7OztFQUFhOzs7Ozs7QUFDbDNDOzs7QUFFQSxTQUFTLFdBQVcsRUFBRSxPQUFPLE9BQU8sU0FBUyxVQUFVOztDQUNyRCxNQUFNLENBQUMsTUFBTSxXQUFXLFNBQVM7RUFBRSxNQUFNLE9BQU8sUUFBUTtFQUFJLFVBQVUsT0FBTyxZQUFZO0VBQUcsUUFBUSxPQUFPLFVBQVUsTUFBTSxFQUFFLEVBQUUsTUFBTTtFQUFJLFVBQVUsT0FBTyxZQUFZO0NBQUssQ0FBQztDQUM1SyxNQUFNLFNBQVMsT0FBTyxVQUFVO0VBQUUsTUFBTSxlQUFlO0VBQUcsTUFBTSxPQUFPLElBQUk7Q0FBRTtDQUM3RSxPQUFPLHdCQUFDLFlBQUQ7RUFBWSxPQUFPLFFBQVEsUUFBUSxNQUFNLFNBQVM7RUFBZSxTQUFRO0VBQTBCO1lBQVMsd0JBQUMsUUFBRDtHQUFNLFdBQVU7R0FBYSxVQUFVO2FBQXZDO0lBQStDLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWY7TUFBMkIsd0JBQUMsT0FBRDtPQUFPLE9BQU07T0FBYSxPQUFPLEtBQUs7T0FBTSxXQUFXLFVBQVUsUUFBUTtRQUFFLEdBQUc7UUFBTSxNQUFNO09BQU0sQ0FBQztPQUFHO01BQVc7Ozs7O01BQUMsd0JBQUMsT0FBRDtPQUFPLE9BQU07T0FBVyxNQUFLO09BQVMsS0FBSTtPQUFJLE9BQU8sS0FBSztPQUFVLFdBQVcsVUFBVSxRQUFRO1FBQUUsR0FBRztRQUFNLFVBQVU7T0FBTSxDQUFDO01BQUk7Ozs7O01BQUMsd0JBQUMsYUFBRDtPQUFhLE9BQU07T0FBTyxPQUFPLEtBQUs7T0FBUSxXQUFXLFVBQVUsUUFBUTtRQUFFLEdBQUc7UUFBTSxRQUFRO09BQU0sQ0FBQztPQUFHLFNBQVMsTUFBTSxLQUFLLFVBQVU7UUFBRSxPQUFPLEtBQUs7UUFBTSxPQUFPLEtBQUs7T0FBRyxFQUFFO01BQUk7Ozs7O0tBQU07Ozs7OztJQUFFLFNBQVMsd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZixDQUE2Qyx3QkFBQyxPQUFELGFBQUssd0JBQUMsVUFBRCxZQUFRLHdCQUE2Qjs7OztlQUFDLHdCQUFDLFFBQUQsWUFBTSx1REFBMEQ7Ozs7YUFBTTs7OztlQUFDLHdCQUFDLFVBQUQ7TUFBUSxNQUFLO01BQVMsV0FBVyxVQUFVLEtBQUssV0FBVyxVQUFVO01BQU0sZUFBZSxRQUFRO09BQUUsR0FBRztPQUFNLFVBQVUsQ0FBQyxLQUFLO01BQVMsQ0FBQztNQUFHLGNBQVc7Z0JBQTRCLHdCQUFDLFFBQUQsQ0FBTzs7Ozs7S0FBUzs7OzthQUFNOzs7Ozs7SUFBRSx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmLENBQStCLHdCQUFDLFVBQUQ7TUFBUSxNQUFLO01BQVMsV0FBVTtNQUFzQixTQUFTO2dCQUFTO0tBQVk7Ozs7ZUFBQyx3QkFBQyxVQUFEO01BQVEsV0FBVTtnQkFBbEI7T0FBMkMsUUFBUSxlQUFlO09BQVk7T0FBQyx3QkFBQyxjQUFELEVBQWMsTUFBTSxHQUFLOzs7OztNQUFTOzs7OzthQUFNOzs7Ozs7R0FBTzs7Ozs7O0NBQWE7Ozs7O0FBQ3h0Qzs7O0FBRUEsU0FBUyxXQUFXLEVBQUUsU0FBUyxVQUFVOztDQUN2QyxNQUFNLENBQUMsTUFBTSxXQUFXLFNBQVM7RUFBRSxNQUFNO0VBQUksWUFBWTtFQUFJLE1BQU07Q0FBTyxDQUFDO0NBQzNFLE9BQU8sd0JBQUMsWUFBRDtFQUFZLE9BQU07RUFBc0IsU0FBUTtFQUEyQjtZQUFTLHdCQUFDLFFBQUQ7R0FBTSxXQUFVO0dBQWEsV0FBVyxVQUFVO0lBQUUsTUFBTSxlQUFlO0lBQUcsT0FBTyxJQUFJO0dBQUU7YUFBekY7SUFBNEYsd0JBQUMsT0FBRDtLQUFPLE9BQU07S0FBWSxPQUFPLEtBQUs7S0FBTSxXQUFXLFVBQVUsUUFBUTtNQUFFLEdBQUc7TUFBTSxNQUFNO0tBQU0sQ0FBQztLQUFHO0lBQVc7Ozs7O0lBQUMsd0JBQUMsT0FBRDtLQUFPLE9BQU07S0FBYSxNQUFLO0tBQVEsT0FBTyxLQUFLO0tBQVksV0FBVyxVQUFVLFFBQVE7TUFBRSxHQUFHO01BQU0sWUFBWTtLQUFNLENBQUM7SUFBSTs7Ozs7SUFBQyx3QkFBQyxhQUFEO0tBQWEsT0FBTTtLQUFPLE9BQU8sS0FBSztLQUFNLFdBQVcsVUFBVSxRQUFRO01BQUUsR0FBRztNQUFNLE1BQU07S0FBTSxDQUFDO0tBQUcsU0FBUyxDQUFDO01BQUUsT0FBTztNQUFRLE9BQU87S0FBTyxHQUFHO01BQUUsT0FBTztNQUFXLE9BQU87S0FBVSxDQUFDO0lBQUk7Ozs7O0lBQUMsd0JBQUMsS0FBRDtLQUFHLFdBQVU7ZUFBYTtJQUF5RTs7Ozs7SUFBQyx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmLENBQStCLHdCQUFDLFVBQUQ7TUFBUSxNQUFLO01BQVMsV0FBVTtNQUFzQixTQUFTO2dCQUFTO0tBQVk7Ozs7ZUFBQyx3QkFBQyxVQUFEO01BQVEsV0FBVTtnQkFBbEIsQ0FBMEMsbUJBQWUsd0JBQUMsY0FBRCxFQUFjLE1BQU0sR0FBSzs7OztjQUFTOzs7OzthQUFNOzs7Ozs7R0FBTzs7Ozs7O0NBQWE7Ozs7O0FBQy82Qjs7O0FBRUEsU0FBUyxhQUFhLEVBQUUsT0FBTyxhQUFhLGNBQWMsU0FBUyxhQUFhOztDQUM5RSxNQUFNLENBQUMsTUFBTSxXQUFXLFNBQVMsS0FBSztDQUN0QyxNQUFNLFVBQVUsWUFBWTtFQUFFLFFBQVEsSUFBSTtFQUFHLE1BQU0sVUFBVTtFQUFHLFFBQVEsS0FBSztDQUFFO0NBQy9FLE9BQU8sd0JBQUMsWUFBRDtFQUFtQjtFQUFPLFNBQVE7RUFBMEI7WUFBNUQsQ0FBcUUsd0JBQUMsS0FBRDtHQUFHLFdBQVU7YUFBZ0I7RUFBZTs7OztZQUFDLHdCQUFDLE9BQUQ7R0FBSyxXQUFVO2FBQWYsQ0FBK0Isd0JBQUMsVUFBRDtJQUFRLFdBQVU7SUFBc0IsU0FBUztjQUFTO0dBQWtCOzs7O2FBQUMsd0JBQUMsVUFBRDtJQUFRLFdBQVU7SUFBdUIsU0FBUztJQUFTLFVBQVU7Y0FBckU7S0FBNEUsT0FBTyxjQUFjO0tBQWE7S0FBQyx3QkFBQyxHQUFELEVBQUcsTUFBTSxHQUFLOzs7OztJQUFTOzs7OztXQUFNOzs7OztVQUFhOzs7Ozs7QUFDaFk7OztBQUVBLFNBQVMsTUFBTSxFQUFFLE9BQU8sT0FBTyxVQUFVLE9BQU8sUUFBUSxPQUFPLGFBQWEsR0FBRyxTQUFTO0NBQUUsT0FBTyx3QkFBQyxTQUFEO0VBQU8sV0FBVTtZQUFqQjtHQUF5Qix3QkFBQyxRQUFELFlBQU8sTUFBWTs7Ozs7R0FBQyx3QkFBQyxTQUFEO0lBQU8sR0FBSTtJQUFhO0lBQWE7SUFBb0I7SUFBYSxXQUFXLFVBQVUsU0FBUyxNQUFNLE9BQU8sS0FBSztHQUFJOzs7OztHQUFDLCtDQUFHLFNBQVMsd0JBQUMsU0FBRDtJQUFPLFdBQVU7Y0FBZTtHQUFhOzs7O1lBQUk7Ozs7O0VBQVE7Ozs7OztBQUFFOztBQUNoVixTQUFTLFlBQVksRUFBRSxPQUFPLE9BQU8sVUFBVSxXQUFXO0NBQUUsT0FBTyx3QkFBQyxTQUFEO0VBQU8sV0FBVTtZQUFqQixDQUF5Qix3QkFBQyxRQUFELFlBQU8sTUFBWTs7OztZQUFDLHdCQUFDLE9BQUQ7R0FBSyxXQUFVO2FBQWYsQ0FBNkIsd0JBQUMsVUFBRDtJQUFRLE9BQU8sT0FBTyxRQUFRLE9BQU8sV0FBVyxRQUFRO0lBQU8sV0FBVyxVQUFVLFNBQVMsTUFBTSxPQUFPLEtBQUs7Y0FBSSxRQUFRLEtBQUssV0FBVztLQUFFLE1BQU0sYUFBYSxPQUFPLFdBQVcsV0FBVztNQUFFLE9BQU87TUFBUSxPQUFPO0tBQU8sSUFBSTtLQUFRLE9BQU8sd0JBQUMsVUFBRDtNQUFRLE9BQU8sV0FBVztnQkFBK0IsV0FBVztLQUFjLEdBQTVDLFdBQVc7Ozs7WUFBaUM7SUFBRSxDQUFDO0dBQVU7Ozs7YUFBQyx3QkFBQyxhQUFELEVBQWEsTUFBTSxHQUFLOzs7O1dBQU07Ozs7O1VBQVE7Ozs7OztBQUFFOztBQUVwZ0IsZUFBZSIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJBcHAuanN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZUVmZmVjdCwgdXNlTWVtbywgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCdcclxuaW1wb3J0IHtcclxuICBBcnJvd1VwUmlnaHQsXHJcbiAgQmFuLFxyXG4gIEJlbGxSaW5nLFxyXG4gIENoZWNrLFxyXG4gIENoZXZyb25Eb3duLFxyXG4gIENpcmNsZVVzZXJSb3VuZCxcclxuICBDbG9jazMsXHJcbiAgRG9vck9wZW4sXHJcbiAgRWRpdDMsXHJcbiAgTGF5b3V0TGlzdCxcclxuICBMb2dPdXQsXHJcbiAgTWVudSxcclxuICBNb3JlSG9yaXpvbnRhbCxcclxuICBQbHVzLFxyXG4gIFNldHRpbmdzMixcclxuICBTaGllbGRDaGVjayxcclxuICBTcGFya2xlcyxcclxuICBUYWJsZTIsXHJcbiAgVXNlcnNSb3VuZCxcclxuICBYLFxyXG59IGZyb20gJ2x1Y2lkZS1yZWFjdCdcclxuaW1wb3J0IHsgYmFja2VuZEFwaSBhcyBhcGkgfSBmcm9tICcuL2FwaS9iYWNrZW5kQXBpJ1xyXG5cclxuY29uc3QgcHJlZmVyZW5jZU9wdGlvbnMgPSBbJ05vIHByZWZlcmVuY2UnLCAnRGluaW5nIHJvb20nLCAnUGF0aW8nLCAnQmFyJ11cclxuXHJcbmNvbnN0IGZvcm1hdFRpbWUgPSAodmFsdWUpID0+IG5ldyBJbnRsLkRhdGVUaW1lRm9ybWF0KCdlbi1VUycsIHsgaG91cjogJ251bWVyaWMnLCBtaW51dGU6ICcyLWRpZ2l0JyB9KS5mb3JtYXQobmV3IERhdGUodmFsdWUpKVxyXG5jb25zdCBmb3JtYXREYXRlID0gKHZhbHVlID0gbmV3IERhdGUoKSkgPT4gbmV3IEludGwuRGF0ZVRpbWVGb3JtYXQoJ2VuLVVTJywgeyB3ZWVrZGF5OiAnbG9uZycsIG1vbnRoOiAnbG9uZycsIGRheTogJ251bWVyaWMnIH0pLmZvcm1hdChuZXcgRGF0ZSh2YWx1ZSkpXHJcbmNvbnN0IGZvcm1hdFJlbGF0aXZlID0gKHZhbHVlKSA9PiB7XHJcbiAgY29uc3QgbWludXRlcyA9IE1hdGgubWF4KDAsIE1hdGguZmxvb3IoKERhdGUubm93KCkgLSBuZXcgRGF0ZSh2YWx1ZSkuZ2V0VGltZSgpKSAvIDYwMDAwKSlcclxuICBpZiAobWludXRlcyA8IDEpIHJldHVybiAnSnVzdCBub3cnXHJcbiAgaWYgKG1pbnV0ZXMgPT09IDEpIHJldHVybiAnMSBtaW4gYWdvJ1xyXG4gIHJldHVybiBgJHttaW51dGVzfSBtaW4gYWdvYFxyXG59XHJcblxyXG5mdW5jdGlvbiBBcHAoKSB7XHJcbiAgY29uc3QgW3Nlc3Npb24sIHNldFNlc3Npb25dID0gdXNlU3RhdGUoKCkgPT4gYXBpLmdldFNlc3Npb24oKSlcclxuICBjb25zdCBbZGF0YSwgc2V0RGF0YV0gPSB1c2VTdGF0ZShudWxsKVxyXG4gIGNvbnN0IFt2aWV3LCBzZXRWaWV3XSA9IHVzZVN0YXRlKCd3YWl0bGlzdCcpXHJcbiAgY29uc3QgW2xvYWRpbmcsIHNldExvYWRpbmddID0gdXNlU3RhdGUoQm9vbGVhbihzZXNzaW9uKSlcclxuICBjb25zdCBbbW9kYWwsIHNldE1vZGFsXSA9IHVzZVN0YXRlKG51bGwpXHJcbiAgY29uc3QgW3RvYXN0LCBzZXRUb2FzdF0gPSB1c2VTdGF0ZShudWxsKVxyXG4gIGNvbnN0IFtzaWRlYmFyT3Blbiwgc2V0U2lkZWJhck9wZW5dID0gdXNlU3RhdGUoZmFsc2UpXHJcblxyXG4gIGNvbnN0IHJlZnJlc2ggPSBhc3luYyAoKSA9PiB7XHJcbiAgICBjb25zdCBkYXNoYm9hcmQgPSBhd2FpdCBhcGkuZ2V0RGFzaGJvYXJkKClcclxuICAgIHNldERhdGEoZGFzaGJvYXJkKVxyXG4gIH1cclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGlmICghc2Vzc2lvbikgcmV0dXJuIHVuZGVmaW5lZFxyXG4gICAgbGV0IG1vdW50ZWQgPSB0cnVlXHJcbiAgICBzZXRMb2FkaW5nKHRydWUpXHJcbiAgICBhcGkuZ2V0RGFzaGJvYXJkKCkudGhlbigoZGFzaGJvYXJkKSA9PiB7XHJcbiAgICAgIGlmIChtb3VudGVkKSB7XHJcbiAgICAgICAgc2V0RGF0YShkYXNoYm9hcmQpXHJcbiAgICAgICAgc2V0TG9hZGluZyhmYWxzZSlcclxuICAgICAgfVxyXG4gICAgfSkuY2F0Y2goKGVycm9yKSA9PiB7XHJcbiAgICAgIGlmICghbW91bnRlZCkgcmV0dXJuXHJcbiAgICAgIHNldExvYWRpbmcoZmFsc2UpXHJcbiAgICAgIGlmIChlcnJvci5zdGF0dXMgPT09IDQwMSkge1xyXG4gICAgICAgIGFwaS5jbGVhclNlc3Npb24oKVxyXG4gICAgICAgIHNldFNlc3Npb24obnVsbClcclxuICAgICAgICBzZXREYXRhKG51bGwpXHJcbiAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgbm90aWZ5KGVycm9yLm1lc3NhZ2UsICdlcnJvcicpXHJcbiAgICAgIH1cclxuICAgIH0pXHJcbiAgICByZXR1cm4gKCkgPT4geyBtb3VudGVkID0gZmFsc2UgfVxyXG4gIH0sIFtzZXNzaW9uXSlcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGlmICghdG9hc3QpIHJldHVybiB1bmRlZmluZWRcclxuICAgIGNvbnN0IHRpbWVvdXQgPSB3aW5kb3cuc2V0VGltZW91dCgoKSA9PiBzZXRUb2FzdChudWxsKSwgMzYwMClcclxuICAgIHJldHVybiAoKSA9PiB3aW5kb3cuY2xlYXJUaW1lb3V0KHRpbWVvdXQpXHJcbiAgfSwgW3RvYXN0XSlcclxuXHJcbiAgY29uc3Qgbm90aWZ5ID0gKG1lc3NhZ2UsIHRvbmUgPSAnc3VjY2VzcycpID0+IHNldFRvYXN0KHsgbWVzc2FnZSwgdG9uZSB9KVxyXG5cclxuICBjb25zdCBoYW5kbGVMb2dpbiA9IGFzeW5jIChjcmVkZW50aWFscykgPT4ge1xyXG4gICAgdHJ5IHtcclxuICAgICAgY29uc3QgbmV4dFNlc3Npb24gPSBhd2FpdCBhcGkubG9naW4oY3JlZGVudGlhbHMpXHJcbiAgICAgIHNldFNlc3Npb24obmV4dFNlc3Npb24pXHJcbiAgICAgIG5vdGlmeShgV2VsY29tZSBiYWNrLCAke25leHRTZXNzaW9uLm5hbWUuc3BsaXQoJyAnKVswXX0uYClcclxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgIHRocm93IGVycm9yXHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICBjb25zdCBoYW5kbGVMb2dvdXQgPSAoKSA9PiB7XHJcbiAgICB2b2lkIGFwaS5sb2dvdXQoKVxyXG4gICAgc2V0U2Vzc2lvbihudWxsKVxyXG4gICAgc2V0RGF0YShudWxsKVxyXG4gICAgc2V0Vmlldygnd2FpdGxpc3QnKVxyXG4gIH1cclxuXHJcbiAgY29uc3QgcnVuTXV0YXRpb24gPSBhc3luYyAoYWN0aW9uLCBzdWNjZXNzTWVzc2FnZSkgPT4ge1xyXG4gICAgdHJ5IHtcclxuICAgICAgYXdhaXQgYWN0aW9uKClcclxuICAgICAgYXdhaXQgcmVmcmVzaCgpXHJcbiAgICAgIHNldE1vZGFsKG51bGwpXHJcbiAgICAgIG5vdGlmeShzdWNjZXNzTWVzc2FnZSlcclxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgIGlmIChlcnJvci5zdGF0dXMgPT09IDQwMSkge1xyXG4gICAgICAgIGFwaS5jbGVhclNlc3Npb24oKVxyXG4gICAgICAgIHNldFNlc3Npb24obnVsbClcclxuICAgICAgICBzZXREYXRhKG51bGwpXHJcbiAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgbm90aWZ5KGVycm9yLm1lc3NhZ2UsICdlcnJvcicpXHJcbiAgICAgIH1cclxuICAgIH1cclxuICB9XHJcblxyXG4gIGlmICghc2Vzc2lvbikgcmV0dXJuIDxMb2dpblNjcmVlbiBvbkxvZ2luPXtoYW5kbGVMb2dpbn0gLz5cclxuICBpZiAobG9hZGluZyB8fCAhZGF0YSkgcmV0dXJuIDxMb2FkaW5nU2NyZWVuIC8+XHJcblxyXG4gIGNvbnN0IGFjdGl2ZUNvdW50ID0gZGF0YS5lbnRyaWVzLmZpbHRlcigoZW50cnkpID0+IGVudHJ5LnN0YXR1cyA9PT0gJ3dhaXRpbmcnKS5sZW5ndGhcclxuICBjb25zdCBvY2N1cGllZFRhYmxlSWRzID0gbmV3IFNldChkYXRhLnRhYmxlcy5maWx0ZXIoKHRhYmxlKSA9PiB0YWJsZS5hdmFpbGFiaWxpdHkgPT09ICdvY2N1cGllZCcpLm1hcCgodGFibGUpID0+IHRhYmxlLmlkKSlcclxuICBjb25zdCBhdmFpbGFibGVDb3VudCA9IGRhdGEudGFibGVzLmZpbHRlcigodGFibGUpID0+IHRhYmxlLmlzQWN0aXZlICYmIHRhYmxlLmF2YWlsYWJpbGl0eSA9PT0gJ2F2YWlsYWJsZScpLmxlbmd0aFxyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPGRpdiBjbGFzc05hbWU9XCJhcHAtc2hlbGxcIj5cclxuICAgICAgPGFzaWRlIGNsYXNzTmFtZT17YHNpZGViYXIgJHtzaWRlYmFyT3BlbiA/ICdpcy1vcGVuJyA6ICcnfWB9PlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYnJhbmQtbG9ja3VwXCI+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJyYW5kLW1hcmtcIj48c3Bhbj5KPC9zcGFuPjxzcGFuPlA8L3NwYW4+PC9kaXY+XHJcbiAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJyYW5kLW5hbWVcIj5IT1NUQk9BUkQ8L2Rpdj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJicmFuZC1zdWJ0aXRsZVwiPkp1bmUgJiBQaW5lPC9kaXY+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDxidXR0b24gY2xhc3NOYW1lPVwiaWNvbi1idXR0b24gc2lkZWJhci1jbG9zZVwiIG9uQ2xpY2s9eygpID0+IHNldFNpZGViYXJPcGVuKGZhbHNlKX0gYXJpYS1sYWJlbD1cIkNsb3NlIG5hdmlnYXRpb25cIj48WCBzaXplPXsxOH0gLz48L2J1dHRvbj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNlcnZpY2Utc3dpdGNoZXJcIj5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic2VydmljZS1raWNrZXJcIj48c3BhbiBjbGFzc05hbWU9XCJsaXZlLWRvdFwiIC8+IExpdmUgc2VydmljZTwvZGl2PlxyXG4gICAgICAgICAgPHN0cm9uZz57ZGF0YS5yZXN0YXVyYW50LnNlcnZpY2VMYWJlbH08L3N0cm9uZz5cclxuICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInNlcnZpY2UtZGF0ZVwiPntmb3JtYXREYXRlKCl9PC9zcGFuPlxyXG4gICAgICAgICAgPENoZXZyb25Eb3duIHNpemU9ezE1fSAvPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDxuYXYgY2xhc3NOYW1lPVwicHJpbWFyeS1uYXZcIiBhcmlhLWxhYmVsPVwiUHJpbWFyeSBuYXZpZ2F0aW9uXCI+XHJcbiAgICAgICAgICA8TmF2SXRlbSBpY29uPXs8TGF5b3V0TGlzdCBzaXplPXsxOH0gLz59IGxhYmVsPVwiV2FpdGxpc3RcIiBhY3RpdmU9e3ZpZXcgPT09ICd3YWl0bGlzdCd9IG9uQ2xpY2s9eygpID0+IHsgc2V0Vmlldygnd2FpdGxpc3QnKTsgc2V0U2lkZWJhck9wZW4oZmFsc2UpIH19IGNvdW50PXthY3RpdmVDb3VudH0gLz5cclxuICAgICAgICAgIDxOYXZJdGVtIGljb249ezxDbG9jazMgc2l6ZT17MTh9IC8+fSBsYWJlbD1cIlRvZGF54oCZcyBoaXN0b3J5XCIgYWN0aXZlPXt2aWV3ID09PSAnaGlzdG9yeSd9IG9uQ2xpY2s9eygpID0+IHsgc2V0VmlldygnaGlzdG9yeScpOyBzZXRTaWRlYmFyT3BlbihmYWxzZSkgfX0gLz5cclxuICAgICAgICAgIHtzZXNzaW9uLnJvbGUgPT09ICdtYW5hZ2VyJyAmJiA8TmF2SXRlbSBpY29uPXs8U2V0dGluZ3MyIHNpemU9ezE4fSAvPn0gbGFiZWw9XCJNYW5hZ2VyIHNldHRpbmdzXCIgYWN0aXZlPXt2aWV3ID09PSAnc2V0dGluZ3MnfSBvbkNsaWNrPXsoKSA9PiB7IHNldFZpZXcoJ3NldHRpbmdzJyk7IHNldFNpZGViYXJPcGVuKGZhbHNlKSB9fSAvPn1cclxuICAgICAgICA8L25hdj5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNpZGViYXItZm9vdGVyXCI+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNpZGViYXItbm90ZVwiPjxTcGFya2xlcyBzaXplPXsxNX0gLz48c3Bhbj5LZWVwIHRoZSByb29tIG1vdmluZy48L3NwYW4+PC9kaXY+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInByb2ZpbGUtcm93XCI+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYXZhdGFyXCI+e3Nlc3Npb24ubmFtZS5zcGxpdCgnICcpLm1hcCgocGFydCkgPT4gcGFydFswXSkuam9pbignJyl9PC9kaXY+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHJvZmlsZS1jb3B5XCI+PHN0cm9uZz57c2Vzc2lvbi5uYW1lfTwvc3Ryb25nPjxzcGFuPntzZXNzaW9uLnJvbGV9PC9zcGFuPjwvZGl2PlxyXG4gICAgICAgICAgICA8YnV0dG9uIGNsYXNzTmFtZT1cImljb24tYnV0dG9uXCIgb25DbGljaz17aGFuZGxlTG9nb3V0fSBhcmlhLWxhYmVsPVwiU2lnbiBvdXRcIiB0aXRsZT1cIlNpZ24gb3V0XCI+PExvZ091dCBzaXplPXsxN30gLz48L2J1dHRvbj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICA8L2FzaWRlPlxyXG4gICAgICB7c2lkZWJhck9wZW4gJiYgPGJ1dHRvbiBjbGFzc05hbWU9XCJzaWRlYmFyLXNjcmltXCIgb25DbGljaz17KCkgPT4gc2V0U2lkZWJhck9wZW4oZmFsc2UpfSBhcmlhLWxhYmVsPVwiQ2xvc2UgbmF2aWdhdGlvblwiIC8+fVxyXG4gICAgICA8bWFpbiBjbGFzc05hbWU9XCJtYWluLXNoZWxsXCI+XHJcbiAgICAgICAgPGhlYWRlciBjbGFzc05hbWU9XCJ0b3BiYXJcIj5cclxuICAgICAgICAgIDxidXR0b24gY2xhc3NOYW1lPVwiaWNvbi1idXR0b24gbWVudS1idXR0b25cIiBvbkNsaWNrPXsoKSA9PiBzZXRTaWRlYmFyT3Blbih0cnVlKX0gYXJpYS1sYWJlbD1cIk9wZW4gbmF2aWdhdGlvblwiPjxNZW51IHNpemU9ezIwfSAvPjwvYnV0dG9uPlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjcnVtYlwiPjxzcGFuPk9wZXJhdGlvbnM8L3NwYW4+PHNwYW4gY2xhc3NOYW1lPVwiY3J1bWItc2xhc2hcIj4vPC9zcGFuPjxzdHJvbmc+e3ZpZXcgPT09ICd3YWl0bGlzdCcgPyAnV2FpdGxpc3QnIDogdmlldyA9PT0gJ2hpc3RvcnknID8gJ1RvZGF54oCZcyBoaXN0b3J5JyA6ICdNYW5hZ2VyIHNldHRpbmdzJ308L3N0cm9uZz48L2Rpdj5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidG9wYmFyLWFjdGlvbnNcIj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9e2BvcGVuLXBpbGwgJHtkYXRhLnJlc3RhdXJhbnQuaXNPcGVuID8gJ2lzLW9wZW4nIDogJ2lzLWNsb3NlZCd9YH0+PHNwYW4gY2xhc3NOYW1lPVwib3Blbi1waWxsLWRvdFwiIC8+IHtkYXRhLnJlc3RhdXJhbnQuaXNPcGVuID8gJ09wZW4gbm93JyA6ICdDbG9zZWQnfTwvZGl2PlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRvcGJhci1kYXRlXCI+e2Zvcm1hdERhdGUoKX08L2Rpdj5cclxuICAgICAgICAgICAgPGJ1dHRvbiBjbGFzc05hbWU9XCJhdmF0YXIgYXZhdGFyLXNtYWxsXCIgYXJpYS1sYWJlbD1cIkN1cnJlbnQgcHJvZmlsZVwiPntzZXNzaW9uLm5hbWUuc3BsaXQoJyAnKS5tYXAoKHBhcnQpID0+IHBhcnRbMF0pLmpvaW4oJycpfTwvYnV0dG9uPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9oZWFkZXI+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjb250ZW50LXdyYXBcIj5cclxuICAgICAgICAgIHt2aWV3ID09PSAnd2FpdGxpc3QnICYmIDxXYWl0bGlzdFZpZXcgZGF0YT17ZGF0YX0gb25BZGQ9eygpID0+IHNldE1vZGFsKHsgdHlwZTogJ3BhcnR5JyB9KX0gb25FZGl0PXsoZW50cnkpID0+IHNldE1vZGFsKHsgdHlwZTogJ3BhcnR5JywgZW50cnkgfSl9IG9uU2VhdD17KGVudHJ5KSA9PiBzZXRNb2RhbCh7IHR5cGU6ICdzZWF0JywgZW50cnkgfSl9IG9uQ2FuY2VsPXsoZW50cnkpID0+IHNldE1vZGFsKHsgdHlwZTogJ2NhbmNlbCcsIGVudHJ5IH0pfSBvblJlbGVhc2VUYWJsZT17KHRhYmxlKSA9PiBzZXRNb2RhbCh7IHR5cGU6ICdyZWxlYXNlLXRhYmxlJywgdGFibGUgfSl9IC8+fVxyXG4gICAgICAgICAge3ZpZXcgPT09ICdoaXN0b3J5JyAmJiA8SGlzdG9yeVZpZXcgZGF0YT17ZGF0YX0gb25SZWxlYXNlVGFibGU9eyh0YWJsZSkgPT4gc2V0TW9kYWwoeyB0eXBlOiAncmVsZWFzZS10YWJsZScsIHRhYmxlIH0pfSAvPn1cclxuICAgICAgICAgIHt2aWV3ID09PSAnc2V0dGluZ3MnICYmIHNlc3Npb24ucm9sZSA9PT0gJ21hbmFnZXInICYmIDxTZXR0aW5nc1ZpZXcgZGF0YT17ZGF0YX0gb25SZWZyZXNoPXtyZWZyZXNofSBvbk5vdGlmeT17bm90aWZ5fSBvbk1vZGFsPXtzZXRNb2RhbH0gLz59XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgIDwvbWFpbj5cclxuICAgICAge21vZGFsPy50eXBlID09PSAncGFydHknICYmIDxQYXJ0eU1vZGFsIGVudHJ5PXttb2RhbC5lbnRyeX0gZW50cmllcz17ZGF0YS5lbnRyaWVzfSBvbkNsb3NlPXsoKSA9PiBzZXRNb2RhbChudWxsKX0gb25TYXZlPXsocGF5bG9hZCkgPT4gcnVuTXV0YXRpb24oKCkgPT4gbW9kYWwuZW50cnkgPyBhcGkudXBkYXRlRW50cnkobW9kYWwuZW50cnkuaWQsIHBheWxvYWQsIHNlc3Npb24pIDogYXBpLmNyZWF0ZUVudHJ5KHBheWxvYWQsIHNlc3Npb24pLCBtb2RhbC5lbnRyeSA/ICdQYXJ0eSBkZXRhaWxzIHVwZGF0ZWQuJyA6ICdQYXJ0eSBhZGRlZCB0byB0aGUgd2FpdGxpc3QuJyl9IC8+fVxyXG4gICAgICB7bW9kYWw/LnR5cGUgPT09ICdzZWF0JyAmJiA8U2VhdE1vZGFsIGVudHJ5PXttb2RhbC5lbnRyeX0gdGFibGVzPXtkYXRhLnRhYmxlc30gZW50cmllcz17ZGF0YS5lbnRyaWVzfSBhcmVhcz17ZGF0YS5hcmVhc30gb25DbG9zZT17KCkgPT4gc2V0TW9kYWwobnVsbCl9IG9uU2VhdD17KHRhYmxlSWQpID0+IHJ1bk11dGF0aW9uKCgpID0+IGFwaS5zZWF0RW50cnkobW9kYWwuZW50cnkuaWQsIHRhYmxlSWQsIHNlc3Npb24pLCBgJHttb2RhbC5lbnRyeS5ndWVzdE5hbWV9IGlzIHNlYXRlZC5gKX0gLz59XHJcbiAgICAgIHttb2RhbD8udHlwZSA9PT0gJ2NhbmNlbCcgJiYgPENvbmZpcm1Nb2RhbCB0aXRsZT1cIkNhbmNlbCB0aGlzIHBhcnR5P1wiIGRlc2NyaXB0aW9uPXtgJHttb2RhbC5lbnRyeS5ndWVzdE5hbWV9IHdpbGwgbGVhdmUgdGhlIGFjdGl2ZSBxdWV1ZS4gVGhpcyBhY3Rpb24gd2lsbCBiZSBrZXB0IGluIHRvZGF54oCZcyBoaXN0b3J5LmB9IGNvbmZpcm1MYWJlbD1cIkNhbmNlbCBwYXJ0eVwiIG9uQ2xvc2U9eygpID0+IHNldE1vZGFsKG51bGwpfSBvbkNvbmZpcm09eygpID0+IHJ1bk11dGF0aW9uKCgpID0+IGFwaS5jYW5jZWxFbnRyeShtb2RhbC5lbnRyeS5pZCwgc2Vzc2lvbiksIGAke21vZGFsLmVudHJ5Lmd1ZXN0TmFtZX0gd2FzIGNhbmNlbGxlZC5gKX0gLz59XHJcbiAgICAgIHttb2RhbD8udHlwZSA9PT0gJ3RhYmxlJyAmJiA8VGFibGVNb2RhbCB0YWJsZT17bW9kYWwudGFibGV9IGFyZWFzPXtkYXRhLmFyZWFzfSBvbkNsb3NlPXsoKSA9PiBzZXRNb2RhbChudWxsKX0gb25TYXZlPXsocGF5bG9hZCkgPT4gcnVuTXV0YXRpb24oKCkgPT4gbW9kYWwudGFibGUgPyBhcGkudXBkYXRlVGFibGUobW9kYWwudGFibGUuaWQsIHBheWxvYWQpIDogYXBpLmNyZWF0ZVRhYmxlKHBheWxvYWQpLCBtb2RhbC50YWJsZSA/ICdUYWJsZSBkZXRhaWxzIHVwZGF0ZWQuJyA6ICdUYWJsZSBhZGRlZCB0byB0aGUgcm9vbS4nKX0gLz59XHJcbiAgICAgIHttb2RhbD8udHlwZSA9PT0gJ3N0YWZmJyAmJiA8U3RhZmZNb2RhbCBvbkNsb3NlPXsoKSA9PiBzZXRNb2RhbChudWxsKX0gb25TYXZlPXsocGF5bG9hZCkgPT4gcnVuTXV0YXRpb24oKCkgPT4gYXBpLmNyZWF0ZVN0YWZmKHBheWxvYWQpLCAnU3RhZmYgYWNjb3VudCBjcmVhdGVkLicpfSAvPn1cclxuICAgICAge21vZGFsPy50eXBlID09PSAncmVsZWFzZS10YWJsZScgJiYgPENvbmZpcm1Nb2RhbCB0aXRsZT17YE1hcmsgJHttb2RhbC50YWJsZS5uYW1lfSBhcyBmcmVlP2B9IGRlc2NyaXB0aW9uPXttb2RhbC50YWJsZS5jdXJyZW50UGFydHkgPyBgJHttb2RhbC50YWJsZS5jdXJyZW50UGFydHkuZ3Vlc3ROYW1lfeKAmXMgcGFydHkgKCR7bW9kYWwudGFibGUuY3VycmVudFBhcnR5LnBhcnR5U2l6ZX0gZ3Vlc3RzKSBoYXMgZmluaXNoZWQgdXNpbmcgdGFibGUgJHttb2RhbC50YWJsZS5uYW1lfS4gSXQgd2lsbCBiZWNvbWUgYXZhaWxhYmxlIGltbWVkaWF0ZWx5IGZvciBuZXcgcGFydGllcy5gIDogYE1hcmsgdGFibGUgJHttb2RhbC50YWJsZS5uYW1lfSBhcyBmcmVlIGFuZCByZWFkeSBmb3IgbmV3IGd1ZXN0cy5gfSBjb25maXJtTGFiZWw9XCJNYXJrIHRhYmxlIGZyZWVcIiBvbkNsb3NlPXsoKSA9PiBzZXRNb2RhbChudWxsKX0gb25Db25maXJtPXsoKSA9PiBydW5NdXRhdGlvbigoKSA9PiBhcGkucmVsZWFzZVRhYmxlKG1vZGFsLnRhYmxlLmlkKSwgYFRhYmxlICR7bW9kYWwudGFibGUubmFtZX0gaXMgbm93IGZyZWUuYCl9IC8+fVxyXG4gICAgICB7dG9hc3QgJiYgPGRpdiBjbGFzc05hbWU9e2B0b2FzdCB0b2FzdC0ke3RvYXN0LnRvbmV9YH0gcm9sZT1cInN0YXR1c1wiPjxzcGFuIGNsYXNzTmFtZT1cInRvYXN0LWljb25cIj57dG9hc3QudG9uZSA9PT0gJ2Vycm9yJyA/IDxCYW4gc2l6ZT17MTZ9IC8+IDogPENoZWNrIHNpemU9ezE2fSAvPn08L3NwYW4+e3RvYXN0Lm1lc3NhZ2V9PC9kaXY+fVxyXG4gICAgPC9kaXY+XHJcbiAgKVxyXG59XHJcblxyXG5mdW5jdGlvbiBOYXZJdGVtKHsgaWNvbiwgbGFiZWwsIGFjdGl2ZSwgb25DbGljaywgY291bnQgfSkge1xyXG4gIHJldHVybiA8YnV0dG9uIGNsYXNzTmFtZT17YG5hdi1pdGVtICR7YWN0aXZlID8gJ2lzLWFjdGl2ZScgOiAnJ31gfSBvbkNsaWNrPXtvbkNsaWNrfT57aWNvbn08c3Bhbj57bGFiZWx9PC9zcGFuPntjb3VudCA+IDAgJiYgPHNwYW4gY2xhc3NOYW1lPVwibmF2LWNvdW50XCI+e2NvdW50fTwvc3Bhbj59PC9idXR0b24+XHJcbn1cclxuXHJcbmZ1bmN0aW9uIExvYWRpbmdTY3JlZW4oKSB7XHJcbiAgcmV0dXJuIDxkaXYgY2xhc3NOYW1lPVwibG9hZGluZy1zY3JlZW5cIj48ZGl2IGNsYXNzTmFtZT1cImxvYWRpbmctb3JiaXRcIj48c3BhbiAvPjwvZGl2PjxzcGFuPk9wZW5pbmcgdGhlIHNlcnZpY2UgYm9hcmQ8L3NwYW4+PC9kaXY+XHJcbn1cclxuXHJcbmZ1bmN0aW9uIExvZ2luU2NyZWVuKHsgb25Mb2dpbiB9KSB7XHJcbiAgY29uc3QgW2lkZW50aWZpZXIsIHNldElkZW50aWZpZXJdID0gdXNlU3RhdGUoJ21heWFAanVuZWFuZHBpbmUuY29tJylcclxuICBjb25zdCBbcGFzc3dvcmQsIHNldFBhc3N3b3JkXSA9IHVzZVN0YXRlKCdkZW1vMTIzNCcpXHJcbiAgY29uc3QgW2J1c3ksIHNldEJ1c3ldID0gdXNlU3RhdGUoZmFsc2UpXHJcbiAgY29uc3QgW2Vycm9yLCBzZXRFcnJvcl0gPSB1c2VTdGF0ZSgnJylcclxuXHJcbiAgY29uc3Qgc3VibWl0ID0gYXN5bmMgKGV2ZW50KSA9PiB7XHJcbiAgICBldmVudC5wcmV2ZW50RGVmYXVsdCgpXHJcbiAgICBzZXRCdXN5KHRydWUpXHJcbiAgICBzZXRFcnJvcignJylcclxuICAgIHRyeSB7XHJcbiAgICAgIGF3YWl0IG9uTG9naW4oeyBpZGVudGlmaWVyLCBwYXNzd29yZCB9KVxyXG4gICAgfSBjYXRjaCAobG9naW5FcnJvcikge1xyXG4gICAgICBzZXRFcnJvcihsb2dpbkVycm9yLm1lc3NhZ2UpXHJcbiAgICB9IGZpbmFsbHkge1xyXG4gICAgICBzZXRCdXN5KGZhbHNlKVxyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgcmV0dXJuIDxkaXYgY2xhc3NOYW1lPVwibG9naW4tc2NyZWVuXCI+XHJcbiAgICA8ZGl2IGNsYXNzTmFtZT1cImxvZ2luLWFtYmllbnQgYW1iaWVudC1vbmVcIiAvPjxkaXYgY2xhc3NOYW1lPVwibG9naW4tYW1iaWVudCBhbWJpZW50LXR3b1wiIC8+XHJcbiAgICA8ZGl2IGNsYXNzTmFtZT1cImxvZ2luLWxlZnRcIj5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJsb2dpbi1icmFuZFwiPjxkaXYgY2xhc3NOYW1lPVwiYnJhbmQtbWFya1wiPjxzcGFuPko8L3NwYW4+PHNwYW4+UDwvc3Bhbj48L2Rpdj48c3Bhbj5IT1NUQk9BUkQ8L3NwYW4+PC9kaXY+XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwibG9naW4tY29weVwiPjxwIGNsYXNzTmFtZT1cImV5ZWJyb3dcIj5KdW5lICYgUGluZSAvIFNlcnZpY2Ugb3BlcmF0aW9uczwvcD48aDE+TWFrZSBldmVyeTxiciAvPjxlbT5zZWF0PC9lbT4gY291bnQuPC9oMT48cD5BIGNsZWFyLWV5ZWQgd2FpdGxpc3QgZm9yIHRoZSBtb21lbnRzIGJldHdlZW4gYXJyaXZhbCBhbmQgZmlyc3QgYml0ZS48L3A+PC9kaXY+XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwibG9naW4tZm9vdGVyXCI+PHNwYW4+U3RhZmYgd29ya3NwYWNlPC9zcGFuPjxzcGFuIGNsYXNzTmFtZT1cImxvZ2luLWZvb3Rlci1saW5lXCIgLz48c3Bhbj5Ccm9va2x5biwgTlk8L3NwYW4+PC9kaXY+XHJcbiAgICA8L2Rpdj5cclxuICAgIDxkaXYgY2xhc3NOYW1lPVwibG9naW4tcGFuZWwtd3JhcFwiPjxkaXYgY2xhc3NOYW1lPVwibG9naW4tcGFuZWxcIj5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJwYW5lbC1raWNrZXJcIj48U2hpZWxkQ2hlY2sgc2l6ZT17MTZ9IC8+IFN0YWZmIHNpZ24gaW48L2Rpdj5cclxuICAgICAgPGgyPkdvb2QgZXZlbmluZy48L2gyPjxwIGNsYXNzTmFtZT1cInBhbmVsLWludHJvXCI+U2lnbiBpbiB0byBvcGVuIHRvbmlnaHTigJlzIHNlcnZpY2UgYm9hcmQuPC9wPlxyXG4gICAgICA8Zm9ybSBvblN1Ym1pdD17c3VibWl0fSBjbGFzc05hbWU9XCJsb2dpbi1mb3JtXCI+XHJcbiAgICAgICAgPEZpZWxkIGxhYmVsPVwiV29yayBlbWFpbFwiIHZhbHVlPXtpZGVudGlmaWVyfSBvbkNoYW5nZT17c2V0SWRlbnRpZmllcn0gdHlwZT1cImVtYWlsXCIgYXV0b0NvbXBsZXRlPVwidXNlcm5hbWVcIiAvPlxyXG4gICAgICAgIDxGaWVsZCBsYWJlbD1cIlBhc3N3b3JkXCIgdmFsdWU9e3Bhc3N3b3JkfSBvbkNoYW5nZT17c2V0UGFzc3dvcmR9IHR5cGU9XCJwYXNzd29yZFwiIGF1dG9Db21wbGV0ZT1cImN1cnJlbnQtcGFzc3dvcmRcIiAvPlxyXG4gICAgICAgIHtlcnJvciAmJiA8ZGl2IGNsYXNzTmFtZT1cImZvcm0tZXJyb3JcIj48QmFuIHNpemU9ezE1fSAvPntlcnJvcn08L2Rpdj59XHJcbiAgICAgICAgPGJ1dHRvbiBjbGFzc05hbWU9XCJidXR0b24gYnV0dG9uLXByaW1hcnkgYnV0dG9uLXdpZGVcIiBkaXNhYmxlZD17YnVzeX0+e2J1c3kgPyAnT3BlbmluZyBib2FyZOKApicgOiAnRW50ZXIgc2VydmljZSBib2FyZCd9IDxBcnJvd1VwUmlnaHQgc2l6ZT17MTd9IC8+PC9idXR0b24+XHJcbiAgICAgIDwvZm9ybT5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJkZW1vLWFjY291bnRzXCI+PHNwYW4+RGVtbyBhY2Nlc3M8L3NwYW4+PGJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgb25DbGljaz17KCkgPT4geyBzZXRJZGVudGlmaWVyKCdtYXlhQGp1bmVhbmRwaW5lLmNvbScpOyBzZXRQYXNzd29yZCgnZGVtbzEyMzQnKSB9fT5NYW5hZ2VyPC9idXR0b24+PGJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgb25DbGljaz17KCkgPT4geyBzZXRJZGVudGlmaWVyKCdsdWNhQGp1bmVhbmRwaW5lLmNvbScpOyBzZXRQYXNzd29yZCgnZGVtbzEyMzQnKSB9fT5Ib3N0PC9idXR0b24+PC9kaXY+XHJcbiAgICA8L2Rpdj48L2Rpdj5cclxuICA8L2Rpdj5cclxufVxyXG5cclxuZnVuY3Rpb24gV2FpdGxpc3RWaWV3KHsgZGF0YSwgb25BZGQsIG9uRWRpdCwgb25TZWF0LCBvbkNhbmNlbCwgb25SZWxlYXNlVGFibGUgfSkge1xyXG4gIGNvbnN0IFtmaWx0ZXIsIHNldEZpbHRlcl0gPSB1c2VTdGF0ZSgnQWxsJylcclxuICBjb25zdCB3YWl0aW5nID0gZGF0YS5lbnRyaWVzLmZpbHRlcigoZW50cnkpID0+IGVudHJ5LnN0YXR1cyA9PT0gJ3dhaXRpbmcnKVxyXG4gIGNvbnN0IHNlYXRlZCA9IGRhdGEuZW50cmllcy5maWx0ZXIoKGVudHJ5KSA9PiBlbnRyeS5zdGF0dXMgPT09ICdzZWF0ZWQnKS5sZW5ndGhcclxuICBjb25zdCBhdmFpbGFibGUgPSBkYXRhLnRhYmxlcy5maWx0ZXIoKHRhYmxlKSA9PiB0YWJsZS5pc0FjdGl2ZSAmJiB0YWJsZS5hdmFpbGFiaWxpdHkgPT09ICdhdmFpbGFibGUnKS5sZW5ndGhcclxuICBjb25zdCB2aXNpYmxlID0gZmlsdGVyID09PSAnQWxsJyA/IHdhaXRpbmcgOiB3YWl0aW5nLmZpbHRlcigoZW50cnkpID0+IGVudHJ5LnNlYXRpbmdQcmVmZXJlbmNlID09PSBmaWx0ZXIpXHJcbiAgY29uc3Qgb2xkZXN0ID0gd2FpdGluZ1swXVxyXG5cclxuICByZXR1cm4gPD5cclxuICAgIDxzZWN0aW9uIGNsYXNzTmFtZT1cInBhZ2UtaW50cm8gcGFnZS1pbnRyby1ib2FyZFwiPlxyXG4gICAgICA8ZGl2PjxwIGNsYXNzTmFtZT1cImV5ZWJyb3dcIj48c3BhbiBjbGFzc05hbWU9XCJleWVicm93LXB1bHNlXCIgLz4gTGl2ZSBzZXJ2aWNlIC8ge2RhdGEucmVzdGF1cmFudC5zZXJ2aWNlTGFiZWx9PC9wPjxoMT5LZWVwIHRoZSByb29tIG1vdmluZzxzcGFuIGNsYXNzTmFtZT1cInBlcmlvZFwiPi48L3NwYW4+PC9oMT48cCBjbGFzc05hbWU9XCJwYWdlLWRlc2NyaXB0aW9uXCI+VGhlIGFjdGl2ZSBib2FyZCBmb3IgdG9uaWdodOKAmXMgd2Fsay1pbnMuIEZpcnN0IGluLCBmaXJzdCBzZXJ2ZWQuPC9wPjwvZGl2PlxyXG4gICAgICA8YnV0dG9uIGNsYXNzTmFtZT1cImJ1dHRvbiBidXR0b24tcHJpbWFyeSBidXR0b24tYWRkXCIgb25DbGljaz17b25BZGR9PjxQbHVzIHNpemU9ezE4fSAvPiBBZGQgcGFydHk8L2J1dHRvbj5cclxuICAgIDwvc2VjdGlvbj5cclxuICAgIDxzZWN0aW9uIGNsYXNzTmFtZT1cIm1ldHJpYy1zdHJpcFwiIGFyaWEtbGFiZWw9XCJTZXJ2aWNlIHN1bW1hcnlcIj5cclxuICAgICAgPE1ldHJpYyBsYWJlbD1cIldhaXRpbmcgbm93XCIgdmFsdWU9e3dhaXRpbmcubGVuZ3RofSBkZXRhaWw9e3dhaXRpbmcubGVuZ3RoID8gYE5leHQgdXA6ICR7d2FpdGluZ1swXS5ndWVzdE5hbWV9YCA6ICdUaGUgcXVldWUgaXMgY2xlYXInfSBhY2NlbnQ9XCJyZWRcIiAvPlxyXG4gICAgICA8TWV0cmljIGxhYmVsPVwiU2VhdGVkIHRvbmlnaHRcIiB2YWx1ZT17c2VhdGVkfSBkZXRhaWw9XCJDb21wbGV0ZWQgc2VydmljZSBlbnRyaWVzXCIgYWNjZW50PVwiZ3JlZW5cIiAvPlxyXG4gICAgICA8TWV0cmljIGxhYmVsPVwiT3BlbiB0YWJsZXNcIiB2YWx1ZT17YXZhaWxhYmxlfSBkZXRhaWw9XCJSZWFkeSBmb3IgYSBwYXJ0eVwiIGFjY2VudD1cImlua1wiIC8+XHJcbiAgICAgIDxNZXRyaWMgbGFiZWw9XCJMb25nZXN0IHdhaXRcIiB2YWx1ZT17b2xkZXN0ID8gZm9ybWF0UmVsYXRpdmUob2xkZXN0LmNyZWF0ZWRBdCkgOiAn4oCUJ30gZGV0YWlsPXtvbGRlc3QgPyBvbGRlc3QuZ3Vlc3ROYW1lIDogJ05vIGFjdGl2ZSBwYXJ0aWVzJ30gYWNjZW50PVwiYW1iZXJcIiAvPlxyXG4gICAgPC9zZWN0aW9uPlxyXG4gICAgPGRpdiBjbGFzc05hbWU9XCJib2FyZC1ncmlkXCI+XHJcbiAgICAgIDxzZWN0aW9uIGNsYXNzTmFtZT1cInF1ZXVlLXBhbmVsXCI+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzZWN0aW9uLWhlYWRpbmcgcXVldWUtaGVhZGluZ1wiPjxkaXY+PHAgY2xhc3NOYW1lPVwiZXllYnJvd1wiPlRoZSBsaW5lPC9wPjxoMj5BY3RpdmUgd2FpdGxpc3QgPHNwYW4gY2xhc3NOYW1lPVwiaGVhZGluZy1jb3VudFwiPnt3YWl0aW5nLmxlbmd0aH08L3NwYW4+PC9oMj48L2Rpdj48ZGl2IGNsYXNzTmFtZT1cImZpbHRlci10YWJzXCI+e1snQWxsJywgJ0RpbmluZyByb29tJywgJ1BhdGlvJywgJ0JhciddLm1hcCgoaXRlbSkgPT4gPGJ1dHRvbiBrZXk9e2l0ZW19IGNsYXNzTmFtZT17ZmlsdGVyID09PSBpdGVtID8gJ2lzLWFjdGl2ZScgOiAnJ30gb25DbGljaz17KCkgPT4gc2V0RmlsdGVyKGl0ZW0pfT57aXRlbX08L2J1dHRvbj4pfTwvZGl2PjwvZGl2PlxyXG4gICAgICAgIHt2aXNpYmxlLmxlbmd0aCA9PT0gMCA/IDxFbXB0eVF1ZXVlIG9uQWRkPXtvbkFkZH0gZmlsdGVyZWQ9e2ZpbHRlciAhPT0gJ0FsbCd9IC8+IDogPGRpdiBjbGFzc05hbWU9XCJxdWV1ZS1saXN0XCI+e3Zpc2libGUubWFwKChlbnRyeSwgaW5kZXgpID0+IDxRdWV1ZVJvdyBrZXk9e2VudHJ5LmlkfSBlbnRyeT17ZW50cnl9IHBvc2l0aW9uPXt3YWl0aW5nLmluZGV4T2YoZW50cnkpICsgMX0gaXNOZXh0PXt3YWl0aW5nLmluZGV4T2YoZW50cnkpID09PSAwfSBvbkVkaXQ9e29uRWRpdH0gb25TZWF0PXtvblNlYXR9IG9uQ2FuY2VsPXtvbkNhbmNlbH0gLz4pfTwvZGl2Pn1cclxuICAgICAgPC9zZWN0aW9uPlxyXG4gICAgICA8YXNpZGUgY2xhc3NOYW1lPVwicm9vbS1yYWlsXCI+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyYWlsLWhlYWRpbmdcIj48ZGl2PjxwIGNsYXNzTmFtZT1cImV5ZWJyb3dcIj5UaGUgcm9vbTwvcD48aDI+VGFibGUgcHVsc2U8L2gyPjwvZGl2PjxUYWJsZTIgc2l6ZT17MjB9IC8+PC9kaXY+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0YWJsZS1zdW1tYXJ5XCI+PHN0cm9uZz57YXZhaWxhYmxlfTwvc3Ryb25nPjxzcGFuPm9mIHtkYXRhLnRhYmxlcy5maWx0ZXIoKHRhYmxlKSA9PiB0YWJsZS5pc0FjdGl2ZSkubGVuZ3RofSBhY3RpdmUgdGFibGVzIG9wZW48L3NwYW4+PGRpdiBjbGFzc05hbWU9XCJ0YWJsZS1tZXRlclwiPjxzcGFuIHN0eWxlPXt7IHdpZHRoOiBgJHtNYXRoLm1heCg2LCAoYXZhaWxhYmxlIC8gTWF0aC5tYXgoMSwgZGF0YS50YWJsZXMuZmlsdGVyKCh0YWJsZSkgPT4gdGFibGUuaXNBY3RpdmUpLmxlbmd0aCkpICogMTAwKX0lYCB9fSAvPjwvZGl2PjwvZGl2PlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWluaS10YWJsZS1ncmlkXCI+e2RhdGEudGFibGVzLmZpbHRlcigodGFibGUpID0+IHRhYmxlLmlzQWN0aXZlKS5tYXAoKHRhYmxlKSA9PiB7IGNvbnN0IG9jY3VwaWVkID0gdGFibGUuYXZhaWxhYmlsaXR5ID09PSAnb2NjdXBpZWQnOyByZXR1cm4gPGJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgY2xhc3NOYW1lPXtgbWluaS10YWJsZSAke29jY3VwaWVkID8gJ2lzLW9jY3VwaWVkJyA6ICcnfWB9IGtleT17dGFibGUuaWR9IG9uQ2xpY2s9eygpID0+IG9jY3VwaWVkICYmIG9uUmVsZWFzZVRhYmxlICYmIG9uUmVsZWFzZVRhYmxlKHRhYmxlKX0gc3R5bGU9e3sgY3Vyc29yOiBvY2N1cGllZCA/ICdwb2ludGVyJyA6ICdkZWZhdWx0JywgdGV4dEFsaWduOiAnbGVmdCcsIGJvcmRlcjogJ25vbmUnLCBmb250OiAnaW5oZXJpdCcgfX0gdGl0bGU9e29jY3VwaWVkID8gYE9jY3VwaWVkIGJ5ICR7dGFibGUuY3VycmVudFBhcnR5Py5ndWVzdE5hbWUgfHwgJ3BhcnR5J30uIENsaWNrIHRvIG1hcmsgdGFibGUgZnJlZS5gIDogYCR7dGFibGUuY2FwYWNpdHl9IHNlYXRzIGF2YWlsYWJsZWB9PjxzcGFuPnt0YWJsZS5uYW1lfTwvc3Bhbj48c21hbGw+e29jY3VwaWVkID8gKHRhYmxlLmN1cnJlbnRQYXJ0eSA/IGAke3RhYmxlLmN1cnJlbnRQYXJ0eS5ndWVzdE5hbWV9IMK3IEZyZWVgIDogJ09jY3VwaWVkIMK3IEZyZWUnKSA6IGAke3RhYmxlLmNhcGFjaXR5fSBzZWF0c2B9PC9zbWFsbD48L2J1dHRvbj4gfSl9PC9kaXY+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyYWlsLWRpdmlkZXJcIiAvPlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmFpbC1hY3Rpdml0eVwiPjxkaXYgY2xhc3NOYW1lPVwicmFpbC1oZWFkaW5nIHNtYWxsXCI+PGgzPlNlcnZpY2Ugbm90ZTwvaDM+PEJlbGxSaW5nIHNpemU9ezE2fSAvPjwvZGl2PjxwPkNsaWNrIG9jY3VwaWVkIHRhYmxlcyB0byBtYXJrIHRoZW0gZnJlZSBvbmNlIGd1ZXN0cyBkZXBhcnQsIG9yIHNlbGVjdCBhbiBhdmFpbGFibGUgdGFibGUgd2hlbiBzZWF0aW5nLjwvcD48ZGl2IGNsYXNzTmFtZT1cImFjdGl2aXR5LXVzZXJcIj48ZGl2IGNsYXNzTmFtZT1cImF2YXRhciBhdmF0YXItdGlueVwiPkpQPC9kaXY+PHNwYW4+SnVuZSAmIFBpbmUgc3RhZmYgd29ya3NwYWNlPC9zcGFuPjwvZGl2PjwvZGl2PlxyXG4gICAgICA8L2FzaWRlPlxyXG4gICAgPC9kaXY+XHJcbiAgPC8+XHJcbn1cclxuXHJcbmZ1bmN0aW9uIE1ldHJpYyh7IGxhYmVsLCB2YWx1ZSwgZGV0YWlsLCBhY2NlbnQgfSkge1xyXG4gIHJldHVybiA8ZGl2IGNsYXNzTmFtZT17YG1ldHJpYyBtZXRyaWMtJHthY2NlbnR9YH0+PGRpdiBjbGFzc05hbWU9XCJtZXRyaWMtdG9wXCI+PHNwYW4+e2xhYmVsfTwvc3Bhbj48c3BhbiBjbGFzc05hbWU9XCJtZXRyaWMtbWFya1wiIC8+PC9kaXY+PHN0cm9uZz57dmFsdWV9PC9zdHJvbmc+PHNtYWxsPntkZXRhaWx9PC9zbWFsbD48L2Rpdj5cclxufVxyXG5cclxuZnVuY3Rpb24gUXVldWVSb3coeyBlbnRyeSwgcG9zaXRpb24sIGlzTmV4dCwgb25FZGl0LCBvblNlYXQsIG9uQ2FuY2VsIH0pIHtcclxuICByZXR1cm4gPGFydGljbGUgY2xhc3NOYW1lPXtgcXVldWUtcm93ICR7aXNOZXh0ID8gJ2lzLW5leHQnIDogJyd9YH0+XHJcbiAgICA8ZGl2IGNsYXNzTmFtZT1cInF1ZXVlLXBvc2l0aW9uXCI+e2lzTmV4dCA/IDxzcGFuIGNsYXNzTmFtZT1cIm5leHQtdGFnXCI+TmV4dDwvc3Bhbj4gOiA8c3Bhbj57U3RyaW5nKHBvc2l0aW9uKS5wYWRTdGFydCgyLCAnMCcpfTwvc3Bhbj59PC9kaXY+XHJcbiAgICA8ZGl2IGNsYXNzTmFtZT1cInBhcnR5LW1haW5cIj48ZGl2IGNsYXNzTmFtZT1cInBhcnR5LW5hbWUtbGluZVwiPjxoMz57ZW50cnkuZ3Vlc3ROYW1lfTwvaDM+e2VudHJ5Lm5vdGVzICYmIDxzcGFuIGNsYXNzTmFtZT1cIm5vdGUtZmxhZ1wiIHRpdGxlPXtlbnRyeS5ub3Rlc30+Tm90ZTwvc3Bhbj59PC9kaXY+PGRpdiBjbGFzc05hbWU9XCJwYXJ0eS1tZXRhXCI+PHNwYW4+PFVzZXJzUm91bmQgc2l6ZT17MTR9IC8+IHtlbnRyeS5wYXJ0eVNpemV9IHtlbnRyeS5wYXJ0eVNpemUgPT09IDEgPyAnZ3Vlc3QnIDogJ2d1ZXN0cyd9PC9zcGFuPjxzcGFuPjxEb29yT3BlbiBzaXplPXsxNH0gLz4ge2VudHJ5LnNlYXRpbmdQcmVmZXJlbmNlfTwvc3Bhbj48c3Bhbj48Q2xvY2szIHNpemU9ezE0fSAvPiB7Zm9ybWF0VGltZShlbnRyeS5jcmVhdGVkQXQpfTwvc3Bhbj48c3BhbiBjbGFzc05hbWU9XCJwYXJ0eS1waG9uZS1pbmxpbmVcIj57ZW50cnkucGhvbmV9PC9zcGFuPjwvZGl2PjwvZGl2PlxyXG4gICAgPGRpdiBjbGFzc05hbWU9XCJwYXJ0eS1waG9uZVwiPntlbnRyeS5waG9uZX08L2Rpdj5cclxuICAgIDxkaXYgY2xhc3NOYW1lPVwid2FpdC1hZ2VcIj48c3Ryb25nPntmb3JtYXRSZWxhdGl2ZShlbnRyeS5jcmVhdGVkQXQpfTwvc3Ryb25nPjxzcGFuPndhaXRpbmc8L3NwYW4+PC9kaXY+XHJcbiAgICA8ZGl2IGNsYXNzTmFtZT1cInJvdy1hY3Rpb25zXCI+PGJ1dHRvbiBjbGFzc05hbWU9XCJidXR0b24gYnV0dG9uLXNlYXRcIiBvbkNsaWNrPXsoKSA9PiBvblNlYXQoZW50cnkpfT48VGFibGUyIHNpemU9ezE1fSAvPiBTZWF0PC9idXR0b24+PGJ1dHRvbiBjbGFzc05hbWU9XCJpY29uLWJ1dHRvblwiIG9uQ2xpY2s9eygpID0+IG9uRWRpdChlbnRyeSl9IGFyaWEtbGFiZWw9e2BFZGl0ICR7ZW50cnkuZ3Vlc3ROYW1lfWB9IHRpdGxlPVwiRWRpdFwiPjxFZGl0MyBzaXplPXsxNn0gLz48L2J1dHRvbj48YnV0dG9uIGNsYXNzTmFtZT1cImljb24tYnV0dG9uIGljb24tZGFuZ2VyXCIgb25DbGljaz17KCkgPT4gb25DYW5jZWwoZW50cnkpfSBhcmlhLWxhYmVsPXtgQ2FuY2VsICR7ZW50cnkuZ3Vlc3ROYW1lfWB9IHRpdGxlPVwiQ2FuY2VsXCI+PFggc2l6ZT17MTd9IC8+PC9idXR0b24+PC9kaXY+XHJcbiAgPC9hcnRpY2xlPlxyXG59XHJcblxyXG5mdW5jdGlvbiBFbXB0eVF1ZXVlKHsgb25BZGQsIGZpbHRlcmVkIH0pIHtcclxuICByZXR1cm4gPGRpdiBjbGFzc05hbWU9XCJlbXB0eS1zdGF0ZVwiPjxkaXYgY2xhc3NOYW1lPVwiZW1wdHktaWNvblwiPjxTcGFya2xlcyBzaXplPXsyMn0gLz48L2Rpdj48aDM+e2ZpbHRlcmVkID8gJ05vIHBhcnRpZXMgaW4gdGhpcyBhcmVhJyA6ICdBIGNsZWFyIHJvb20sIGZvciBub3cnfTwvaDM+PHA+e2ZpbHRlcmVkID8gJ1RyeSBhbm90aGVyIHNlYXRpbmcgcHJlZmVyZW5jZS4nIDogJ1doZW4gdGhlIGZpcnN0IHdhbGstaW4gYXJyaXZlcywgYWRkIHRoZW0gdG8gdGhlIGJvYXJkLid9PC9wPnshZmlsdGVyZWQgJiYgPGJ1dHRvbiBjbGFzc05hbWU9XCJidXR0b24gYnV0dG9uLXNlY29uZGFyeVwiIG9uQ2xpY2s9e29uQWRkfT48UGx1cyBzaXplPXsxNn0gLz4gQWRkIGZpcnN0IHBhcnR5PC9idXR0b24+fTwvZGl2PlxyXG59XHJcblxyXG5mdW5jdGlvbiBIaXN0b3J5Vmlldyh7IGRhdGEsIG9uUmVsZWFzZVRhYmxlIH0pIHtcclxuICBjb25zdCBoaXN0b3J5ID0gZGF0YS5lbnRyaWVzLmZpbHRlcigoZW50cnkpID0+IGVudHJ5LnN0YXR1cyAhPT0gJ3dhaXRpbmcnKS5zb3J0KChhLCBiKSA9PiBuZXcgRGF0ZShiLnNlYXRlZEF0IHx8IGIuY2FuY2VsbGVkQXQgfHwgYi5jcmVhdGVkQXQpIC0gbmV3IERhdGUoYS5zZWF0ZWRBdCB8fCBhLmNhbmNlbGxlZEF0IHx8IGEuY3JlYXRlZEF0KSlcclxuICBjb25zdCBzZWF0ZWQgPSBoaXN0b3J5LmZpbHRlcigoZW50cnkpID0+IGVudHJ5LnN0YXR1cyA9PT0gJ3NlYXRlZCcpLmxlbmd0aFxyXG4gIHJldHVybiA8PjxzZWN0aW9uIGNsYXNzTmFtZT1cInBhZ2UtaW50cm9cIj48ZGl2PjxwIGNsYXNzTmFtZT1cImV5ZWJyb3dcIj5TZXJ2aWNlIGFyY2hpdmUgLyBUb2RheTwvcD48aDE+VG9kYXnigJlzIGhpc3Rvcnk8c3BhbiBjbGFzc05hbWU9XCJwZXJpb2RcIj4uPC9zcGFuPjwvaDE+PHAgY2xhc3NOYW1lPVwicGFnZS1kZXNjcmlwdGlvblwiPkEgcXVpZXQgcmVjb3JkIG9mIGV2ZXJ5IGhhbmRvZmYgYWZ0ZXIgdGhlIHdhaXRsaXN0LjwvcD48L2Rpdj48ZGl2IGNsYXNzTmFtZT1cImhpc3RvcnktdG90YWxcIj48c3Ryb25nPntoaXN0b3J5Lmxlbmd0aH08L3N0cm9uZz48c3Bhbj5jb21wbGV0ZWQgZW50cmllczwvc3Bhbj48L2Rpdj48L3NlY3Rpb24+PHNlY3Rpb24gY2xhc3NOYW1lPVwiaGlzdG9yeS1zdW1tYXJ5XCI+PGRpdj48c3BhbiBjbGFzc05hbWU9XCJzdW1tYXJ5LWxhYmVsXCI+U2VhdGVkPC9zcGFuPjxzdHJvbmc+e3NlYXRlZH08L3N0cm9uZz48c3Bhbj5wYXJ0aWVzIGF0IGEgdGFibGU8L3NwYW4+PC9kaXY+PGRpdj48c3BhbiBjbGFzc05hbWU9XCJzdW1tYXJ5LWxhYmVsXCI+Q2FuY2VsbGVkPC9zcGFuPjxzdHJvbmc+e2hpc3RvcnkubGVuZ3RoIC0gc2VhdGVkfTwvc3Ryb25nPjxzcGFuPnBhcnRpZXMgbGVmdCB0aGUgbGluZTwvc3Bhbj48L2Rpdj48ZGl2PjxzcGFuIGNsYXNzTmFtZT1cInN1bW1hcnktbGFiZWxcIj5TZXJ2aWNlIGRhdGU8L3NwYW4+PHN0cm9uZz57bmV3IEludGwuRGF0ZVRpbWVGb3JtYXQoJ2VuLVVTJywgeyBtb250aDogJ3Nob3J0JywgZGF5OiAnbnVtZXJpYycgfSkuZm9ybWF0KG5ldyBEYXRlKCkpfTwvc3Ryb25nPjxzcGFuPntkYXRhLnJlc3RhdXJhbnQubmFtZX08L3NwYW4+PC9kaXY+PC9zZWN0aW9uPjxzZWN0aW9uIGNsYXNzTmFtZT1cImhpc3RvcnktcGFuZWxcIj48ZGl2IGNsYXNzTmFtZT1cInNlY3Rpb24taGVhZGluZ1wiPjxkaXY+PHAgY2xhc3NOYW1lPVwiZXllYnJvd1wiPlRoZSBsb2c8L3A+PGgyPkNvbXBsZXRlZCBlbnRyaWVzPC9oMj48L2Rpdj48c3BhbiBjbGFzc05hbWU9XCJtdXRlZC1sYWJlbFwiPkN1cnJlbnQgc2VydmljZSBkYXk8L3NwYW4+PC9kaXY+e2hpc3RvcnkubGVuZ3RoID09PSAwID8gPEVtcHR5SGlzdG9yeSAvPiA6IDxkaXYgY2xhc3NOYW1lPVwiaGlzdG9yeS1saXN0XCI+e2hpc3RvcnkubWFwKChlbnRyeSkgPT4gPEhpc3RvcnlSb3cga2V5PXtlbnRyeS5pZH0gZW50cnk9e2VudHJ5fSB0YWJsZT17ZGF0YS50YWJsZXMuZmluZCgodGFibGUpID0+IHRhYmxlLmlkID09PSBlbnRyeS5hc3NpZ25lZFRhYmxlSWQpfSBvblJlbGVhc2VUYWJsZT17b25SZWxlYXNlVGFibGV9IC8+KX08L2Rpdj59PC9zZWN0aW9uPjwvPlxyXG59XHJcblxyXG5mdW5jdGlvbiBIaXN0b3J5Um93KHsgZW50cnksIHRhYmxlLCBvblJlbGVhc2VUYWJsZSB9KSB7XHJcbiAgY29uc3QgaXNTZWF0ZWQgPSBlbnRyeS5zdGF0dXMgPT09ICdzZWF0ZWQnXHJcbiAgY29uc3QgaXNPY2N1cGllZCA9IGlzU2VhdGVkICYmIGVudHJ5LmlzVGFibGVPY2N1cGllZCAmJiB0YWJsZSAmJiB0YWJsZS5hdmFpbGFiaWxpdHkgPT09ICdvY2N1cGllZCdcclxuICByZXR1cm4gPGRpdiBjbGFzc05hbWU9XCJoaXN0b3J5LXJvd1wiPjxkaXYgY2xhc3NOYW1lPXtgaGlzdG9yeS1zdGF0dXMgJHtpc1NlYXRlZCA/ICdzdGF0dXMtc2VhdGVkJyA6ICdzdGF0dXMtY2FuY2VsbGVkJ31gfT57aXNTZWF0ZWQgPyA8Q2hlY2sgc2l6ZT17MTV9IC8+IDogPFggc2l6ZT17MTV9IC8+fTwvZGl2PjxkaXYgY2xhc3NOYW1lPVwiaGlzdG9yeS1wYXJ0eVwiPjxzdHJvbmc+e2VudHJ5Lmd1ZXN0TmFtZX08L3N0cm9uZz48c3Bhbj57ZW50cnkucGFydHlTaXplfSBndWVzdHMgwrcge2VudHJ5LnNlYXRpbmdQcmVmZXJlbmNlfTwvc3Bhbj48L2Rpdj48ZGl2IGNsYXNzTmFtZT1cImhpc3RvcnktZGV0YWlsXCI+PHNwYW4+e2lzU2VhdGVkID8gYFNlYXRlZCBhdCAke3RhYmxlPy5uYW1lIHx8ICd0YWJsZSd9YCA6ICdDYW5jZWxsZWQgZnJvbSBxdWV1ZSd9PC9zcGFuPjxzbWFsbD57Zm9ybWF0VGltZShlbnRyeS5zZWF0ZWRBdCB8fCBlbnRyeS5jYW5jZWxsZWRBdCB8fCBlbnRyeS5jcmVhdGVkQXQpfTwvc21hbGw+PC9kaXY+PGRpdiBjbGFzc05hbWU9XCJoaXN0b3J5LXN0YWZmXCI+PGRpdiBjbGFzc05hbWU9XCJhdmF0YXIgYXZhdGFyLXRpbnlcIj57KGVudHJ5LmNvbXBsZXRlZEJ5IHx8ICdTdGFmZicpLnNwbGl0KCcgJykubWFwKChwYXJ0KSA9PiBwYXJ0WzBdKS5qb2luKCcnKX08L2Rpdj48c3Bhbj57ZW50cnkuY29tcGxldGVkQnkgfHwgJ1N0YWZmJ308L3NwYW4+PC9kaXY+e2lzT2NjdXBpZWQgJiYgPGJ1dHRvbiBjbGFzc05hbWU9XCJidXR0b24gYnV0dG9uLWdob3N0XCIgc3R5bGU9e3sgcGFkZGluZzogJzAuMzVyZW0gMC43NXJlbScsIGZvbnRTaXplOiAnMC44NXJlbScgfX0gb25DbGljaz17KCkgPT4gb25SZWxlYXNlVGFibGUodGFibGUpfT5GcmVlIHRhYmxlPC9idXR0b24+fTwvZGl2PlxyXG59XHJcblxyXG5mdW5jdGlvbiBFbXB0eUhpc3RvcnkoKSB7IHJldHVybiA8ZGl2IGNsYXNzTmFtZT1cImVtcHR5LXN0YXRlIGNvbXBhY3RcIj48ZGl2IGNsYXNzTmFtZT1cImVtcHR5LWljb25cIj48Q2xvY2szIHNpemU9ezIxfSAvPjwvZGl2PjxoMz5Ob3RoaW5nIGZpbGVkIHlldDwvaDM+PHA+U2VhdGVkIGFuZCBjYW5jZWxsZWQgcGFydGllcyB3aWxsIGFwcGVhciBoZXJlLjwvcD48L2Rpdj4gfVxyXG5cclxuZnVuY3Rpb24gU2V0dGluZ3NWaWV3KHsgZGF0YSwgb25SZWZyZXNoLCBvbk5vdGlmeSwgb25Nb2RhbCB9KSB7XHJcbiAgY29uc3QgW3RhYiwgc2V0VGFiXSA9IHVzZVN0YXRlKCdyb29tJylcclxuICBjb25zdCBbcmVzdGF1cmFudE5hbWUsIHNldFJlc3RhdXJhbnROYW1lXSA9IHVzZVN0YXRlKGRhdGEucmVzdGF1cmFudC5uYW1lKVxyXG4gIGNvbnN0IFtpc09wZW4sIHNldElzT3Blbl0gPSB1c2VTdGF0ZShkYXRhLnJlc3RhdXJhbnQuaXNPcGVuKVxyXG4gIGNvbnN0IFtzYXZpbmcsIHNldFNhdmluZ10gPSB1c2VTdGF0ZShmYWxzZSlcclxuICBjb25zdCBzYXZlUmVzdGF1cmFudCA9IGFzeW5jIChldmVudCkgPT4ge1xyXG4gICAgZXZlbnQucHJldmVudERlZmF1bHQoKVxyXG4gICAgc2V0U2F2aW5nKHRydWUpXHJcbiAgICB0cnkgeyBhd2FpdCBhcGkudXBkYXRlUmVzdGF1cmFudCh7IG5hbWU6IHJlc3RhdXJhbnROYW1lLCBpc09wZW4gfSk7IGF3YWl0IG9uUmVmcmVzaCgpOyBvbk5vdGlmeSgnUmVzdGF1cmFudCBzZXR0aW5ncyBzYXZlZC4nKSB9IGNhdGNoIChlcnJvcikgeyBvbk5vdGlmeShlcnJvci5tZXNzYWdlLCAnZXJyb3InKSB9IGZpbmFsbHkgeyBzZXRTYXZpbmcoZmFsc2UpIH1cclxuICB9XHJcbiAgcmV0dXJuIDw+PHNlY3Rpb24gY2xhc3NOYW1lPVwicGFnZS1pbnRybyBzZXR0aW5ncy1pbnRyb1wiPjxkaXY+PHAgY2xhc3NOYW1lPVwiZXllYnJvd1wiPkNvbnRyb2wgcm9vbSAvIE1hbmFnZXIgYWNjZXNzPC9wPjxoMT5NYWtlIGl0IHlvdXJzPHNwYW4gY2xhc3NOYW1lPVwicGVyaW9kXCI+Ljwvc3Bhbj48L2gxPjxwIGNsYXNzTmFtZT1cInBhZ2UtZGVzY3JpcHRpb25cIj5UaGUgc21hbGwgY29udHJvbHMgdGhhdCBrZWVwIHRvbmlnaHTigJlzIG9wZXJhdGlvbiBmZWVsaW5nIGxpa2UgeW91cnMuPC9wPjwvZGl2PjxkaXYgY2xhc3NOYW1lPVwibWFuYWdlci1zZWFsXCI+PFNoaWVsZENoZWNrIHNpemU9ezE5fSAvPjxzcGFuPk1hbmFnZXIgYWNjZXNzPC9zcGFuPjwvZGl2Pjwvc2VjdGlvbj48ZGl2IGNsYXNzTmFtZT1cInNldHRpbmdzLWxheW91dFwiPjxkaXYgY2xhc3NOYW1lPVwic2V0dGluZ3MtdGFic1wiIHJvbGU9XCJ0YWJsaXN0XCI+PGJ1dHRvbiBjbGFzc05hbWU9e3RhYiA9PT0gJ3Jvb20nID8gJ2lzLWFjdGl2ZScgOiAnJ30gb25DbGljaz17KCkgPT4gc2V0VGFiKCdyb29tJyl9PjxTZXR0aW5nczIgc2l6ZT17MTd9IC8+IFJlc3RhdXJhbnQ8L2J1dHRvbj48YnV0dG9uIGNsYXNzTmFtZT17dGFiID09PSAndGFibGVzJyA/ICdpcy1hY3RpdmUnIDogJyd9IG9uQ2xpY2s9eygpID0+IHNldFRhYigndGFibGVzJyl9PjxUYWJsZTIgc2l6ZT17MTd9IC8+IFRhYmxlcyA8c3Bhbj57ZGF0YS50YWJsZXMubGVuZ3RofTwvc3Bhbj48L2J1dHRvbj48YnV0dG9uIGNsYXNzTmFtZT17dGFiID09PSAnc3RhZmYnID8gJ2lzLWFjdGl2ZScgOiAnJ30gb25DbGljaz17KCkgPT4gc2V0VGFiKCdzdGFmZicpfT48VXNlcnNSb3VuZCBzaXplPXsxN30gLz4gU3RhZmYgPHNwYW4+e2RhdGEudXNlcnMubGVuZ3RofTwvc3Bhbj48L2J1dHRvbj48L2Rpdj48ZGl2IGNsYXNzTmFtZT1cInNldHRpbmdzLWNvbnRlbnRcIj57dGFiID09PSAncm9vbScgJiYgPGZvcm0gY2xhc3NOYW1lPVwic2V0dGluZ3Mtc2VjdGlvblwiIG9uU3VibWl0PXtzYXZlUmVzdGF1cmFudH0+PGRpdiBjbGFzc05hbWU9XCJzZXR0aW5ncy1zZWN0aW9uLWhlYWRcIj48ZGl2PjxwIGNsYXNzTmFtZT1cImV5ZWJyb3dcIj5SZXN0YXVyYW50IGlkZW50aXR5PC9wPjxoMj5Ub25pZ2h04oCZcyByb29tPC9oMj48L2Rpdj48YnV0dG9uIGNsYXNzTmFtZT1cImJ1dHRvbiBidXR0b24tcHJpbWFyeVwiIGRpc2FibGVkPXtzYXZpbmd9PntzYXZpbmcgPyAnU2F2aW5n4oCmJyA6ICdTYXZlIGNoYW5nZXMnfTwvYnV0dG9uPjwvZGl2PjxkaXYgY2xhc3NOYW1lPVwiZm9ybS1ncmlkXCI+PEZpZWxkIGxhYmVsPVwiUmVzdGF1cmFudCBuYW1lXCIgdmFsdWU9e3Jlc3RhdXJhbnROYW1lfSBvbkNoYW5nZT17c2V0UmVzdGF1cmFudE5hbWV9IC8+PGRpdiBjbGFzc05hbWU9XCJzZXR0aW5nLXRvZ2dsZVwiPjxkaXY+PHN0cm9uZz5BY2NlcHQgbmV3IHBhcnRpZXM8L3N0cm9uZz48c3Bhbj5XaGVuIGNsb3NlZCwgdGhlIHF1ZXVlIHN0YXlzIHZpc2libGUgYnV0IG5ldyBlbnRyaWVzIGFyZSBwYXVzZWQuPC9zcGFuPjwvZGl2PjxidXR0b24gdHlwZT1cImJ1dHRvblwiIGNsYXNzTmFtZT17YHRvZ2dsZSAke2lzT3BlbiA/ICdpcy1vbicgOiAnJ31gfSBvbkNsaWNrPXsoKSA9PiBzZXRJc09wZW4oKHZhbHVlKSA9PiAhdmFsdWUpfSBhcmlhLWxhYmVsPVwiVG9nZ2xlIHJlc3RhdXJhbnQgb3BlbiBzdGF0dXNcIj48c3BhbiAvPjwvYnV0dG9uPjwvZGl2PjwvZGl2PjxkaXYgY2xhc3NOYW1lPVwicHJlZmVyZW5jZS1zZWN0aW9uXCI+PGRpdj48cCBjbGFzc05hbWU9XCJleWVicm93XCI+U2VhdGluZyBwcmVmZXJlbmNlczwvcD48aDM+QXJlYXMgaW4gdGhlIHJvb208L2gzPjwvZGl2PjxkaXYgY2xhc3NOYW1lPVwicHJlZmVyZW5jZS1jaGlwc1wiPntkYXRhLmFyZWFzLmZpbHRlcigoYXJlYSkgPT4gYXJlYS5pc0FjdGl2ZSkubWFwKChhcmVhKSA9PiA8c3BhbiBrZXk9e2FyZWEuaWR9IGNsYXNzTmFtZT1cInByZWZlcmVuY2UtY2hpcFwiPjxzcGFuIGNsYXNzTmFtZT1cImNoaXAtZG90XCIgLz57YXJlYS5uYW1lfTwvc3Bhbj4pfTwvZGl2PjwvZGl2PjwvZm9ybT59e3RhYiA9PT0gJ3RhYmxlcycgJiYgPFRhYmxlc1NldHRpbmdzIGRhdGE9e2RhdGF9IG9uTW9kYWw9e29uTW9kYWx9IC8+fXt0YWIgPT09ICdzdGFmZicgJiYgPFN0YWZmU2V0dGluZ3MgZGF0YT17ZGF0YX0gb25Nb2RhbD17b25Nb2RhbH0gb25SZWZyZXNoPXtvblJlZnJlc2h9IG9uTm90aWZ5PXtvbk5vdGlmeX0gLz59PC9kaXY+PC9kaXY+PC8+XHJcbn1cclxuXHJcbmZ1bmN0aW9uIFRhYmxlc1NldHRpbmdzKHsgZGF0YSwgb25Nb2RhbCB9KSB7XHJcbiAgcmV0dXJuIDxzZWN0aW9uIGNsYXNzTmFtZT1cInNldHRpbmdzLXNlY3Rpb25cIj48ZGl2IGNsYXNzTmFtZT1cInNldHRpbmdzLXNlY3Rpb24taGVhZFwiPjxkaXY+PHAgY2xhc3NOYW1lPVwiZXllYnJvd1wiPlJvb20gaW52ZW50b3J5PC9wPjxoMj5UYWJsZXM8L2gyPjxwIGNsYXNzTmFtZT1cInNlY3Rpb24tc3VidGl0bGVcIj5BY3RpdmUgdGFibGVzIGFyZSBhdmFpbGFibGUgdG8gaG9zdHMgd2hlbiBzZWF0aW5nIGEgcGFydHkuPC9wPjwvZGl2PjxidXR0b24gY2xhc3NOYW1lPVwiYnV0dG9uIGJ1dHRvbi1wcmltYXJ5XCIgb25DbGljaz17KCkgPT4gb25Nb2RhbCh7IHR5cGU6ICd0YWJsZScgfSl9PjxQbHVzIHNpemU9ezE2fSAvPiBBZGQgdGFibGU8L2J1dHRvbj48L2Rpdj48ZGl2IGNsYXNzTmFtZT1cImludmVudG9yeS1saXN0XCI+e2RhdGEudGFibGVzLm1hcCgodGFibGUpID0+IDxkaXYgY2xhc3NOYW1lPXtgaW52ZW50b3J5LXJvdyAkeyF0YWJsZS5pc0FjdGl2ZSA/ICdpcy1pbmFjdGl2ZScgOiAnJ31gfSBrZXk9e3RhYmxlLmlkfT48ZGl2IGNsYXNzTmFtZT1cImludmVudG9yeS1zeW1ib2xcIj48VGFibGUyIHNpemU9ezE4fSAvPjwvZGl2PjxkaXYgY2xhc3NOYW1lPVwiaW52ZW50b3J5LW1haW5cIj48c3Ryb25nPnt0YWJsZS5uYW1lfTwvc3Ryb25nPjxzcGFuPnt0YWJsZS5jYXBhY2l0eX0gc2VhdHMgwrcge2RhdGEuYXJlYXMuZmluZCgoYXJlYSkgPT4gYXJlYS5pZCA9PT0gdGFibGUuYXJlYUlkKT8ubmFtZSB8fCAnTm8gYXJlYSd9PC9zcGFuPjwvZGl2PjxzcGFuIGNsYXNzTmFtZT17YGludmVudG9yeS1zdGF0dXMgJHt0YWJsZS5hdmFpbGFiaWxpdHl9YH0+e3RhYmxlLmF2YWlsYWJpbGl0eSA9PT0gJ29jY3VwaWVkJyA/ICdPY2N1cGllZCcgOiB0YWJsZS5pc0FjdGl2ZSA/ICdBdmFpbGFibGUnIDogJ0luYWN0aXZlJ308L3NwYW4+e3RhYmxlLmF2YWlsYWJpbGl0eSA9PT0gJ29jY3VwaWVkJyAmJiA8YnV0dG9uIGNsYXNzTmFtZT1cInRleHQtYnV0dG9uXCIgc3R5bGU9e3sgbWFyZ2luTGVmdDogJzAuNXJlbScsIGZvbnRXZWlnaHQ6IDYwMCB9fSBvbkNsaWNrPXsoKSA9PiBvbk1vZGFsKHsgdHlwZTogJ3JlbGVhc2UtdGFibGUnLCB0YWJsZSB9KX0+RnJlZSB0YWJsZTwvYnV0dG9uPn08YnV0dG9uIGNsYXNzTmFtZT1cImljb24tYnV0dG9uXCIgb25DbGljaz17KCkgPT4gb25Nb2RhbCh7IHR5cGU6ICd0YWJsZScsIHRhYmxlIH0pfSBhcmlhLWxhYmVsPXtgRWRpdCAke3RhYmxlLm5hbWV9YH0gdGl0bGU9XCJFZGl0IHRhYmxlXCI+PE1vcmVIb3Jpem9udGFsIHNpemU9ezE4fSAvPjwvYnV0dG9uPjwvZGl2Pil9PC9kaXY+PC9zZWN0aW9uPlxyXG59XHJcblxyXG5mdW5jdGlvbiBTdGFmZlNldHRpbmdzKHsgZGF0YSwgb25Nb2RhbCwgb25SZWZyZXNoLCBvbk5vdGlmeSB9KSB7XHJcbiAgY29uc3QgdG9nZ2xlID0gYXN5bmMgKHVzZXIpID0+IHsgdHJ5IHsgYXdhaXQgYXBpLnRvZ2dsZVN0YWZmKHVzZXIuaWQsICF1c2VyLmlzQWN0aXZlKTsgYXdhaXQgb25SZWZyZXNoKCk7IG9uTm90aWZ5KGAke3VzZXIubmFtZX0gaXMgbm93ICR7dXNlci5pc0FjdGl2ZSA/ICdpbmFjdGl2ZScgOiAnYWN0aXZlJ30uYCkgfSBjYXRjaCAoZXJyb3IpIHsgb25Ob3RpZnkoZXJyb3IubWVzc2FnZSwgJ2Vycm9yJykgfSB9XHJcbiAgcmV0dXJuIDxzZWN0aW9uIGNsYXNzTmFtZT1cInNldHRpbmdzLXNlY3Rpb25cIj48ZGl2IGNsYXNzTmFtZT1cInNldHRpbmdzLXNlY3Rpb24taGVhZFwiPjxkaXY+PHAgY2xhc3NOYW1lPVwiZXllYnJvd1wiPlBlb3BsZSAmIGFjY2VzczwvcD48aDI+U3RhZmYgYWNjb3VudHM8L2gyPjxwIGNsYXNzTmFtZT1cInNlY3Rpb24tc3VidGl0bGVcIj5Ib3N0cyBvcGVyYXRlIHRoZSBib2FyZC4gTWFuYWdlcnMgb3duIHRoZSByb29tLjwvcD48L2Rpdj48YnV0dG9uIGNsYXNzTmFtZT1cImJ1dHRvbiBidXR0b24tcHJpbWFyeVwiIG9uQ2xpY2s9eygpID0+IG9uTW9kYWwoeyB0eXBlOiAnc3RhZmYnIH0pfT48UGx1cyBzaXplPXsxNn0gLz4gQWRkIHN0YWZmPC9idXR0b24+PC9kaXY+PGRpdiBjbGFzc05hbWU9XCJpbnZlbnRvcnktbGlzdFwiPntkYXRhLnVzZXJzLm1hcCgodXNlcikgPT4gPGRpdiBjbGFzc05hbWU9e2BpbnZlbnRvcnktcm93ICR7IXVzZXIuaXNBY3RpdmUgPyAnaXMtaW5hY3RpdmUnIDogJyd9YH0ga2V5PXt1c2VyLmlkfT48ZGl2IGNsYXNzTmFtZT1cImF2YXRhciBhdmF0YXItc21hbGxcIj57dXNlci5uYW1lLnNwbGl0KCcgJykubWFwKChwYXJ0KSA9PiBwYXJ0WzBdKS5qb2luKCcnKX08L2Rpdj48ZGl2IGNsYXNzTmFtZT1cImludmVudG9yeS1tYWluXCI+PHN0cm9uZz57dXNlci5uYW1lfTwvc3Ryb25nPjxzcGFuPnt1c2VyLmlkZW50aWZpZXJ9PC9zcGFuPjwvZGl2PjxzcGFuIGNsYXNzTmFtZT17YHJvbGUtcGlsbCByb2xlLSR7dXNlci5yb2xlfWB9Pnt1c2VyLnJvbGV9PC9zcGFuPjxidXR0b24gY2xhc3NOYW1lPXtgdGV4dC1idXR0b24gJHt1c2VyLmlzQWN0aXZlID8gJ2Rhbmdlci10ZXh0JyA6ICcnfWB9IG9uQ2xpY2s9eygpID0+IHRvZ2dsZSh1c2VyKX0+e3VzZXIuaXNBY3RpdmUgPyAnRGlzYWJsZScgOiAnRW5hYmxlJ308L2J1dHRvbj48L2Rpdj4pfTwvZGl2Pjwvc2VjdGlvbj5cclxufVxyXG5cclxuZnVuY3Rpb24gTW9kYWxTaGVsbCh7IHRpdGxlLCBleWVicm93LCBjaGlsZHJlbiwgb25DbG9zZSwgd2lkZSA9IGZhbHNlIH0pIHtcclxuICByZXR1cm4gPGRpdiBjbGFzc05hbWU9XCJtb2RhbC1iYWNrZHJvcFwiIHJvbGU9XCJwcmVzZW50YXRpb25cIj48ZGl2IGNsYXNzTmFtZT17YG1vZGFsICR7d2lkZSA/ICdtb2RhbC13aWRlJyA6ICcnfWB9IHJvbGU9XCJkaWFsb2dcIiBhcmlhLW1vZGFsPVwidHJ1ZVwiIGFyaWEtbGFiZWw9e3RpdGxlfT48YnV0dG9uIGNsYXNzTmFtZT1cIm1vZGFsLWNsb3NlIGljb24tYnV0dG9uXCIgb25DbGljaz17b25DbG9zZX0gYXJpYS1sYWJlbD1cIkNsb3NlIGRpYWxvZ1wiPjxYIHNpemU9ezE4fSAvPjwvYnV0dG9uPjxwIGNsYXNzTmFtZT1cImV5ZWJyb3dcIj57ZXllYnJvd308L3A+PGgyPnt0aXRsZX08L2gyPntjaGlsZHJlbn08L2Rpdj48L2Rpdj5cclxufVxyXG5cclxuZnVuY3Rpb24gUGFydHlNb2RhbCh7IGVudHJ5LCBlbnRyaWVzLCBvbkNsb3NlLCBvblNhdmUgfSkge1xyXG4gIGNvbnN0IFtmb3JtLCBzZXRGb3JtXSA9IHVzZVN0YXRlKHsgZ3Vlc3ROYW1lOiBlbnRyeT8uZ3Vlc3ROYW1lIHx8ICcnLCBwaG9uZTogZW50cnk/LnBob25lIHx8ICcnLCBwYXJ0eVNpemU6IGVudHJ5Py5wYXJ0eVNpemUgfHwgMiwgc2VhdGluZ1ByZWZlcmVuY2U6IGVudHJ5Py5zZWF0aW5nUHJlZmVyZW5jZSB8fCAnTm8gcHJlZmVyZW5jZScsIG5vdGVzOiBlbnRyeT8ubm90ZXMgfHwgJycgfSlcclxuICBjb25zdCBbYnVzeSwgc2V0QnVzeV0gPSB1c2VTdGF0ZShmYWxzZSlcclxuICBjb25zdCBbZXJyb3JzLCBzZXRFcnJvcnNdID0gdXNlU3RhdGUoe30pXHJcbiAgY29uc3QgZHVwbGljYXRlID0gZW50cmllcy5zb21lKChjYW5kaWRhdGUpID0+IGNhbmRpZGF0ZS5zdGF0dXMgPT09ICd3YWl0aW5nJyAmJiBjYW5kaWRhdGUuaWQgIT09IGVudHJ5Py5pZCAmJiBjYW5kaWRhdGUucGhvbmUucmVwbGFjZSgvXFxEL2csICcnKSA9PT0gZm9ybS5waG9uZS5yZXBsYWNlKC9cXEQvZywgJycpICYmIGZvcm0ucGhvbmUucmVwbGFjZSgvXFxEL2csICcnKS5sZW5ndGggPiA1KVxyXG4gIGNvbnN0IHVwZGF0ZSA9IChrZXksIHZhbHVlKSA9PiBzZXRGb3JtKChjdXJyZW50KSA9PiAoeyAuLi5jdXJyZW50LCBba2V5XTogdmFsdWUgfSkpXHJcbiAgY29uc3Qgc3VibWl0ID0gYXN5bmMgKGV2ZW50KSA9PiB7XHJcbiAgICBldmVudC5wcmV2ZW50RGVmYXVsdCgpXHJcbiAgICBjb25zdCBuZXh0RXJyb3JzID0ge31cclxuICAgIGlmICghZm9ybS5ndWVzdE5hbWUudHJpbSgpKSBuZXh0RXJyb3JzLmd1ZXN0TmFtZSA9ICdBZGQgdGhlIGd1ZXN0IG5hbWUuJ1xyXG4gICAgaWYgKGZvcm0ucGhvbmUucmVwbGFjZSgvXFxEL2csICcnKS5sZW5ndGggPCA3KSBuZXh0RXJyb3JzLnBob25lID0gJ0FkZCBhIHZhbGlkIHBob25lIG51bWJlci4nXHJcbiAgICBpZiAoIU51bWJlci5pc0ludGVnZXIoTnVtYmVyKGZvcm0ucGFydHlTaXplKSkgfHwgTnVtYmVyKGZvcm0ucGFydHlTaXplKSA8IDEpIG5leHRFcnJvcnMucGFydHlTaXplID0gJ1VzZSBhIHdob2xlIG51bWJlci4nXHJcbiAgICBzZXRFcnJvcnMobmV4dEVycm9ycylcclxuICAgIGlmIChPYmplY3Qua2V5cyhuZXh0RXJyb3JzKS5sZW5ndGgpIHJldHVyblxyXG4gICAgc2V0QnVzeSh0cnVlKVxyXG4gICAgYXdhaXQgb25TYXZlKGZvcm0pXHJcbiAgICBzZXRCdXN5KGZhbHNlKVxyXG4gIH1cclxuICByZXR1cm4gPE1vZGFsU2hlbGwgdGl0bGU9e2VudHJ5ID8gJ0VkaXQgcGFydHknIDogJ0FkZCBhIHBhcnR5J30gZXllYnJvdz17ZW50cnkgPyAnVXBkYXRlIHRoZSBsaW5lJyA6ICdOZXcgYXJyaXZhbCd9IG9uQ2xvc2U9e29uQ2xvc2V9Pjxmb3JtIGNsYXNzTmFtZT1cIm1vZGFsLWZvcm1cIiBvblN1Ym1pdD17c3VibWl0fT48ZGl2IGNsYXNzTmFtZT1cImZvcm0tZ3JpZFwiPjxGaWVsZCBsYWJlbD1cIkd1ZXN0IG5hbWVcIiB2YWx1ZT17Zm9ybS5ndWVzdE5hbWV9IG9uQ2hhbmdlPXsodmFsdWUpID0+IHVwZGF0ZSgnZ3Vlc3ROYW1lJywgdmFsdWUpfSBlcnJvcj17ZXJyb3JzLmd1ZXN0TmFtZX0gYXV0b0ZvY3VzIC8+PEZpZWxkIGxhYmVsPVwiUGhvbmUgbnVtYmVyXCIgdmFsdWU9e2Zvcm0ucGhvbmV9IG9uQ2hhbmdlPXsodmFsdWUpID0+IHVwZGF0ZSgncGhvbmUnLCB2YWx1ZSl9IGVycm9yPXtlcnJvcnMucGhvbmV9IHR5cGU9XCJ0ZWxcIiAvPjxGaWVsZCBsYWJlbD1cIlBhcnR5IHNpemVcIiB2YWx1ZT17Zm9ybS5wYXJ0eVNpemV9IG9uQ2hhbmdlPXsodmFsdWUpID0+IHVwZGF0ZSgncGFydHlTaXplJywgdmFsdWUpfSBlcnJvcj17ZXJyb3JzLnBhcnR5U2l6ZX0gdHlwZT1cIm51bWJlclwiIG1pbj1cIjFcIiAvPjxTZWxlY3RGaWVsZCBsYWJlbD1cIlNlYXRpbmcgcHJlZmVyZW5jZVwiIHZhbHVlPXtmb3JtLnNlYXRpbmdQcmVmZXJlbmNlfSBvbkNoYW5nZT17KHZhbHVlKSA9PiB1cGRhdGUoJ3NlYXRpbmdQcmVmZXJlbmNlJywgdmFsdWUpfSBvcHRpb25zPXtwcmVmZXJlbmNlT3B0aW9uc30gLz48L2Rpdj48RmllbGQgbGFiZWw9XCJOb3RlcyBmb3IgdGhlIGZsb29yXCIgdmFsdWU9e2Zvcm0ubm90ZXN9IG9uQ2hhbmdlPXsodmFsdWUpID0+IHVwZGF0ZSgnbm90ZXMnLCB2YWx1ZSl9IHBsYWNlaG9sZGVyPVwiSGlnaCBjaGFpciwgY2VsZWJyYXRpb24sIGFjY2Vzc2liaWxpdHnigKZcIiAvPjxkaXYgY2xhc3NOYW1lPVwibW9kYWwtcnVsZVwiIC8+e2R1cGxpY2F0ZSAmJiA8ZGl2IGNsYXNzTmFtZT1cImR1cGxpY2F0ZS13YXJuaW5nXCI+PEJlbGxSaW5nIHNpemU9ezE3fSAvPjxkaXY+PHN0cm9uZz5Bbm90aGVyIGFjdGl2ZSBwYXJ0eSBoYXMgdGhpcyBudW1iZXIuPC9zdHJvbmc+PHNwYW4+WW91IGNhbiBzdGlsbCBzYXZlIHRoaXMgZW50cnksIGJ1dCBjaGVjayB0aGUgbmFtZSBiZWZvcmUgY2FsbGluZy48L3NwYW4+PC9kaXY+PC9kaXY+fTxkaXYgY2xhc3NOYW1lPVwibW9kYWwtYWN0aW9uc1wiPjxidXR0b24gdHlwZT1cImJ1dHRvblwiIGNsYXNzTmFtZT1cImJ1dHRvbiBidXR0b24tZ2hvc3RcIiBvbkNsaWNrPXtvbkNsb3NlfT5CYWNrPC9idXR0b24+PGJ1dHRvbiBjbGFzc05hbWU9XCJidXR0b24gYnV0dG9uLXByaW1hcnlcIiBkaXNhYmxlZD17YnVzeX0+e2J1c3kgPyAnU2F2aW5n4oCmJyA6IGVudHJ5ID8gJ1NhdmUgY2hhbmdlcycgOiAnQWRkIHRvIHdhaXRsaXN0J30gPEFycm93VXBSaWdodCBzaXplPXsxNn0gLz48L2J1dHRvbj48L2Rpdj48L2Zvcm0+PC9Nb2RhbFNoZWxsPlxyXG59XHJcblxyXG5mdW5jdGlvbiBTZWF0TW9kYWwoeyBlbnRyeSwgdGFibGVzLCBlbnRyaWVzLCBhcmVhcywgb25DbG9zZSwgb25TZWF0IH0pIHtcclxuICBjb25zdCBbc2VsZWN0ZWQsIHNldFNlbGVjdGVkXSA9IHVzZVN0YXRlKCcnKVxyXG4gIGNvbnN0IFtidXN5LCBzZXRCdXN5XSA9IHVzZVN0YXRlKGZhbHNlKVxyXG4gIGNvbnN0IG9wdGlvbnMgPSB0YWJsZXMuZmlsdGVyKCh0YWJsZSkgPT4gdGFibGUuaXNBY3RpdmUgJiYgdGFibGUuYXZhaWxhYmlsaXR5ID09PSAnYXZhaWxhYmxlJylcclxuICBjb25zdCBzdWJtaXQgPSBhc3luYyAoKSA9PiB7IGlmICghc2VsZWN0ZWQpIHJldHVybjsgc2V0QnVzeSh0cnVlKTsgYXdhaXQgb25TZWF0KHNlbGVjdGVkKTsgc2V0QnVzeShmYWxzZSkgfVxyXG4gIHJldHVybiA8TW9kYWxTaGVsbCB0aXRsZT17YFNlYXQgJHtlbnRyeS5ndWVzdE5hbWV9YH0gZXllYnJvdz1cIkNob29zZSBhIHRhYmxlXCIgb25DbG9zZT17b25DbG9zZX0gd2lkZT48ZGl2IGNsYXNzTmFtZT1cInNlYXQtcGFydHktc3VtbWFyeVwiPjxkaXYgY2xhc3NOYW1lPVwic2VhdC1udW1iZXJcIj57ZW50cnkucGFydHlTaXplfTwvZGl2PjxkaXY+PHN0cm9uZz57ZW50cnkuZ3Vlc3ROYW1lfTwvc3Ryb25nPjxzcGFuPntlbnRyeS5wYXJ0eVNpemV9IGd1ZXN0cyDCtyB7ZW50cnkuc2VhdGluZ1ByZWZlcmVuY2V9IMK3IHdhaXRpbmcge2Zvcm1hdFJlbGF0aXZlKGVudHJ5LmNyZWF0ZWRBdCkucmVwbGFjZSgnIGFnbycsICcnKX08L3NwYW4+PC9kaXY+PC9kaXY+PGRpdiBjbGFzc05hbWU9XCJ0YWJsZS1jaG9pY2UtZ3JpZFwiPntvcHRpb25zLm1hcCgodGFibGUpID0+IHsgY29uc3QgYXJlYSA9IGFyZWFzLmZpbmQoKGNhbmRpZGF0ZSkgPT4gY2FuZGlkYXRlLmlkID09PSB0YWJsZS5hcmVhSWQpPy5uYW1lOyBjb25zdCBmaXRzID0gdGFibGUuY2FwYWNpdHkgPj0gZW50cnkucGFydHlTaXplOyByZXR1cm4gPGJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIga2V5PXt0YWJsZS5pZH0gZGlzYWJsZWQ9eyFmaXRzfSBjbGFzc05hbWU9e2B0YWJsZS1jaG9pY2UgJHtzZWxlY3RlZCA9PT0gdGFibGUuaWQgPyAnaXMtc2VsZWN0ZWQnIDogJyd9ICR7IWZpdHMgPyAnaXMtdG9vLXNtYWxsJyA6ICcnfWB9IG9uQ2xpY2s9eygpID0+IHNldFNlbGVjdGVkKHRhYmxlLmlkKX0+PHNwYW4gY2xhc3NOYW1lPVwiY2hvaWNlLWNoZWNrXCI+e3NlbGVjdGVkID09PSB0YWJsZS5pZCAmJiA8Q2hlY2sgc2l6ZT17MTR9IC8+fTwvc3Bhbj48VGFibGUyIHNpemU9ezIyfSAvPjxzdHJvbmc+e3RhYmxlLm5hbWV9PC9zdHJvbmc+PHNwYW4+e3RhYmxlLmNhcGFjaXR5fSBzZWF0czwvc3Bhbj48c21hbGw+e2FyZWF9PC9zbWFsbD57IWZpdHMgJiYgPGVtPlRvbyBzbWFsbDwvZW0+fTwvYnV0dG9uPiB9KX08L2Rpdj57b3B0aW9ucy5sZW5ndGggPT09IDAgJiYgPGRpdiBjbGFzc05hbWU9XCJpbmxpbmUtZW1wdHlcIj5UaGVyZSBhcmUgbm8gYWN0aXZlIHRhYmxlcyBhdmFpbGFibGUgcmlnaHQgbm93LjwvZGl2Pn08ZGl2IGNsYXNzTmFtZT1cIm1vZGFsLWFjdGlvbnNcIj48YnV0dG9uIHR5cGU9XCJidXR0b25cIiBjbGFzc05hbWU9XCJidXR0b24gYnV0dG9uLWdob3N0XCIgb25DbGljaz17b25DbG9zZX0+QmFjazwvYnV0dG9uPjxidXR0b24gY2xhc3NOYW1lPVwiYnV0dG9uIGJ1dHRvbi1wcmltYXJ5XCIgZGlzYWJsZWQ9eyFzZWxlY3RlZCB8fCBidXN5fSBvbkNsaWNrPXtzdWJtaXR9PntidXN5ID8gJ1NlYXRpbmfigKYnIDogJ0NvbmZpcm0gdGFibGUnfSA8Q2hlY2sgc2l6ZT17MTZ9IC8+PC9idXR0b24+PC9kaXY+PC9Nb2RhbFNoZWxsPlxyXG59XHJcblxyXG5mdW5jdGlvbiBUYWJsZU1vZGFsKHsgdGFibGUsIGFyZWFzLCBvbkNsb3NlLCBvblNhdmUgfSkge1xyXG4gIGNvbnN0IFtmb3JtLCBzZXRGb3JtXSA9IHVzZVN0YXRlKHsgbmFtZTogdGFibGU/Lm5hbWUgfHwgJycsIGNhcGFjaXR5OiB0YWJsZT8uY2FwYWNpdHkgfHwgMiwgYXJlYUlkOiB0YWJsZT8uYXJlYUlkIHx8IGFyZWFzWzBdPy5pZCB8fCAnJywgaXNBY3RpdmU6IHRhYmxlPy5pc0FjdGl2ZSA/PyB0cnVlIH0pXHJcbiAgY29uc3Qgc3VibWl0ID0gYXN5bmMgKGV2ZW50KSA9PiB7IGV2ZW50LnByZXZlbnREZWZhdWx0KCk7IGF3YWl0IG9uU2F2ZShmb3JtKSB9XHJcbiAgcmV0dXJuIDxNb2RhbFNoZWxsIHRpdGxlPXt0YWJsZSA/IGBFZGl0ICR7dGFibGUubmFtZX1gIDogJ0FkZCBhIHRhYmxlJ30gZXllYnJvdz1cIlJvb20gaW52ZW50b3J5XCIgb25DbG9zZT17b25DbG9zZX0+PGZvcm0gY2xhc3NOYW1lPVwibW9kYWwtZm9ybVwiIG9uU3VibWl0PXtzdWJtaXR9PjxkaXYgY2xhc3NOYW1lPVwiZm9ybS1ncmlkXCI+PEZpZWxkIGxhYmVsPVwiVGFibGUgbmFtZVwiIHZhbHVlPXtmb3JtLm5hbWV9IG9uQ2hhbmdlPXsodmFsdWUpID0+IHNldEZvcm0oeyAuLi5mb3JtLCBuYW1lOiB2YWx1ZSB9KX0gYXV0b0ZvY3VzIC8+PEZpZWxkIGxhYmVsPVwiQ2FwYWNpdHlcIiB0eXBlPVwibnVtYmVyXCIgbWluPVwiMVwiIHZhbHVlPXtmb3JtLmNhcGFjaXR5fSBvbkNoYW5nZT17KHZhbHVlKSA9PiBzZXRGb3JtKHsgLi4uZm9ybSwgY2FwYWNpdHk6IHZhbHVlIH0pfSAvPjxTZWxlY3RGaWVsZCBsYWJlbD1cIkFyZWFcIiB2YWx1ZT17Zm9ybS5hcmVhSWR9IG9uQ2hhbmdlPXsodmFsdWUpID0+IHNldEZvcm0oeyAuLi5mb3JtLCBhcmVhSWQ6IHZhbHVlIH0pfSBvcHRpb25zPXthcmVhcy5tYXAoKGFyZWEpID0+ICh7IGxhYmVsOiBhcmVhLm5hbWUsIHZhbHVlOiBhcmVhLmlkIH0pKX0gLz48L2Rpdj57dGFibGUgJiYgPGRpdiBjbGFzc05hbWU9XCJzZXR0aW5nLXRvZ2dsZSBtb2RhbC10b2dnbGVcIj48ZGl2PjxzdHJvbmc+QXZhaWxhYmxlIGZvciBzZWF0aW5nPC9zdHJvbmc+PHNwYW4+SW5hY3RpdmUgdGFibGVzIHN0YXkgaW4gdGhlIGludmVudG9yeSBmb3IgcmVmZXJlbmNlLjwvc3Bhbj48L2Rpdj48YnV0dG9uIHR5cGU9XCJidXR0b25cIiBjbGFzc05hbWU9e2B0b2dnbGUgJHtmb3JtLmlzQWN0aXZlID8gJ2lzLW9uJyA6ICcnfWB9IG9uQ2xpY2s9eygpID0+IHNldEZvcm0oeyAuLi5mb3JtLCBpc0FjdGl2ZTogIWZvcm0uaXNBY3RpdmUgfSl9IGFyaWEtbGFiZWw9XCJUb2dnbGUgdGFibGUgYXZhaWxhYmlsaXR5XCI+PHNwYW4gLz48L2J1dHRvbj48L2Rpdj59PGRpdiBjbGFzc05hbWU9XCJtb2RhbC1hY3Rpb25zXCI+PGJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgY2xhc3NOYW1lPVwiYnV0dG9uIGJ1dHRvbi1naG9zdFwiIG9uQ2xpY2s9e29uQ2xvc2V9PkJhY2s8L2J1dHRvbj48YnV0dG9uIGNsYXNzTmFtZT1cImJ1dHRvbiBidXR0b24tcHJpbWFyeVwiPnt0YWJsZSA/ICdTYXZlIHRhYmxlJyA6ICdBZGQgdGFibGUnfSA8QXJyb3dVcFJpZ2h0IHNpemU9ezE2fSAvPjwvYnV0dG9uPjwvZGl2PjwvZm9ybT48L01vZGFsU2hlbGw+XHJcbn1cclxuXHJcbmZ1bmN0aW9uIFN0YWZmTW9kYWwoeyBvbkNsb3NlLCBvblNhdmUgfSkge1xyXG4gIGNvbnN0IFtmb3JtLCBzZXRGb3JtXSA9IHVzZVN0YXRlKHsgbmFtZTogJycsIGlkZW50aWZpZXI6ICcnLCByb2xlOiAnaG9zdCcgfSlcclxuICByZXR1cm4gPE1vZGFsU2hlbGwgdGl0bGU9XCJBZGQgYSBzdGFmZiBhY2NvdW50XCIgZXllYnJvdz1cIlBlb3BsZSAmIGFjY2Vzc1wiIG9uQ2xvc2U9e29uQ2xvc2V9Pjxmb3JtIGNsYXNzTmFtZT1cIm1vZGFsLWZvcm1cIiBvblN1Ym1pdD17KGV2ZW50KSA9PiB7IGV2ZW50LnByZXZlbnREZWZhdWx0KCk7IG9uU2F2ZShmb3JtKSB9fT48RmllbGQgbGFiZWw9XCJGdWxsIG5hbWVcIiB2YWx1ZT17Zm9ybS5uYW1lfSBvbkNoYW5nZT17KHZhbHVlKSA9PiBzZXRGb3JtKHsgLi4uZm9ybSwgbmFtZTogdmFsdWUgfSl9IGF1dG9Gb2N1cyAvPjxGaWVsZCBsYWJlbD1cIldvcmsgZW1haWxcIiB0eXBlPVwiZW1haWxcIiB2YWx1ZT17Zm9ybS5pZGVudGlmaWVyfSBvbkNoYW5nZT17KHZhbHVlKSA9PiBzZXRGb3JtKHsgLi4uZm9ybSwgaWRlbnRpZmllcjogdmFsdWUgfSl9IC8+PFNlbGVjdEZpZWxkIGxhYmVsPVwiUm9sZVwiIHZhbHVlPXtmb3JtLnJvbGV9IG9uQ2hhbmdlPXsodmFsdWUpID0+IHNldEZvcm0oeyAuLi5mb3JtLCByb2xlOiB2YWx1ZSB9KX0gb3B0aW9ucz17W3sgbGFiZWw6ICdIb3N0JywgdmFsdWU6ICdob3N0JyB9LCB7IGxhYmVsOiAnTWFuYWdlcicsIHZhbHVlOiAnbWFuYWdlcicgfV19IC8+PHAgY2xhc3NOYW1lPVwibW9kYWwtaGludFwiPkEgdGVtcG9yYXJ5IHBhc3N3b3JkIGZsb3cgd2lsbCBiZSBjb25uZWN0ZWQgd2hlbiB0aGUgYmFja2VuZCBpcyBhZGRlZC48L3A+PGRpdiBjbGFzc05hbWU9XCJtb2RhbC1hY3Rpb25zXCI+PGJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgY2xhc3NOYW1lPVwiYnV0dG9uIGJ1dHRvbi1naG9zdFwiIG9uQ2xpY2s9e29uQ2xvc2V9PkJhY2s8L2J1dHRvbj48YnV0dG9uIGNsYXNzTmFtZT1cImJ1dHRvbiBidXR0b24tcHJpbWFyeVwiPkNyZWF0ZSBhY2NvdW50IDxBcnJvd1VwUmlnaHQgc2l6ZT17MTZ9IC8+PC9idXR0b24+PC9kaXY+PC9mb3JtPjwvTW9kYWxTaGVsbD5cclxufVxyXG5cclxuZnVuY3Rpb24gQ29uZmlybU1vZGFsKHsgdGl0bGUsIGRlc2NyaXB0aW9uLCBjb25maXJtTGFiZWwsIG9uQ2xvc2UsIG9uQ29uZmlybSB9KSB7XHJcbiAgY29uc3QgW2J1c3ksIHNldEJ1c3ldID0gdXNlU3RhdGUoZmFsc2UpXHJcbiAgY29uc3QgY29uZmlybSA9IGFzeW5jICgpID0+IHsgc2V0QnVzeSh0cnVlKTsgYXdhaXQgb25Db25maXJtKCk7IHNldEJ1c3koZmFsc2UpIH1cclxuICByZXR1cm4gPE1vZGFsU2hlbGwgdGl0bGU9e3RpdGxlfSBleWVicm93PVwiUGxlYXNlIGNvbmZpcm1cIiBvbkNsb3NlPXtvbkNsb3NlfT48cCBjbGFzc05hbWU9XCJjb25maXJtLWNvcHlcIj57ZGVzY3JpcHRpb259PC9wPjxkaXYgY2xhc3NOYW1lPVwibW9kYWwtYWN0aW9uc1wiPjxidXR0b24gY2xhc3NOYW1lPVwiYnV0dG9uIGJ1dHRvbi1naG9zdFwiIG9uQ2xpY2s9e29uQ2xvc2V9PktlZXAgcGFydHk8L2J1dHRvbj48YnV0dG9uIGNsYXNzTmFtZT1cImJ1dHRvbiBidXR0b24tZGFuZ2VyXCIgb25DbGljaz17Y29uZmlybX0gZGlzYWJsZWQ9e2J1c3l9PntidXN5ID8gJ1VwZGF0aW5n4oCmJyA6IGNvbmZpcm1MYWJlbH0gPFggc2l6ZT17MTZ9IC8+PC9idXR0b24+PC9kaXY+PC9Nb2RhbFNoZWxsPlxyXG59XHJcblxyXG5mdW5jdGlvbiBGaWVsZCh7IGxhYmVsLCB2YWx1ZSwgb25DaGFuZ2UsIHR5cGUgPSAndGV4dCcsIGVycm9yLCBwbGFjZWhvbGRlciwgLi4ucHJvcHMgfSkgeyByZXR1cm4gPGxhYmVsIGNsYXNzTmFtZT1cImZpZWxkXCI+PHNwYW4+e2xhYmVsfTwvc3Bhbj48aW5wdXQgey4uLnByb3BzfSB0eXBlPXt0eXBlfSB2YWx1ZT17dmFsdWV9IHBsYWNlaG9sZGVyPXtwbGFjZWhvbGRlcn0gb25DaGFuZ2U9eyhldmVudCkgPT4gb25DaGFuZ2UoZXZlbnQudGFyZ2V0LnZhbHVlKX0gLz48PntlcnJvciAmJiA8c21hbGwgY2xhc3NOYW1lPVwiZmllbGQtZXJyb3JcIj57ZXJyb3J9PC9zbWFsbD59PC8+PC9sYWJlbD4gfVxyXG5mdW5jdGlvbiBTZWxlY3RGaWVsZCh7IGxhYmVsLCB2YWx1ZSwgb25DaGFuZ2UsIG9wdGlvbnMgfSkgeyByZXR1cm4gPGxhYmVsIGNsYXNzTmFtZT1cImZpZWxkXCI+PHNwYW4+e2xhYmVsfTwvc3Bhbj48ZGl2IGNsYXNzTmFtZT1cInNlbGVjdC13cmFwXCI+PHNlbGVjdCB2YWx1ZT17dHlwZW9mIG9wdGlvbnNbMF0gPT09ICdzdHJpbmcnID8gdmFsdWUgOiB2YWx1ZX0gb25DaGFuZ2U9eyhldmVudCkgPT4gb25DaGFuZ2UoZXZlbnQudGFyZ2V0LnZhbHVlKX0+e29wdGlvbnMubWFwKChvcHRpb24pID0+IHsgY29uc3Qgbm9ybWFsaXplZCA9IHR5cGVvZiBvcHRpb24gPT09ICdzdHJpbmcnID8geyBsYWJlbDogb3B0aW9uLCB2YWx1ZTogb3B0aW9uIH0gOiBvcHRpb247IHJldHVybiA8b3B0aW9uIHZhbHVlPXtub3JtYWxpemVkLnZhbHVlfSBrZXk9e25vcm1hbGl6ZWQudmFsdWV9Pntub3JtYWxpemVkLmxhYmVsfTwvb3B0aW9uPiB9KX08L3NlbGVjdD48Q2hldnJvbkRvd24gc2l6ZT17MTZ9IC8+PC9kaXY+PC9sYWJlbD4gfVxyXG5cclxuZXhwb3J0IGRlZmF1bHQgQXBwXHJcbiJdfQ==